import { Auth } from "aws-amplify";

export const getJwtToken = async () => {
  try {
    let token = (await Auth.currentSession()).getIdToken().getJwtToken();
    return token;
  } catch (error) {
    console.log("Error getting JWT token:", error);
  }
};
