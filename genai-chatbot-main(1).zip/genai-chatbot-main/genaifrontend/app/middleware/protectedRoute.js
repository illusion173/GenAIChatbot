"use client";

import React, { createContext, useContext } from "react";
import { Authenticator } from "@aws-amplify/ui-react";
import { Amplify } from "aws-amplify";
import config from "../../src/amplifyconfiguration.json";
import "@aws-amplify/ui-react/styles.css";

// Configure Amplify with the output settings
Amplify.configure(config);

// Create a context to hold the user details
const UserContext = createContext();

const protectedRoute = (Comp) => (props) => {
  return (
    <Authenticator hideSignUp>
      {({ signOut, user }) => (
        // Provide the user details via context
        <UserContext.Provider value={{ signOut, user }}>
          <Comp {...props} />
        </UserContext.Provider>
      )}
    </Authenticator>
  );
};

// Custom hook to use the user context
export const useUser = () => {
  return useContext(UserContext);
};

export default protectedRoute;
