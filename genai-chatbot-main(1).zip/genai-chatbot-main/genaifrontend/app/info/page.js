"use client";

import protectedRoute from "../middleware/protectedRoute";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import "./styles.css";

const Info = () => {
  const router = useRouter();
  const handleClickBackToDashboard = async () => {
    router.push("/dashboard");
  };

  useEffect(() => { }, []);

  return (
    <div>
      <div className="p-6">
        <button
          onClick={handleClickBackToDashboard}
          className="mb-6 px-4 py-2 bg-blue-600 text-white font-semibold rounded hover:bg-blue-500 transition duration-300 ease-in-out shadow-lg"
        >
          Back to Dashboard
        </button>
      </div>

      <div className="h-full px-12 pt-10">
        {/* Chatbot Info Section */}
        <div className="info-header">
          <h1 className="text-2xl font-bold" id="ChatbotInfoHeader">
            Chatbot Interaction
          </h1>
        </div>
        <div className="info-content flex items-center">
          <div className="w-1/2">
            <video
              src="/chatbotinteraction-1.mov"
              alt="Chatbot Info"
              className="my-4 rounded shadow-lg video w-full"
              autoPlay
              loop
              muted
              controls
            />
          </div>
          <p className="p-4 w-1/2">
            To begin using the chatbot, simply select a domain & subdomain that
            has been created. <br></br> Type in your question! <br></br> Please
            note that the knowledgebase is only as good as the data that is
            inputted into it!<br></br> See below for uploading details.
          </p>
        </div>

        {/* Upload Info Section */}
        <div className="info-header">
          <h1 className="text-2xl font-bold" id="UploadInfoHeader">
            Uploading Files
          </h1>
        </div>
        <div className="info-content flex items-center">
          <div className="w-1/2">
            <video
              src="/uploading-1.mov"
              alt="Upload Info"
              className="my-4 rounded shadow-lg video w-full"
              autoPlay
              loop
              muted
              controls
            />
          </div>
          <div className="p-4 w-1/2">
            Currently, users can upload files depending on the domain and
            subdomain. This puts them in an appropriate S3 bucket. Users can
            single upload or bulk upload. Max Upload is currently 5 Gb per file.
            <br></br>
            Additionally, users can upload files with tags.
            <table border="1" className="w-full mt-4">
              <thead>
                <tr>
                  <th>Tag</th>
                  <th>phi: bool</th>
                  <th>pii: bool</th>
                  <th>summarize: bool</th>
                  <th>image_type: String</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>Options</td>
                  <td>true, false</td>
                  <td>true, false</td>
                  <td>true, false</td>
                  <td>"document", "expense"</td>
                </tr>
                <tr>
                  <td>Explanation</td>
                  <td>Tell the system if the file may contain PHI</td>
                  <td>Tell the system if the file may contain PII</td>
                  <td>
                    The "invoke_prompt" is the prompt that will be used to
                    summarize.
                  </td>
                  <td>
                    Allowed image types: document (for forms and general
                    documents), expense (for receipts and expense reports).
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Download Info Section */}
        <div className="info-header">
          <h1 className="text-2xl font-bold" id="DownloadInfo">
            Downloading Files
          </h1>
        </div>
        <div className="info-content flex items-center">
          <div className="w-1/2">
            <video
              src="/downloadpage-1.mov"
              alt="Download Info"
              className="my-4 rounded shadow-lg video w-full"
              autoPlay
              loop
              controls
              muted
            />
          </div>
          <p className="p-4 w-1/2">
            To download a citation to your machine, you may directly download it
            from the citation popup. <br></br>
            Or, add the file to your download list, navigate to the download
            page, select the file and an s3 presignued url will give you access.
            <br></br>
            For multiple files, simply select the checkbox and download all and
            then a zip file will download and zip up all the selected files.
          </p>
        </div>

        {/* Inserting New Domains Section */}
        <div className="info-header">
          <h1 className="text-2xl font-bold" id="InsertNewDomain">
            Inserting New Domains
          </h1>
        </div>
        <div className="info-content flex items-center">
          <div className="w-1/2">
            <video
              src="/insertnewdomain-1.mov"
              alt="Inserting New Domains"
              className="my-4 rounded shadow-lg video w-full"
              autoPlay
              loop
              controls
              muted
            />
          </div>
          <p className="p-4 w-1/2">
            Users can currently submit a new domain and subdomain into dynamodb.
            This is what can determine what you upload to, download from, and
            what your chatbot can talk about.
            <br></br> Users need to supply the datasource id, knowledge base id
            and model id from AWS console.
          </p>
        </div>

        {/* Viewing Previous Conversations Section */}
        <div className="info-header">
          <h1
            className="text-2xl font-bold"
            id="ViewPreviousConversationHeader"
          >
            Viewing Previous Conversations
          </h1>
        </div>
        <div className="info-content flex items-center">
          <div className="w-1/2">
            <video
              src="/viewpreviousconvos-1.mov"
              alt="Viewing Previous Conversations"
              className="my-4 rounded shadow-lg video w-full"
              autoPlay
              loop
              muted
              controls
            />
          </div>
          <p className="p-4 w-1/2">
            To save a conversation, after a conversation simply select save
            conversation and type in a name.<br></br>This page enables users to
            view previous conversations they have had with the chatbot. Users
            can filter their selection based on domain and subdomain. This
            information is stored in dynamodb.
          </p>
        </div>
      </div>
    </div>
  );
};

export default protectedRoute(Info);
