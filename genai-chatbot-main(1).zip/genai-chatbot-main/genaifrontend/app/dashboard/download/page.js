"use client";

import protectedRoute from "../../middleware/protectedRoute";
import { get_presignedurl_download } from "../../api_endpoints.tsx";
import { useEffect } from "react";
import { useDashboardContext } from "../context.js";
import { MdCloudDownload, MdInfo } from "react-icons/md";
import JSZip from "jszip";
import { saveAs } from "file-saver";
import React, { useState } from "react";
import { useRouter } from "next/navigation";

const Download = () => {
  const router = useRouter();

  const {
    sessionId,
    setSessionId,
    knowledgeBaseId: contextKnowledgeBaseId,
    setKnowledgeBaseID,
    auditDomain,
    setAuditDomain,
    subDomain,
    setSubDomain,
    savedFileList,
    setSavedFileList,
    messages,
    setMessages,
    conversationName,
    setConversationName,
    domainData,
    setDomainData,
  } = useDashboardContext();
  const handleInfoClick = async (url) => {
    router.push(url);
  };
  const [selectFileList, setSelectFileList] = useState([]);
  const [allSelected, setAllSelected] = useState(false);

  const parseFileKey = (fileKey) => {
    const parts = fileKey.split("/");
    const domain =
      parts[0].charAt(0).toUpperCase() + parts[0].slice(1).toLowerCase();
    const subdomain =
      parts[1].charAt(0).toUpperCase() + parts[1].slice(1).toLowerCase();
    const dateTime = parts[2].split("_")[1];
    const fileName = parts[2].split("_").slice(2).join("_");

    const formattedDateTime = new Date(dateTime).toLocaleString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });

    return { domain, subdomain, fileName, dateTime: formattedDateTime };
  };

  const handleDownload = async (file_key) => {
    try {
      let presigned_url_download_response =
        await get_presignedurl_download(file_key);
      let presigned_url_download =
        presigned_url_download_response["presigned_url"];

      // Trigger the download
      const link = document.createElement("a");
      link.href = presigned_url_download;
      link.target = "_blank"; // This will open the link in a new tab
      link.rel = "noopener noreferrer"; // For security reasons
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error downloading the file:", error);
    }
  };

  const handleDownloadAll = async () => {
    const zip = new JSZip();

    try {
      const promises = selectFileList.map(async (fileEle) => {
        const presigned_url_download_response = await get_presignedurl_download(
          fileEle.file_key,
        );
        const presigned_url_download =
          presigned_url_download_response["presigned_url"];

        const response = await fetch(presigned_url_download);
        if (!response.ok) {
          throw new Error(
            `Failed to fetch ${fileEle.file_key}: ${response.statusText}`,
          );
        }
        const data = await response.blob();
        zip.file(fileEle.file_key, data);
      });

      await Promise.all(promises);

      const zipContent = await zip.generateAsync({ type: "blob" });
      saveAs(zipContent, "files.zip");
    } catch (error) {
      console.error("Error downloading or zipping the files:", error);
    }
  };

  const handleCheckboxChange = (fileKey, checked) => {
    if (checked) {
      setSelectFileList((prevList) => [...prevList, { file_key: fileKey }]);
    } else {
      setSelectFileList((prevList) =>
        prevList.filter((file) => file.file_key !== fileKey),
      );
    }
  };

  const handleSelectAllChange = (checked) => {
    setAllSelected(checked);
    if (checked) {
      setSelectFileList(
        savedFileList.map((fileKey) => ({ file_key: fileKey })),
      );
    } else {
      setSelectFileList([]);
    }
  };

  const isSelected = (fileKey) =>
    selectFileList.some((file) => file.file_key === fileKey);

  useEffect(() => { }, []);

  return (
    <div className="h-full px-12 pt-10">
      <div className="flex justify-between" style={{ height: "7%" }}>
        <div
          className="flex items-center font-light text-left px-4 py-3 hover:underline cursor-pointer"
          onClick={() => handleInfoClick("/info")}
        >
          <MdInfo className="mr-2" />
        </div>
        <div className="text-3xl w-1/2">Download File</div>
        <div id="header-buttons" className="flex justify-end w-1/2">
          <div className="w-1/3">
            <label
              className="flex justify-center items-center mb-2 text-sm font-light text-gray-900 cursor-pointer bg-black text-white text-center py-4"
              onClick={() => handleDownloadAll()}
            >
              <div>
                <MdCloudDownload className="text-2xl" />
              </div>
              <div className="ml-2 text-lg font-extralight">Download All</div>
            </label>
          </div>
        </div>
      </div>
      <div
        className="mt-8"
        id="file-upload-table"
        style={{ height: "85%", maxWidth: "95%", overflow: "hidden" }}
      >
        {/*Header Row*/}
        <div
          className="text-sm flex items-center border-y-2"
          style={{ height: "10%", minWidth: "700px" }}
        >
          <div className="pr-12" id="checkbox-header" style={{ width: "5%" }}>
            <input
              id="select-all-checkbox"
              type="checkbox"
              className="bg-gray-100 border-gray-300 rounded focus:ring-none dark:bg-gray-700"
              checked={allSelected}
              onChange={(e) => handleSelectAllChange(e.target.checked)}
            />
          </div>
          <div
            className="text-gray-400"
            id="domain-subdomain-header"
            style={{ width: "30%" }}
          >
            DOMAIN/SUBDOMAIN
          </div>
          <div
            className="text-gray-400"
            id="file-name-header"
            style={{ width: "35%" }}
          >
            FILE NAME
          </div>
          <div
            className="text-gray-400"
            id="date-header"
            style={{ width: "30%" }}
          >
            DATE
          </div>
        </div>
        {/*Table Body*/}
        <div
          className="overflow-y-scroll pb-4"
          id="uploaded-files-list"
          style={{ height: "92%", minWidth: "700px" }}
        >
          {savedFileList.map((fileKey) => {
            const { domain, subdomain, fileName, dateTime } =
              parseFileKey(fileKey);
            return (
              <div
                className={`text-sm flex items-center border-b-2 cursor-pointer hover:bg-gray-200 ${isSelected(fileKey) ? "bg-gray-100" : "bg-white"
                  }`}
                style={{ height: "10%", minWidth: "700px" }}
                key={fileKey}
                onClick={() => handleDownload(fileKey)}
              >
                <div className="pr-12" style={{ width: "5%" }}>
                  <input
                    type="checkbox"
                    className="bg-gray-100 border-gray-300 rounded focus:ring-none dark:bg-gray-700"
                    checked={isSelected(fileKey)}
                    onChange={(e) =>
                      handleCheckboxChange(fileKey, e.target.checked)
                    }
                    onClick={(e) => e.stopPropagation()} // Prevent row click when checkbox is clicked
                  />
                </div>
                <div className="text-gray-700" style={{ width: "30%" }}>
                  {domain}/{subdomain}
                </div>
                <div className="text-gray-700" style={{ width: "35%" }}>
                  {fileName}
                </div>
                <div className="text-gray-700" style={{ width: "30%" }}>
                  {dateTime}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default protectedRoute(Download);
