"use client";

import React, { createContext, useContext, useState } from "react";

const DashboardContext = createContext();

export const useDashboardContext = () => useContext(DashboardContext);

export const DashboardProvider = ({ children }) => {
  const [sessionId, setSessionId] = useState(null);
  const [knowledgeBaseId, setKnowledgeBaseID] = useState("");
  const [auditDomain, setAuditDomain] = useState(null);
  const [subDomain, setSubDomain] = useState(null);
  const [savedFileList, setSavedFileList] = useState([]);
  const [messages, setMessages] = useState([]);
  const [conversationName, setConversationName] = useState("");
  const [domainData, setDomainData] = useState({});

  const value = {
    sessionId,
    setSessionId,
    knowledgeBaseId,
    setKnowledgeBaseID,
    auditDomain,
    setAuditDomain,
    subDomain,
    setSubDomain,
    savedFileList,
    setSavedFileList,
    messages,
    setMessages,
    conversationName,
    setConversationName,
    domainData,
    setDomainData,
  };

  return (
    <DashboardContext.Provider value={value}>
      {children}
    </DashboardContext.Provider>
  );
};
