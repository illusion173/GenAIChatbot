"use client";

import protectedRoute from "../middleware/protectedRoute";

import Sidebar from "../ui/dashboard/sidebar/Sidebar";

const Layout = ({ children }) => {
  return (
    <div className="flex h-full">
      <div className="w-3/12">
        <Sidebar />
      </div>
      <div className="w-full">{children}</div>
    </div>
  );
};

export default protectedRoute(Layout);
