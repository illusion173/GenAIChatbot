"use client";
import React, { useState, useEffect, useRef } from "react";
import { MdArrowUpward } from "react-icons/md";
import {
  get_knowledge_base_API,
  chatbot,
  get_presignedurl_download,
  getDomainsSubDomains,
} from "../api_endpoints";
import { useDashboardContext } from "./context";

const capitalize = (s) => s.charAt(0).toUpperCase() + s.slice(1);

const Dashboard = () => {
  const {
    sessionId,
    setSessionId,
    knowledgeBaseId,
    setKnowledgeBaseID,
    auditDomain,
    setAuditDomain,
    subDomain,
    setSubDomain,
    savedFileList,
    setSavedFileList,
    messages,
    setMessages,
    domainData,
    setDomainData,
  } = useDashboardContext();

  useEffect(() => {
    const getDomainDataForDashboard = async () => {
      let response = await getDomainsSubDomains();
      setDomainData(response);
    };

    getDomainDataForDashboard();
  }, []);

  const [inputMessage, setInputMessage] = useState("");
  const [selectedCitation, setSelectedCitation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const addFileKeyToList = (file_key) => {
    setSavedFileList((prevFileList) => [...prevFileList, file_key]);
  };

  const handleDownloadNow = async (file_key) => {
    try {
      let presigned_url_download_response =
        await get_presignedurl_download(file_key);
      let presigned_url_download =
        presigned_url_download_response["presigned_url"];

      // Trigger the download
      const link = document.createElement("a");
      link.href = presigned_url_download;
      link.target = "_blank"; // This will open the link in a new tab
      link.rel = "noopener noreferrer"; // For security reasons
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error downloading the file:", error);
    }
  };

  const Modal = ({ citation, onClose }) => {
    const prettyPrintJson = (text) => {
      try {
        const json = JSON.parse(text);
        return JSON.stringify(json, null, 2); // Pretty print with 2 spaces of indentation
      } catch (error) {
        return text; // If it's not valid JSON, return the text as-is
      }
    };
    return (
      <div className="fixed inset-0 flex items-center justify-center z-50 bg-gray-900 bg-opacity-50">
        <div className="bg-white p-6 rounded-lg shadow-lg max-w-3xl w-full max-h-full">
          <h2 className="text-lg font-bold mb-4">Citation</h2>
          <div>
            <strong>File Key:</strong> {citation.file_key}
          </div>
          <div>
            <strong>Cited Text:</strong>
            <div className="code-block overflow-y-auto max-h-96 p-2 bg-gray-100 border rounded">
              <pre style={{ wordWrap: "break-word", whiteSpace: "pre-line" }}>
                {prettyPrintJson(citation.cited_text)}
              </pre>
            </div>
          </div>
          <div className="mt-4 flex justify-between">
            <button
              className="bg-blue-500 text-white px-4 py-2 rounded mr-2"
              onClick={onClose}
            >
              Close
            </button>
            <button
              className="bg-blue-500 text-white px-4 py-2 rounded mr-2"
              onClick={() => addFileKeyToList(citation.file_key)}
            >
              Add To Download List
            </button>
            <button
              className="bg-blue-500 text-white px-4 py-2 rounded"
              onClick={() => handleDownloadNow(citation.file_key)}
            >
              Download Now
            </button>
          </div>
        </div>
      </div>
    );
  };

  const handleChatBot = async () => {
    if (!inputMessage.trim()) return;

    if (!subDomain) {
      setErrorMessage("Please select both a domain and a subdomain.");
      return;
    }

    setErrorMessage(""); // Clear error message if validation passes

    // Put entry into previous chat records
    const newUserMessage = { text: inputMessage, from: "user" };
    setMessages((prevMessages) => [...prevMessages, newUserMessage]);
    // reset the input message
    setInputMessage("");
    setLoading(true); // Set loading to true when the API call is initiated

    try {
      let chat_bot_response = await chatbot(
        knowledgeBaseId,
        inputMessage,
        sessionId,
      );
      console.log("CHATBOT RESPONSE");
      console.log(chat_bot_response);

      let knowledge_base_id = chat_bot_response["knowledge_base_id"];
      console.log(knowledge_base_id);
      setKnowledgeBaseID(knowledge_base_id);

      let session_id = chat_bot_response["session_id"];
      console.log(session_id);
      setSessionId(session_id);

      let chatbot_answer = chat_bot_response["answer"];
      console.log(chatbot_answer);

      const newChatBotMessage = {
        text: chatbot_answer,
        from: "bot",
        related_citations: null,
      };

      let related_citations = chat_bot_response["related_citations"];
      if (related_citations) {
        newChatBotMessage.related_citations = [];
        related_citations.forEach((citation, index) => {
          if (citation.cited_text.trim()) {
            // Check if cited_text is not empty
            let new_related_citation = {
              file_key: citation.file_key,
              cited_text: citation.cited_text,
            };
            newChatBotMessage.related_citations.push(new_related_citation);
            console.log(`Citation ${index + 1}:`);
            console.log("File Key:", citation.file_key);
            console.log("Cited Text:", citation.cited_text);
          }
        });
      } else {
        console.log("No related citations available.");
      }

      setMessages((prevMessages) => [...prevMessages, newChatBotMessage]);
    } catch (error) {
      console.error("Error sending message to chatbot:", error);
    } finally {
      setLoading(false); // Set loading to false once the API call is completed
    }
  };

  const handleDomainChange = (e) => {
    const selectedDomain = e.target.value;
    setAuditDomain(selectedDomain);
    setSubDomain(""); // Reset subdomain when domain changes
  };

  const handleSubDomainChange = async (e) => {
    const selectedSubDomain = e.target.value;
    setSubDomain(selectedSubDomain);

    console.log("SELECTED SUBDOMAIN");
    console.log(selectedSubDomain);
    if (selectedSubDomain) {
      try {
        let knowledgeBaseId = await get_knowledge_base_API(
          auditDomain,
          selectedSubDomain,
        );
        console.log(knowledgeBaseId);

        if (knowledgeBaseId["knowledge_base_id"] != "") {
          setKnowledgeBaseID(knowledgeBaseId["knowledge_base_id"]);
        }

        console.log(
          `Knowledge Base ID for ${auditDomain} - ${selectedSubDomain}: ${knowledgeBaseId["knowledge_base_id"]}`,
        );
      } catch (error) {
        console.error("Error while retrieving knowledge base id:", error);
      }
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div
        id="message-box"
        className="h-5/6 flex flex-col px-48 pt-12 overflow-y-scroll"
      >
        <div className="text-justify bg-gray-100 p-8 rounded-xl mb-4">
          Welcome to the Audit Assistance Chatbot! Hi there! I'm here to help
          with all your audit-related queries. Whether you need information,
          guidance, or have specific questions, feel free to type in your
          concerns. I'm happy to assist you!
        </div>
        {messages.map((message, index) => (
          <div
            key={index}
            className={`text-justify bg-gray-100 p-8 rounded-xl mb-4 ${
              message.from === "user"
                ? " border border-blue-500"
                : " border border-green-500"
            }`}
          >
            {message.text.split("\n").map((line, i) => (
              <React.Fragment key={i}>
                {line}
                <br />
              </React.Fragment>
            ))}
            {message.related_citations && (
              <div className="flex mt-2 space-x-2">
                {message.related_citations.map((citation, i) => (
                  <button
                    key={i}
                    className="bg-blue-500 text-white px-4 py-2 rounded"
                    onClick={() => setSelectedCitation(citation)}
                  >
                    View Citation {i + 1}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div id="input-section" className="h-1/6 flex justify-center">
        <div
          className="flex justify-between items-center h-14 w-1/2 px-4 rounded-3xl"
          style={{ backgroundColor: "#f0f3f4" }}
        >
          <input
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Message GenAI ChatBot"
            className="w-full focus:outline-none mr-2"
            style={{ backgroundColor: "#f0f3f4" }}
            disabled={loading} // Disable input when loading
          />
          <button
            className="bg-white p-2 rounded-full"
            onClick={handleChatBot}
            disabled={loading} // Disable button when loading
          >
            {loading ? (
              <div className="loader">Loading...</div>
            ) : (
              <MdArrowUpward className="text-2xl" />
            )}
          </button>
        </div>
      </div>
      {errorMessage && (
        <div className="text-red-500 text-center mt-2">{errorMessage}</div>
      )}
      <div className="flex justify-center">
        Select a Domain/Subdomain to Begin.
      </div>

      <div id="dropdowns" className="flex justify-center py-4">
        <select
          value={auditDomain}
          onChange={handleDomainChange}
          className="mr-4 p-2 rounded"
        >
          <option value="">Select Audit Domain</option>
          {Object.keys(domainData).map((domain) => (
            <option key={domain} value={domain}>
              {capitalize(domain)}
            </option>
          ))}
        </select>
        <select
          value={subDomain}
          onChange={handleSubDomainChange}
          className="p-2 rounded"
          disabled={!auditDomain}
        >
          <option value="">Select Sub Domain</option>
          {auditDomain &&
            domainData[auditDomain].map((sub) => (
              <option key={sub} value={sub}>
                {capitalize(sub)}
              </option>
            ))}
        </select>
      </div>

      {selectedCitation && (
        <Modal
          citation={selectedCitation}
          onClose={() => setSelectedCitation(null)}
        />
      )}
    </div>
  );
};

export default Dashboard;
