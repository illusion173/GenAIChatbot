"use client";

import { useState, useEffect, useRef } from "react";
import {
  Dialog,
  DialogBackdrop,
  DialogPanel,
  DialogTitle,
} from "@headlessui/react";
import { MdCloudUpload, MdDelete, MdInfo } from "react-icons/md";
import protectedRoute from "@/app/middleware/protectedRoute";
import { useRouter } from "next/navigation";

import {
  assignUserObjectTags,
  getDomainsSubDomains,
  get_presignedurl_upload,
} from "../../api_endpoints";
import "./upload.css";
const Notification = ({ notifications, removeNotification }) => {
  useEffect(() => {
    notifications.forEach((notification) => {
      const timer = setTimeout(() => {
        removeNotification(notification.id);
      }, 3000);
      return () => clearTimeout(timer);
    });
  }, [notifications, removeNotification]);

  return (
    <div className="notification-container">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className={`notification ${notification.type}`}
        >
          <span>{notification.message}</span>
          <button onClick={() => removeNotification(notification.id)}>x</button>
        </div>
      ))}
    </div>
  );
};

const Upload = () => {
  const router = useRouter();

  const [open, setOpen] = useState(false);
  const [selectedDomain, setSelectedDomain] = useState("");
  const [selectedSubdomain, setSelectedSubdomain] = useState("");
  const [uploadFiles, setUploadFiles] = useState([]);
  const [domainSubDomainData, setDomainSubDomainData] = useState({});
  const [availableSubdomains, setAvailableSubdomains] = useState([]);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [filesSelected, setFilesSelected] = useState(false);
  const [filesList, setFilesList] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const fileInputRef = useRef(null);

  const [fileTags, setFileTags] = useState({
    phi: false,
    pii: false,
    summarize: false,
    image_type: null,
  });

  const addNotification = (message, type) => {
    const id = new Date().getTime();
    setNotifications((prevNotifications) => [
      ...prevNotifications,
      { id, message, type },
    ]);
  };

  const removeNotification = (id) => {
    setNotifications((prevNotifications) =>
      prevNotifications.filter((notification) => notification.id !== id),
    );
  };

  const handleUpload = async () => {
    if (uploadFiles.length === 0) return;

    for (const file of uploadFiles) {
      const fileName = file.name;
      const fileType = file.type;
      const fileKey = `${selectedDomain}/${selectedSubdomain}/${fileName}`;

      let file_url_response = await get_presignedurl_upload(
        fileName,
        selectedDomain,
        selectedSubdomain,
      );

      let s3_presigned_url = file_url_response["presigned_url"];

      try {
        // Upload file to S3 using the presigned URL
        const uploadResponse = await fetch(s3_presigned_url, {
          method: "PUT",
          headers: {
            "Content-Type": fileType,
          },
          body: file,
        });

        if (uploadResponse.ok) {
          console.log(`File ${fileName} uploaded successfully`);

          // Add file details to filesList
          const newFile = {
            fileName: fileName,
            uploadDate: new Date().toISOString().split("T")[0],
            fileType: selectedDomain,
            fileExtension: fileName.split(".").pop(),
          };
          setFilesList((prevFilesList) => [...prevFilesList, newFile]);

          addNotification(`File ${fileName} uploaded successfully`, "success");
        } else {
          console.error(`Failed to upload file ${fileName}`);
          addNotification(`Failed to upload file ${fileName}`, "error");
        }
      } catch (error) {
        console.error(`Error while uploading file ${fileName}:`, error);
        addNotification(
          `Error while uploading file ${fileName}: ${error.message}`,
          "error",
        );
      }

      // Now we need to assign tags to the file
      let phi_tag = fileTags["phi"];
      let pii_tag = fileTags["pii"];
      let summarize_tag = fileTags["summarize"];
      let imagetype_tag = fileTags["image_type"];

      let tag_assignment_response = await assignUserObjectTags(
        fileKey,
        phi_tag,
        pii_tag,
        summarize_tag,
        imagetype_tag,
      );
      console.log(tag_assignment_response);
    }
  };
  const handleInfoClick = async (url) => {
    router.push(url);
  };
  useEffect(() => {
    if (filesSelected) {
      handleUpload();
      setFilesSelected(false);
    }
  }, [filesSelected]);

  useEffect(() => {
    const getDomainsSubdomainsForUploading = async () => {
      let response = await getDomainsSubDomains();
      console.log(response);
      setDomainSubDomainData(response);
    };

    getDomainsSubdomainsForUploading();
  }, []);

  useEffect(() => {
    if (selectedDomain) {
      setAvailableSubdomains(domainSubDomainData[selectedDomain] || []);
    } else {
      setAvailableSubdomains([]);
    }
  }, [selectedDomain, domainSubDomainData]);

  return (
    <>
      <Notification
        notifications={notifications}
        removeNotification={removeNotification}
      />
      <div className="h-full px-12 pt-10">
        <div className="flex justify-between" style={{ height: "7%" }}>
          <div
            className="flex items-center font-light text-left px-4 py-3 hover:underline cursor-pointer"
            onClick={() => handleInfoClick("/info")}
          >
            <MdInfo className="mr-2" />
          </div>
          <div className="text-3xl w-1/2">Upload File</div>

          <div id="header-buttons" className="flex justify-end w-1/2">
            <div className="mr-4 w-1/3">
              <label
                className="flex justify-center items-center mb-2 text-sm font-light text-gray-900 cursor-pointer bg-red-600 text-white text-center py-4"
                htmlFor="file_input"
              >
                <div>
                  <MdDelete className="text-2xl" />
                </div>
                <div className="ml-2 text-lg font-extralight">Delete</div>
              </label>
              <input
                className="block text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 hidden"
                id="file_input"
                type="file"
                multiple
                onChange={(e) => setUploadFiles([...e.target.files])}
              />
            </div>
            <div className="w-1/3">
              <label
                className="flex justify-center items-center mb-2 text-sm font-light text-gray-900 cursor-pointer bg-black text-white text-center py-4"
                onClick={() => {
                  setOpen(true);
                }}
              >
                <div>
                  <MdCloudUpload className="text-2xl" />
                </div>
                <div className="ml-2 text-lg font-extralight">Upload file</div>
              </label>
            </div>
          </div>
        </div>
        <div className="mt-8" id="file-upload-table" style={{ height: "85%" }}>
          <div
            className="text-sm flex items-center border-y-2"
            style={{ height: "8%" }}
          >
            <div className="pr-12" id="checkbox-header" style={{ width: "5%" }}>
              <input
                id="default-checkbox"
                type="checkbox"
                value=""
                className="bg-gray-100 border-gray-300 rounded focus:ring-none dark:bg-gray-700"
              />
            </div>
            <div
              className="text-gray-400"
              id="file-name-header"
              style={{ width: "44.4%" }}
            >
              File Name
            </div>
            <div
              className="text-gray-400"
              id="file-name-header"
              style={{ width: "20%" }}
            >
              Upload Date
            </div>
            <div className="text-gray-400" id="" style={{ width: "20%" }}>
              File Type
            </div>
            <div
              className="text-gray-400 text-right pr-4"
              id=""
              style={{ width: "10%" }}
            >
              Extension
            </div>
          </div>
          <div
            className="overflow-y-scroll pb-4"
            id="uploaded-files-list"
            style={{ height: "92%" }}
          >
            {filesList.map((fileEle, index) => (
              <div className="flex py-4" key={index}>
                <div id="checkbox-header" style={{ width: "5%" }}>
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="bg-gray-100 border-gray-300 rounded focus:ring-none dark:bg-gray-700"
                  />
                </div>
                <div className="text-gray-700" style={{ width: "45%" }}>
                  {fileEle.fileName}
                </div>
                <div className="text-gray-700" style={{ width: "20%" }}>
                  {fileEle.uploadDate}
                </div>
                <div className="text-gray-700" style={{ width: "20%" }}>
                  {fileEle.fileType}
                </div>
                <div
                  className="text-gray-700 text-right pr-2"
                  style={{ width: "10%" }}
                >
                  {fileEle.fileExtension}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <Dialog open={open} onClose={setOpen} className="relative z-10">
        <DialogBackdrop
          transition
          className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity data-[closed]:opacity-0 data-[enter]:duration-300 data-[leave]:duration-200 data-[enter]:ease-out data-[leave]:ease-in"
        />

        <div className="fixed inset-0 z-10 w-screen overflow-y-auto">
          <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <DialogPanel
              transition
              className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all data-[closed]:translate-y-4 data-[closed]:opacity-0 data-[enter]:duration-300 data-[leave]:duration-200 data-[enter]:ease-out data-[leave]:ease-in sm:my-8 sm:w-full sm:max-w-lg data-[closed]:sm:translate-y-0 data-[closed]:sm:scale-95"
            >
              <div className="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                <div
                  className="flex items-center font-light text-left px-4 py-3 hover:underline cursor-pointer"
                  onClick={() => handleInfoClick("/info#UploadInfoHeader")}
                >
                  <MdInfo className="mr-2" />
                </div>
                {currentSlide === 0 && (
                  <>
                    <div className="sm:flex sm:items-start">
                      <div className="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                        <DialogTitle
                          as="h3"
                          className="text-base font-semibold leading-6 text-gray-900"
                        >
                          Select the Domain and Subdomain
                        </DialogTitle>
                        <div className="mt-4 flex">
                          <div className="mr-4">
                            {Object.keys(domainSubDomainData).map((domain) => (
                              <div
                                className="flex items-center mb-4"
                                key={domain}
                              >
                                <input
                                  id={domain}
                                  type="radio"
                                  value={domain}
                                  name="domain"
                                  checked={selectedDomain === domain}
                                  onChange={() => setSelectedDomain(domain)}
                                  className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 dark:bg-gray-700 dark:border-gray-600"
                                />
                                <label
                                  htmlFor={domain}
                                  className="ms-2 text-sm font-medium"
                                >
                                  {domain.charAt(0).toUpperCase() +
                                    domain.slice(1)}
                                </label>
                              </div>
                            ))}
                          </div>
                          <div className="ml-4">
                            {availableSubdomains.map((subdomain) => (
                              <div
                                className="flex items-center mb-4"
                                key={subdomain}
                              >
                                <input
                                  id={subdomain}
                                  type="radio"
                                  value={subdomain}
                                  name="subdomain"
                                  checked={selectedSubdomain === subdomain}
                                  onChange={() =>
                                    setSelectedSubdomain(subdomain)
                                  }
                                  className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 dark:bg-gray-700 dark:border-gray-600"
                                />
                                <label
                                  htmlFor={subdomain}
                                  className="ms-2 text-sm font-medium"
                                >
                                  {subdomain.charAt(0).toUpperCase() +
                                    subdomain.slice(1)}
                                </label>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
                      <button
                        type="button"
                        className="mt-3 inline-flex w-full justify-center rounded-md bg-black px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-800 sm:mt-0 sm:w-auto"
                        onClick={() => setCurrentSlide(1)}
                      >
                        Next
                      </button>
                    </div>
                  </>
                )}
                {currentSlide === 1 && (
                  <>
                    <div className="sm:flex sm:items-start">
                      <div className="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                        <DialogTitle
                          as="h3"
                          className="text-base font-semibold leading-6 text-gray-900"
                        >
                          Select Tags
                        </DialogTitle>
                        <div className="ml-4 mt-4">
                          <label className="inline-flex items-center">
                            <input
                              type="checkbox"
                              className="form-checkbox"
                              checked={fileTags.phi}
                              onChange={(e) =>
                                setFileTags({
                                  ...fileTags,
                                  phi: e.target.checked,
                                })
                              }
                            />
                            <span className="ml-2">PHI</span>
                          </label>
                          <label className="inline-flex items-center ml-4">
                            <input
                              type="checkbox"
                              className="form-checkbox"
                              checked={fileTags.pii}
                              onChange={(e) =>
                                setFileTags({
                                  ...fileTags,
                                  pii: e.target.checked,
                                })
                              }
                            />
                            <span className="ml-2">PII</span>
                          </label>
                          <label className="inline-flex items-center ml-4">
                            <input
                              type="checkbox"
                              className="form-checkbox"
                              checked={fileTags.summarize}
                              onChange={(e) =>
                                setFileTags({
                                  ...fileTags,
                                  summarize: e.target.checked,
                                })
                              }
                            />
                            <span className="ml-2">Summarize</span>
                          </label>
                          <label className="inline-flex items-center ml-4">
                            <input
                              type="checkbox"
                              className="form-checkbox"
                              checked={fileTags.image_type !== null}
                              onChange={(e) =>
                                setFileTags({
                                  ...fileTags,
                                  image_type: e.target.checked
                                    ? "document"
                                    : null,
                                })
                              }
                            />
                            <span className="ml-2">Upload Images</span>
                          </label>
                        </div>
                        {fileTags.image_type && (
                          <div className="ml-4 mt-4">
                            <label className="inline-flex items-center">
                              <input
                                type="radio"
                                name="image_type"
                                value="document"
                                checked={fileTags.image_type === "document"}
                                onChange={(e) =>
                                  setFileTags({
                                    ...fileTags,
                                    image_type: e.target.value,
                                  })
                                }
                              />
                              <span className="ml-2">Document</span>
                            </label>
                            <label className="inline-flex items-center ml-4">
                              <input
                                type="radio"
                                name="image_type"
                                value="expense"
                                checked={fileTags.image_type === "expense"}
                                onChange={(e) =>
                                  setFileTags({
                                    ...fileTags,
                                    image_type: e.target.value,
                                  })
                                }
                              />
                              <span className="ml-2">Expense</span>
                            </label>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="bg-gray-50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6">
                      <button
                        type="button"
                        className="mt-3 inline-flex w-full justify-center rounded-md bg-black px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-800 sm:mt-0 sm:w-auto"
                        onClick={() => fileInputRef.current.click()}
                      >
                        Upload
                      </button>
                      <button
                        type="button"
                        className="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto"
                        onClick={() => setCurrentSlide(0)}
                      >
                        Back
                      </button>
                    </div>
                  </>
                )}
                <input
                  type="file"
                  ref={fileInputRef}
                  style={{ display: "none" }}
                  multiple
                  onChange={(e) => {
                    setUploadFiles([...e.target.files]);
                    setFilesSelected(true);
                  }}
                />
              </div>
            </DialogPanel>
          </div>
        </div>
      </Dialog>
    </>
  );
};

export default protectedRoute(Upload);
