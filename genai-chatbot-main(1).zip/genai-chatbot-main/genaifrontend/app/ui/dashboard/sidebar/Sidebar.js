"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import { useDashboardContext } from "../../../dashboard/context.js";
import { Amplify, Auth } from "aws-amplify";
import {
  saveConversationAPI,
  getConversationHistoryList,
  getConversationAPI,
  insertNewDomainAPI,
  getDomainsSubDomains,
} from "../../../api_endpoints.tsx";
import config from "../../../../src/amplifyconfiguration.json";
Amplify.configure(config);

import {
  MdFileUpload,
  MdFileDownload,
  MdLogout,
  MdList,
  MdSave,
  MdInfo,
  MdInsertChart,
  MdAdd,
  MdRemove,
} from "react-icons/md";
const capitalize = (s) => s.charAt(0).toUpperCase() + s.slice(1);

const Sidebar = () => {
  const router = useRouter();
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
  const [newConversationName, setNewConversationName] = useState("");
  const [isListModalOpen, setIsListModalOpen] = useState(false);
  const [isInsertDomainModalOpen, setIsInsertDomainModalOpen] = useState(false);
  const [selectedAuditDomain, setSelectedAuditDomain] = useState("");
  const [selectedSubDomain, setSelectedSubDomain] = useState("");
  const [conversationHistory, setConversationHistory] = useState([]);
  const [isLoadingConversation, setIsLoadingConversation] = useState(false);
  const [newDomain, setNewDomain] = useState("");
  const [newSubDomain, setNewSubDomain] = useState("");
  const [dataSourceIds, setDataSourceIds] = useState([""]);
  const [genPrompt, setGenPrompt] = useState("");
  const [invokePrompt, setInvokePrompt] = useState("");
  const [knowledgeBaseId, setKnowledgeBaseId] = useState("");
  const [modelId, setModelId] = useState("");

  const {
    sessionId,
    setSessionId,
    knowledgeBaseId: contextKnowledgeBaseId,
    setKnowledgeBaseID,
    auditDomain,
    setAuditDomain,
    subDomain,
    setSubDomain,
    savedFileList,
    setSavedFileList,
    messages,
    setMessages,
    conversationName,
    setConversationName,
    domainData,
    setDomainData,
  } = useDashboardContext();
  useEffect(() => {
    const getDomainDataForDashboard = async () => {
      let response = await getDomainsSubDomains();
      setDomainData(response);
    };

    getDomainDataForDashboard();
  }, []);
  async function getUserEmail() {
    try {
      const user = await Auth.currentAuthenticatedUser();
      const email = user.attributes.email;
      console.log("User email:", email);
      return email;
    } catch (error) {
      console.error("Error fetching user email:", error);
      return null;
    }
  }

  const listHistoricalConversations = async () => {
    let user_email = await getUserEmail();

    let query_string_params = { user_email };

    if (selectedAuditDomain) {
      query_string_params.domain = selectedAuditDomain;
    }
    if (selectedSubDomain) {
      query_string_params.sub_domain = selectedSubDomain;
    }
    try {
      let conversationHistoryResponse =
        await getConversationHistoryList(query_string_params);
      console.log(conversationHistoryResponse);
      setConversationHistory(conversationHistoryResponse);
    } catch (e) {
      alert(
        "Error while submitting a request for historical conversations. Try again later.",
      );
      console.log(e);
    }
  };

  useEffect(() => {
    if (isListModalOpen) {
      listHistoricalConversations();
    }
  }, [selectedAuditDomain, selectedSubDomain, isListModalOpen]);

  const saveConversation = async (name) => {
    setConversationName(name);

    let user_email = await getUserEmail();
    try {
      let saveConversationAPIResponse = await saveConversationAPI(
        auditDomain,
        subDomain,
        name, // Use the name passed to the function
        contextKnowledgeBaseId,
        sessionId,
        messages,
        savedFileList,
        user_email,
      );
      setIsSaveModalOpen(false);
    } catch (e) {
      alert(
        "Error while submitting request for saveConversation. Try again later.",
      );
      console.log(e);
    }
  };

  const handleSaveClick = () => {
    if (!sessionId) {
      alert(
        "No conversation has happened yet.\nPlease start a conversation before saving.",
      );
      return;
    }
    setIsSaveModalOpen(true);
  };

  const handleListClick = () => {
    setIsListModalOpen(true);
  };

  const handleInsertDomainClick = () => {
    setIsInsertDomainModalOpen(true);
  };

  const handleInsertDomainSubmit = async () => {
    // Prepare data
    const new_insert_domain_data = {
      domain_id: Math.floor(Math.random() * 50000000) + 1,
      audit_domain: newDomain.toLowerCase(),
      data_source_ids: dataSourceIds,
      gen_prompt: genPrompt,
      invoke_prompt: invokePrompt,
      knowledge_base_id: knowledgeBaseId,
      model_id: modelId,
      subdomain: newSubDomain.toLowerCase(),
    };
    let response = await insertNewDomainAPI(new_insert_domain_data);
    console.log(response);

    // Close modal
    setIsInsertDomainModalOpen(false);
  };

  const handleModalSubmit = () => {
    saveConversation(newConversationName);
    setIsSaveModalOpen(false);
  };

  const handleSignOut = async () => {
    await Auth.signOut();
    router.push("/");
  };

  const handleInfoClick = async (url) => {
    router.push(url);
  };

  const getConversation = async (selected_conversation_id) => {
    console.log(selected_conversation_id);
    setIsLoadingConversation(true); // Set loading state to true
    try {
      let getConversationAPIResponse = await getConversationAPI(
        selected_conversation_id,
      );

      // Assuming the response contains these values:
      const {
        session_id,
        knowledge_base_id,
        audit_domain,
        sub_domain,
        messages,
        saved_file_list,
        conversation_title,
      } = getConversationAPIResponse;

      // Set the context values
      setSessionId(session_id);
      setKnowledgeBaseID(knowledge_base_id);
      setAuditDomain(audit_domain);
      setSubDomain(sub_domain);
      setMessages(messages);
      setSavedFileList(saved_file_list);
      setConversationName(conversation_title);

      setIsListModalOpen(false); // Close the modal upon success
    } catch (e) {
      alert(
        "Error while submitting request for getConversation. Try again later.",
      );
      console.log(e);
    } finally {
      setIsLoadingConversation(false); // Set loading state to false
    }
  };

  const addDataSource = () => {
    if (dataSourceIds.length < 5) {
      setDataSourceIds([...dataSourceIds, ""]);
    }
  };

  const removeDataSource = (index) => {
    setDataSourceIds(dataSourceIds.filter((_, i) => i !== index));
  };

  const handleDataSourceChange = (index, value) => {
    const newDataSourceIds = [...dataSourceIds];
    newDataSourceIds[index] = value;
    setDataSourceIds(newDataSourceIds);
  };

  return (
    <div
      className="h-full flex flex-col justify-between"
      style={{ backgroundColor: "#f0f3f4" }}
    >
      <div>
        <Link href={"/dashboard"}>
          <div className="text-md px-8 py-8">
            <span className="text-2xl">GenAI</span> ChatBot
          </div>
        </Link>
        <ul className="px-4">
          <Link
            href="/dashboard/upload"
            className="flex items-center font-light text-left px-4 py-3 hover:bg-black hover:text-white rounded-3xl w-full"
          >
            <MdFileUpload className="text-xl mr-2" />
            Upload File
          </Link>
          <Link
            href="/dashboard/download"
            className="flex items-center font-light text-left px-4 py-3 hover:bg-black hover:text-white rounded-3xl w-full"
          >
            <MdFileDownload className="text-xl mr-2" />
            View Downloads
          </Link>
          <button
            onClick={handleSaveClick}
            className="flex items-center font-light text-left px-4 py-3 hover:bg-black hover:text-white rounded-3xl w-full"
          >
            <MdSave className="text-xl mr-2" />
            <div>Save Current Conversation</div>
          </button>
          <button
            onClick={handleListClick}
            className="flex items-center font-light text-left px-4 py-3 hover:bg-black hover:text-white rounded-3xl w-full"
          >
            <MdList className="text-xl mr-2" />
            View Previous Conversations
          </button>
          <button
            onClick={handleInsertDomainClick}
            className="flex items-center font-light text-left px-4 py-3 hover:bg-black hover:text-white rounded-3xl w-full"
          >
            <MdInsertChart className="text-xl mr-2" /> Insert New Domain
          </button>
        </ul>
      </div>
      <div className="py-5 px-4">
        <div
          className="flex items-center font-light text-left px-4 py-3 hover:underline cursor-pointer"
          onClick={() => handleInfoClick("/info")}
        >
          <MdInfo className="mr-2" />
          Information
        </div>
        <div
          className="flex items-center font-light text-left px-4 py-3 hover:underline cursor-pointer"
          onClick={handleSignOut}
        >
          <MdLogout className="mr-2" />
          Log Out
        </div>
      </div>
      {isSaveModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-600 bg-opacity-50">
          <div className="bg-white p-8 rounded-md shadow-md">
            <div className="flex justify-between items-center">
              <h2 className="text-xl mb-4">Enter Conversation Name</h2>
            </div>
            <input
              type="text"
              value={newConversationName}
              onChange={(e) => setNewConversationName(e.target.value)}
              className="border border-gray-300 p-2 mb-4 w-full"
            />
            <button
              onClick={handleModalSubmit}
              className="bg-blue-500 text-white px-4 py-2 rounded-md"
            >
              Save
            </button>
            <button
              onClick={() => setIsSaveModalOpen(false)}
              className="ml-2 bg-gray-500 text-white px-4 py-2 rounded-md"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
      {isListModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-600 bg-opacity-50">
          <div className="bg-white p-8 rounded-md shadow-md w-3/4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl mb-4">Select a Historical Conversation</h2>
              <MdInfo
                className="text-xl cursor-pointer"
                onClick={() =>
                  handleInfoClick("/info#ViewPreviousConversationHeader")
                }
              />
            </div>
            <div className="mb-4">
              <label className="block mb-2">Audit Domain</label>
              <select
                value={selectedAuditDomain}
                onChange={(e) => setSelectedAuditDomain(e.target.value)}
                className="border border-gray-300 p-2 w-full"
              >
                <option value="">Select Audit Domain</option>
                {Object.keys(domainData).map((domain) => (
                  <option key={domain} value={domain}>
                    {capitalize(domain)}
                  </option>
                ))}
              </select>
            </div>
            <div className="mb-4">
              <label className="block mb-2">Sub Domain</label>
              <select
                value={selectedSubDomain}
                onChange={(e) => setSelectedSubDomain(e.target.value)}
                className="border border-gray-300 p-2 w-full"
                disabled={!selectedAuditDomain}
              >
                <option value="">Select Sub Domain</option>
                {selectedAuditDomain &&
                  domainData[selectedAuditDomain].map((subDomain) => (
                    <option key={subDomain} value={subDomain}>
                      {capitalize(subDomain)}
                    </option>
                  ))}
              </select>
            </div>
            {conversationHistory.length > 0 && (
              <table className="min-w-full bg-white">
                <thead>
                  <tr>
                    <th className="py-2">Conversation Title</th>
                    <th className="py-2">Datetime Submitted</th>
                    <th className="py-2">Audit Domain</th>
                    <th className="py-2">Sub Domain</th>
                    <th className="py-2">First Question</th>
                  </tr>
                </thead>
                <tbody>
                  {conversationHistory.map((conversation, index) => (
                    <tr
                      key={index}
                      className={"table-row"}
                      onClick={() =>
                        getConversation(conversation.conversation_id)
                      }
                    >
                      <td className="border px-4 py-2">
                        {capitalize(conversation.conversation_title)}
                      </td>
                      <td className="border px-4 py-2">
                        {conversation.datetime_submitted}
                      </td>
                      <td className="border px-4 py-2">
                        {capitalize(conversation.audit_domain)}
                      </td>
                      <td className="border px-4 py-2">
                        {capitalize(conversation.sub_domain)}
                      </td>
                      <td className="border px-4 py-2">
                        {conversation.first_question}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            <button
              onClick={() => setIsListModalOpen(false)}
              className="mt-4 bg-gray-500 text-white px-4 py-2 rounded-md"
            >
              Close
            </button>
          </div>
        </div>
      )}
      {isInsertDomainModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-600 bg-opacity-50">
          <div className="bg-white p-8 rounded-md shadow-md">
            <div className="flex justify-between items-center">
              <h2 className="text-xl mb-4">Insert New Domain</h2>
              <MdInfo
                className="text-xl cursor-pointer"
                onClick={() => handleInfoClick("/info#InsertNewDomain")}
              />
            </div>
            <input
              type="text"
              value={newDomain}
              onChange={(e) => setNewDomain(e.target.value)}
              className="border border-gray-300 p-2 mb-4 w-full"
              placeholder="New Domain"
            />
            <input
              type="text"
              value={newSubDomain}
              onChange={(e) => setNewSubDomain(e.target.value)}
              className="border border-gray-300 p-2 mb-4 w-full"
              placeholder="New Sub Domain"
            />
            <input
              type="text"
              value={knowledgeBaseId}
              onChange={(e) => setKnowledgeBaseId(e.target.value)}
              className="border border-gray-300 p-2 mb-4 w-full"
              placeholder="Knowledge Base ID"
            />
            <input
              type="text"
              value={modelId}
              onChange={(e) => setModelId(e.target.value)}
              className="border border-gray-300 p-2 mb-4 w-full"
              placeholder="Model ID"
            />
            {dataSourceIds.map((dataSourceId, index) => (
              <div key={index} className="flex items-center mb-2">
                <input
                  type="text"
                  value={dataSourceId}
                  onChange={(e) =>
                    handleDataSourceChange(index, e.target.value)
                  }
                  className="border border-gray-300 p-2 w-full"
                  placeholder={`Data Source ID ${index + 1}`}
                />
                {dataSourceIds.length > 1 && (
                  <MdRemove
                    className="text-xl cursor-pointer ml-2"
                    onClick={() => removeDataSource(index)}
                  />
                )}
              </div>
            ))}
            {dataSourceIds.length < 5 && (
              <button
                onClick={addDataSource}
                className="flex items-center bg-green-500 text-white px-2 py-1 rounded-md mb-4"
              >
                <MdAdd className="text-xl mr-2" /> Add Data Source
              </button>
            )}
            <input
              type="text"
              value={genPrompt}
              onChange={(e) => setGenPrompt(e.target.value)}
              className="border border-gray-300 p-2 mb-4 w-full"
              placeholder="Gen Prompt"
            />
            <input
              type="text"
              value={invokePrompt}
              onChange={(e) => setInvokePrompt(e.target.value)}
              className="border border-gray-300 p-2 mb-4 w-full"
              placeholder="Invoke Prompt"
            />
            <button
              onClick={handleInsertDomainSubmit}
              className="bg-blue-500 text-white px-4 py-2 rounded-md"
            >
              Insert
            </button>
            <button
              onClick={() => setIsInsertDomainModalOpen(false)}
              className="ml-2 bg-gray-500 text-white px-4 py-2 rounded-md"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sidebar;
