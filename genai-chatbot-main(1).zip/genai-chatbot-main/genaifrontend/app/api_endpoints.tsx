import { API, Auth } from "aws-amplify";
import { v4 as uuidv4 } from "uuid";
import config from "../src/amplifyconfiguration.json";

const apiName = config["aws_cloud_logic_custom"][0]["name"];
const apiEndpointUrl = config["aws_cloud_logic_custom"][0]["endpoint"];

// Function to ensure paths are correctly formatted based on the endpoint URL
function getFormattedPath(path: string): string {
  if (apiEndpointUrl.endsWith("/")) {
    return path;
  } else {
    return `/${path}`;
  }
}

export async function get_presignedurl_upload(
  file_key: string,
  domain: string,
  sub_domain: string,
) {
  try {
    const path = getFormattedPath("uploadfilerequest");

    const myInit = {
      headers: {
        Authorization: `Bearer ${(await Auth.currentSession())
          .getIdToken()
          .getJwtToken()}`,
      },
      queryStringParameters: {
        file_name: file_key,
        domain: domain,
        sub_domain: sub_domain,
      },
    };

    let response = await API.get(apiName, path, myInit);
    console.log(response);

    return response;
  } catch (error) {
    alert(
      "Error while submitting request for get_presignedurl_upload. Try again later.",
    );
    console.log(error);
  }
}

export async function get_presignedurl_download(file_key: string) {
  console.log(file_key);
  let test = (await Auth.currentSession()).getIdToken().getJwtToken();
  console.log(test);
  try {
    const path = getFormattedPath("handledownloadrequest");

    const myInit = {
      headers: {
        Authorization: `Bearer ${(await Auth.currentSession())
          .getIdToken()
          .getJwtToken()}`,
      },
      queryStringParameters: {
        file_key: file_key,
      },
    };

    let response = await API.get(apiName, path, myInit);
    console.log(response);

    return response;
  } catch (error) {
    alert(
      "Error while submitting request for get_presignedurl_download. Try again later.",
    );
    console.log(error);
  }
}

export async function get_knowledge_base_API(
  domain: string,
  sub_domain: string,
) {
  try {
    const path = getFormattedPath("getknowledgebaseid");

    const myInit = {
      headers: {
        Authorization: `Bearer ${(await Auth.currentSession())
          .getIdToken()
          .getJwtToken()}`,
      },
      queryStringParameters: {
        domain: domain,
        sub_domain: sub_domain,
      },
    };

    let response = await API.get(apiName, path, myInit);

    return response;
  } catch (error) {
    alert(
      "Error while submitting request for getknoiwledgebaseid. Try again later.",
    );
    console.log(error);
  }
}

export async function chatbot(
  knowledge_base_id: string,
  question: string,
  session_id: null | string,
) {
  try {
    const path = getFormattedPath("chatbot");
    const requestBody = {
      question: question,
      knowledge_base_id: knowledge_base_id,
      session_id: session_id,
    };
    const myInit = {
      body: requestBody,
      headers: {
        Authorization: `Bearer ${(await Auth.currentSession())
          .getIdToken()
          .getJwtToken()}`,
      },
    };

    let response = await API.post(apiName, path, myInit);
    console.log(response);

    return response;
  } catch (error) {
    alert("Error while submitting request for chatbot. Try again later.");
    console.log(error);
  }
}

export async function saveConversationAPI(
  auditDomain: string,
  subDomain: string,
  conversationTitle: string,
  knowledge_base_id: string,
  sessionId: string,
  messages: Message[],
  savedFileList: string[],
  user_email: string,
) {
  let new_conversation_id = uuidv4();
  let datetime = new Date().toISOString();
  try {
    const path = getFormattedPath("saveConversation");
    const requestBody = {
      datetime_submitted: datetime,
      conversation_id: new_conversation_id,
      conversation_title: conversationTitle,
      knowledge_base_id: knowledge_base_id,
      session_id: sessionId,
      audit_domain: auditDomain,
      sub_domain: subDomain,
      saved_file_list: savedFileList,
      messages: messages,
      user_email: user_email,
    };

    const myInit = {
      body: requestBody,
      headers: {
        Authorization: `Bearer ${(await Auth.currentSession())
          .getIdToken()
          .getJwtToken()}`,
      },
    };

    let response = await API.post(apiName, path, myInit);

    return response;
  } catch (error) {
    alert("Error while submitting save for conversation. Try again later.");
    console.log(error);
  }
}

export async function getConversationHistoryList(queryStringDict: {}) {
  try {
    const path = getFormattedPath("listConversations");

    const myInit = {
      headers: {
        Authorization: `Bearer ${(await Auth.currentSession())
          .getIdToken()
          .getJwtToken()}`,
      },
      queryStringParameters: queryStringDict,
    };

    let response = await API.get(apiName, path, myInit);

    return response;
  } catch (error) {
    alert(
      "Error while submitting request for getting user conversation history. Try again later.",
    );
    console.log(error);
  }
}

export async function getConversationAPI(conversation_id: string) {
  try {
    const path = getFormattedPath("getConversation");

    const myInit = {
      headers: {
        Authorization: `Bearer ${(await Auth.currentSession())
          .getIdToken()
          .getJwtToken()}`,
      },
      queryStringParameters: {
        conversation_id: conversation_id,
      },
    };

    let response = await API.get(apiName, path, myInit);

    return response;
  } catch (error) {
    alert(
      "Error while submitting request for getting a user conversation. Try again later.",
    );
    console.log(error);
  }
}

export async function insertNewDomainAPI(domain_data: {}) {
  try {
    const path = getFormattedPath("insertNewDomain");

    const myInit = {
      headers: {
        Authorization: `Bearer ${(await Auth.currentSession())
          .getIdToken()
          .getJwtToken()}`,
      },
      body: domain_data,
    };

    let response = await API.post(apiName, path, myInit);

    return response;
  } catch (error) {
    alert(
      "Error while submitting request for inserting a new domain. Try again later.",
    );
    console.log(error);
  }
}

export async function getDomainsSubDomains() {
  try {
    const path = getFormattedPath("getDomainsSubDomains");

    const myInit = {
      headers: {
        Authorization: `Bearer ${(await Auth.currentSession())
          .getIdToken()
          .getJwtToken()}`,
      },
    };

    let response = await API.get(apiName, path, myInit);

    return response;
  } catch (error) {
    alert(
      "Error while submitting request for inserting a new domain. Try again later.",
    );
    console.log(error);
  }

  return {};
}

export async function assignUserObjectTags(
  file_key: string,
  phi: boolean,
  pii: boolean,
  summarize: boolean,
  image_type: String | null,
) {
  try {
    const path = getFormattedPath("assignobjecttags");
    const requestBody = {
      file_key: file_key,
      phi: phi,
      pii: pii,
      summarize: summarize,
      image_type: image_type,
    };

    const myInit = {
      headers: {
        Authorization: `Bearer ${(await Auth.currentSession())
          .getIdToken()
          .getJwtToken()}`,
      },
      body: requestBody,
    };

    let response = await API.put(apiName, path, myInit);
    return response;
  } catch (error) {
    alert(
      "Error while submitting request to assign user object tags. Try again later.",
    );
    console.log(error);
  }
}

type Message = {
  from: string;
  text: string;
  related_citations?: [
    {
      cited_text: string;
      file_key: string;
    },
  ];
};
