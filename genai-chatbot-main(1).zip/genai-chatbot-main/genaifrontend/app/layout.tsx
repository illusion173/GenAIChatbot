import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./ui/globals.css";
import { DashboardProvider } from "./dashboard/context";
import { Amplify } from "aws-amplify";
import "@aws-amplify/ui-react/styles.css";
import config from "../src/amplifyconfiguration.json";
Amplify.configure(config);

// Configure Amplify with the output settings
const inter = Inter({ subsets: ["latin"] });
export const metadata: Metadata = {
  title: "GenAIChatbot",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <DashboardProvider>
        <body className={inter.className}>{children}</body>
      </DashboardProvider>
    </html>
  );
}
