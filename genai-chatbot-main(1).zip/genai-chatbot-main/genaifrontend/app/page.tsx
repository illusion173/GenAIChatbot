"use client";
import { useState, useEffect } from "react";

import Link from "next/link";
import config from "../src/amplifyconfiguration.json";
Amplify.configure(config);

import { Authenticator } from "@aws-amplify/ui-react";
import { Amplify } from "aws-amplify";
import "@aws-amplify/ui-react/styles.css";

import { useDashboardContext, DashboardProvider } from "./dashboard/context.js";
export default function App() {
  return (
    <DashboardProvider>
      <Authenticator hideSignUp>
        {({ signOut, user }) => (
          <main
            className="flex justify-center px-32 h-full"
            style={{
              background: "linear-gradient(#80C4E9, #f5f5f5)",
              fontFamily: "Helvetica",
            }}
          >
            <div>
              <div className="mt-12 text-center text-xl font-bold">
                Welcome to the AnyCompany Audit Chatbot
              </div>
              <div className="px-8 pt-4 pb-8 mt-4 bg-white rounded-xl">
                <p className="mt-4 text-justify">
                  Welcome to the AnyCompany Audit Chatbot, your new tool for
                  managing internal audit processes with ease. This chatbot is
                  designed to help you find answers to your audit-related
                  questions quickly and efficiently, reducing the need for
                  time-consuming meetings and allowing you to focus on your core
                  tasks.
                </p>
                <div
                  className="mt-8 text-lg font-bold"
                  style={{ color: "#0073bb" }}
                >
                  Getting Started:
                </div>
                <ul className="list-disc">
                  <li>
                    Navigate to the Dashboard: Click the "Take Me to the
                    Dashboard" button below to access the main dashboard.
                  </li>
                  <li>
                    Upload Documents: On the sidebar, select "Upload Document"
                    to add your audit-related files to the system. This will
                    help the chatbot provide more accurate answers.
                  </li>
                  <li>
                    View Downloads: Access any documents you have downloaded by
                    clicking "View Downloads" in the sidebar.
                  </li>
                  <li>
                    Save and View Conversations: Save your current conversations
                    for future reference by clicking "Save Current
                    Conversation." To review past queries, select "View Previous
                    Conversations."
                  </li>
                  <li>
                    Insert New Audit Domains: If you need the chatbot to cover
                    additional audit topics, click "Insert New Domain" to expand
                    its knowledge base.
                  </li>
                </ul>
                <div
                  className="mt-4 text-lg font-bold"
                  style={{ color: "#0073bb" }}
                >
                  Instructions for Use:
                </div>
                <ul className="list-disc">
                  <li>
                    Ask Your Questions: Once you are on the dashboard, simply
                    type your audit-related questions into the chat window. The
                    chatbot will provide you with relevant answers based on the
                    documents and information available.
                  </li>
                  <li>
                    Upload Relevant Documents: Ensure that all necessary audit
                    documents are uploaded to help the chatbot give you the most
                    accurate and helpful responses.
                  </li>
                  <li>
                    Save Important Conversations: Save any important chat
                    interactions to easily revisit them later.
                  </li>
                  <li>
                    Expand the Chatbot's Knowledge: Continuously improve the
                    chatbot&apos;s utility by adding new audit domains as your
                    needs grow. Click the button below to get started and make
                    your audit process smoother and more efficient!
                  </li>
                </ul>
                <div className="mt-8">
                  Click the button below to get started and make your audit
                  process smoother and more efficient!
                </div>
              </div>
              <div className="flex justify-center">
                <Link
                  className="mt-12 text-lg hover:underline font-bold px-4 py-4 rounded"
                  style={{ background: "#F7F9F2", color: "#0073bb" }}
                  href="/dashboard"
                >
                  Take me to the Dashboard
                </Link>
              </div>
            </div>
          </main>
        )}
      </Authenticator>
    </DashboardProvider>
  );
}
