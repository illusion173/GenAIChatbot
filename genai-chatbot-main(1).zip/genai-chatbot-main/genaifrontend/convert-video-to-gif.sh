#!/bin/bash


# Loop through all .mov files in the current directory
for videoFilename in *.mov; do
    # Extract the base name without the extension
    gifFilename="public/$(basename "$videoFilename" .mov).gif"
    
    # Set the filter options
    filters="fps=10,scale=1000:-1:flags=lanczos,split[s0][s1];[s0]palettegen=max_colors=128[p];[s1][p]paletteuse=dither=bayer"
    
    # Run ffmpeg and convert
    ffmpeg -i "$videoFilename" -vf "$filters" -c:v pam -f image2pipe - | convert -delay 10 - -loop 0 -layers optimize "$gifFilename"
done

