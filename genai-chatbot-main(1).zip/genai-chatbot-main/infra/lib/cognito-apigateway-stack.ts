import * as cdk from "aws-cdk-lib";
import {
  RestApi,
  LambdaIntegration,
  CognitoUserPoolsAuthorizer,
} from "aws-cdk-lib/aws-apigateway";
import {
  Role,
  PolicyStatement,
  Effect,
  FederatedPrincipal,
} from "aws-cdk-lib/aws-iam";
import { RustFunction, Settings } from "rust.aws-cdk-lambda"; // Importing RustFunction
import { Construct } from "constructs";
import * as cognito from "aws-cdk-lib/aws-cognito";
import * as apigateway from "aws-cdk-lib/aws-apigateway";
import * as GenAITypes from "../lib/GenAICdkTypes";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import * as iam from "aws-cdk-lib/aws-iam";

interface CognitoAPIGWStackProps extends cdk.StackProps {
  LambdaFunctionInfo: GenAITypes.LambdaFunctions;
  S3Info: GenAITypes.GenAIS3BucketInformation;
  GenAIDomainTable: dynamodb.ITable;
  GenAIConversationTable: dynamodb.ITable;
}

export class CognitoAPIGWStack extends cdk.Stack {
  public readonly genAICognitoAPIInfo: GenAITypes.GenAICognitoAPIGWInfo;

  constructor(scope: Construct, id: string, props: CognitoAPIGWStackProps) {
    super(scope, id, props);

    const {
      LambdaFunctionInfo,
      S3Info,
      GenAIDomainTable,
      GenAIConversationTable,
    } = props;

    const region = cdk.Stack.of(this).region;
    const account = cdk.Stack.of(this).account;
    const rndInt = Math.floor(Math.random() * 10000000) + 1;
    const removalPolicy = cdk.RemovalPolicy.DESTROY;

    // Create the Cognito User Pool
    const genAICognitoUserPool = new cognito.UserPool(
      this,
      "GenAICognitoUserPool",
      {
        userPoolName: `GenAI-CognitoUserPool-${region}-${account}-${rndInt}`,
        passwordPolicy: {
          minLength: 8,
          requireLowercase: false,
          requireUppercase: false,
          requireDigits: false,
          requireSymbols: false,
          tempPasswordValidity: cdk.Duration.days(7),
        },
        autoVerify: {
          email: true,
        },
        selfSignUpEnabled: false,
        accountRecovery: cognito.AccountRecovery.EMAIL_ONLY,
        signInAliases: {
          email: true,
          phone: false, // ensure phone number sign-in is disabled
          username: false, // ensure username sign-in is disabled
        },
        removalPolicy: removalPolicy,
      },
    );

    /*
    // Create a Cognito User Pool Client
    const genAICognitoWebClient = new cognito.UserPoolClient(
      this,
      "GenAIuserPoolWebClient",
      {
        userPool: genAICognitoUserPool,
      },
    );
    */

    const genAICognitoWebClient = genAICognitoUserPool.addClient(
      "GenAIUserPoolWebClient",
      {
        generateSecret: false,
        userPoolClientName: "GenAIWebClient",
        authFlows: { userPassword: true, userSrp: true, custom: true },
        enableTokenRevocation: true,
      },
    );

    const genAIIdentityPool = new cognito.CfnIdentityPool(
      this,
      "genAIIdentityPool",
      {
        identityPoolName: `GenAI-IDPool-${region}-${account}-${rndInt}`,
        allowUnauthenticatedIdentities: false,
        cognitoIdentityProviders: [
          {
            clientId: genAICognitoWebClient.userPoolClientId,
            providerName: genAICognitoUserPool.userPoolProviderName,
          },
        ],
      },
    );

    // Create an API Gateway REST API with Lambda proxy integration
    const genAIAPIGateway = new apigateway.RestApi(
      this,
      "GenAIRestApiGateway",
      {
        restApiName: `GenAI-RESTAPI-${region}-${account}-${rndInt}`,
        defaultCorsPreflightOptions: {
          allowOrigins: apigateway.Cors.ALL_ORIGINS,
          allowMethods: apigateway.Cors.ALL_METHODS,
        },
      },
    );

    // Retrieve the API ID and Stage Name
    const apiId = genAIAPIGateway.restApiId;
    const stageName = genAIAPIGateway.deploymentStage.stageName;

    // Create a Cognito User Pool Authorizer
    const authorizer = new apigateway.CognitoUserPoolsAuthorizer(
      this,
      "GenAIAPIAuthorizer",
      {
        cognitoUserPools: [genAICognitoUserPool],
      },
    );

    const unauthenticatedRole = new iam.Role(
      this,
      "CognitoDefaultUnauthenticatedRole",
      {
        assumedBy: new iam.FederatedPrincipal(
          "cognito-identity.amazonaws.com",
          {
            StringEquals: {
              "cognito-identity.amazonaws.com:aud": genAIIdentityPool.ref,
            },
            "ForAnyValue:StringLike": {
              "cognito-identity.amazonaws.com:amr": "unauthenticated",
            },
          },
          "sts:AssumeRoleWithWebIdentity",
        ),
      },
    );

    unauthenticatedRole.addToPolicy(
      new PolicyStatement({
        effect: Effect.ALLOW,
        actions: ["mobileanalytics:PutEvents", "cognito-sync:*"],
        resources: ["*"],
      }),
    );

    const authenticatedRole = new iam.Role(
      this,
      "CognitoDefaultAuthenticatedRole",
      {
        assumedBy: new iam.FederatedPrincipal(
          "cognito-identity.amazonaws.com",
          {
            StringEquals: {
              "cognito-identity.amazonaws.com:aud": genAIIdentityPool.ref,
            },
            "ForAnyValue:StringLike": {
              "cognito-identity.amazonaws.com:amr": "authenticated",
            },
          },
          "sts:AssumeRoleWithWebIdentity",
        ),
      },
    );
    authenticatedRole.addToPolicy(
      new PolicyStatement({
        effect: Effect.ALLOW,
        actions: [
          "mobileanalytics:PutEvents",
          "cognito-sync:*",
          "cognito-identity:*",
        ],
        resources: ["*"],
      }),
    );

    // Dynamically generate the API resource ARNs
    const apiInvokeArn = `arn:aws:execute-api:${region}:${account}:${apiId}/${stageName}/*/items`;
    const apiInvokeAnyArn = `arn:aws:execute-api:${region}:${account}:${apiId}/${stageName}/*/items/*`;

    // Attach policy to the authenticated role
    authenticatedRole.addToPolicy(
      new PolicyStatement({
        effect: Effect.ALLOW,
        actions: ["execute-api:Invoke"],
        resources: [apiInvokeArn, apiInvokeAnyArn],
      }),
    );

    const defaultPolicy = new cognito.CfnIdentityPoolRoleAttachment(
      this,
      "DefaultValid",
      {
        identityPoolId: genAIIdentityPool.ref,
        roles: {
          unauthenticated: unauthenticatedRole.roleArn,
          authenticated: authenticatedRole.roleArn,
        },
      },
    );

    // Create the IAM Role for the user group
    const groupRole = new Role(this, "GenAIUserGroupRole", {
      assumedBy: new FederatedPrincipal(
        "cognito-identity.amazonaws.com",
        {
          StringEquals: {
            "cognito-identity.amazonaws.com:aud": genAIIdentityPool.ref,
          },
          "ForAnyValue:StringLike": {
            "cognito-identity.amazonaws.com:amr": "authenticated",
          },
        },
        "sts:AssumeRoleWithWebIdentity",
      ),
    });

    // S3 bucket policies
    const s3DataSourceBucketPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["s3:*"],
      resources: [
        S3Info.dataSourceFileBucket.arnForObjects("*"),
        S3Info.dataSourceFileBucket.bucketArn,
      ],
    });
    const s3UserBucketPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["s3:*"],
      resources: [
        S3Info.userLandingBucket.arnForObjects("*"),
        S3Info.userLandingBucket.bucketArn,
      ],
    });

    // Dynamo Policies
    const dynamoKnowledgeBasePolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["dynamodb:*"],
      resources: [
        GenAIDomainTable.tableArn,
        `${GenAIDomainTable.tableArn}/index/audit_domain-subdomain-index`,
        `${GenAIDomainTable.tableArn}/index/knowledge_base_id`,
      ],
    });

    const dynamoConversationPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["dynamodb:*"],
      resources: [
        GenAIConversationTable.tableArn,
        `${GenAIConversationTable.tableArn}/index/user_email-index`,
      ],
    });

    // Attach policy to the user group role
    groupRole.addToPolicy(s3DataSourceBucketPolicy);
    groupRole.addToPolicy(s3UserBucketPolicy);
    groupRole.addToPolicy(dynamoKnowledgeBasePolicy);
    groupRole.addToPolicy(dynamoConversationPolicy);

    // Create the Cognito User Group Users will need to be assigned to this group in order to work with the chatbot
    const userGroup = new cognito.CfnUserPoolGroup(this, "GenAIUserGroup", {
      userPoolId: genAICognitoUserPool.userPoolId,
      groupName: "GenAIUserGroup",
      roleArn: groupRole.roleArn,
    });

    // Create Lambda Proxy Endpoints
    this.createLambdaIntegration(
      genAIAPIGateway,
      authorizer,
      "/assignobjecttags",
      "PUT",
      LambdaFunctionInfo.assignUserTags,
    );

    this.createLambdaIntegration(
      genAIAPIGateway,
      authorizer,
      "/chatbot",
      "POST",
      LambdaFunctionInfo.chatbot,
    );

    this.createLambdaIntegration(
      genAIAPIGateway,
      authorizer,
      "/getConversation",
      "GET",
      LambdaFunctionInfo.grabConversation,
    );

    this.createLambdaIntegration(
      genAIAPIGateway,
      authorizer,
      "/getDomainsSubDomains",
      "GET",
      LambdaFunctionInfo.getDomainsSubdomains,
    );

    this.createLambdaIntegration(
      genAIAPIGateway,
      authorizer,
      "/getknowledgebaseid",
      "GET",
      LambdaFunctionInfo.getKnowledgeBaseId,
    );

    this.createLambdaIntegration(
      genAIAPIGateway,
      authorizer,
      "/handledownloadrequest",
      "GET",
      LambdaFunctionInfo.handleDownload,
    );

    this.createLambdaIntegration(
      genAIAPIGateway,
      authorizer,
      "/insertNewDomain",
      "POST",
      LambdaFunctionInfo.insertDomain,
    );

    this.createLambdaIntegration(
      genAIAPIGateway,
      authorizer,
      "/listConversations",
      "GET",
      LambdaFunctionInfo.listConversations,
    );

    this.createLambdaIntegration(
      genAIAPIGateway,
      authorizer,
      "/saveConversation",
      "POST",
      LambdaFunctionInfo.saveConversation,
    );

    this.createLambdaIntegration(
      genAIAPIGateway,
      authorizer,
      "/uploadfilerequest",
      "GET",
      LambdaFunctionInfo.handleUpload,
    );
    // Return
    //
    this.genAICognitoAPIInfo = {
      genAIAPIGateway: genAIAPIGateway,
      genAIIdentityPool: genAIIdentityPool,
      genAICognitoUserPool: genAICognitoUserPool,
      genAICognitoWebClient: genAICognitoWebClient,
    };
  }

  private createLambdaIntegration(
    api: RestApi,
    authorizer: CognitoUserPoolsAuthorizer,
    path: string,
    method: string,
    lambdaFunction: RustFunction, // Use RustFunction type
  ) {
    const resource = api.root.resourceForPath(path);
    const integration = new LambdaIntegration(lambdaFunction);

    // Add the main method (GET, POST, PUT, etc.)
    resource.addMethod(method, integration, {
      authorizer,
      authorizationType: apigateway.AuthorizationType.COGNITO,
    });
  }
}
