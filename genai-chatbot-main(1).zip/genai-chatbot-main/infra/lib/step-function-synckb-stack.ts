import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import * as tasks from "aws-cdk-lib/aws-stepfunctions-tasks";
import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import * as GenAITypes from "../lib/GenAICdkTypes";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import { RustFunction, Settings } from "rust.aws-cdk-lambda";
import * as iam from "aws-cdk-lib/aws-iam";

interface StepFunctionSyncKBStackProps extends cdk.StackProps {
  //S3Info: GenAITypes.GenAIS3BucketInformation;
  //IAMInfo: GenAITypes.GenAIIamRoles;
  //LambdaFunctionInfo: GenAITypes.LambdaFunctions;
  GenAIDomainTable: dynamodb.ITable;
  //GenAIConversationTable: dynamodb.ITable;
}

export class StepFunctionSyncKBStack extends cdk.Stack {
  public readonly syncSFN: sfn.StateMachine;
  public readonly beginSyncKBsRLF: RustFunction;
  constructor(
    scope: Construct,
    id: string,
    props: StepFunctionSyncKBStackProps,
  ) {
    super(scope, id, props);

    const {
      //S3Info,
      //IAMInfo,
      //LambdaFunctionInfo,
      GenAIDomainTable,
      //GenAIConversationTable,
    } = props;
    // DynamoDB policies
    const dynamoKnowledgeBasePolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["*"],
      resources: [
        GenAIDomainTable.tableArn,
        `${GenAIDomainTable.tableArn}/index/audit_domain-subdomain-index`,
        `${GenAIDomainTable.tableArn}/index/knowledge_base_id`,
      ],
    });

    // Set the base Cargo workspace directory
    Settings.WORKSPACE_DIR = "lambdas";

    const region = cdk.Stack.of(this).region;

    const account = cdk.Stack.of(this).account;

    const rndInt = Math.floor(Math.random() * 10000000) + 1;

    const bedrockArn = `arn:aws:bedrock:${region}::foundation-model/amazon.titan-embed-text-v2:0`;

    // Bedrock policy
    const bedrockPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["bedrock:*"],
      resources: ["*", bedrockArn],
    });

    const stepFunctionLogPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        "logs:CreateLogDelivery",
        "logs:CreateLogStream",
        "logs:GetLogDelivery",
        "logs:UpdateLogDelivery",
        "logs:DeleteLogDelivery",
        "logs:ListLogDeliveries",
        "logs:PutLogEvents",
        "logs:PutResourcePolicy",
        "logs:DescribeResourcePolicies",
        "logs:DescribeLogGroups",
      ],
      resources: ["*"],
    });

    const stepFunctionInvokeLambdaPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["lambda:InvokeFunction"],
      resources: ["*"],
    });

    const beginSyncStepFunctionPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["states:StartExecution"],
      resources: ["*"],
    });

    // Common Lambda Execution Role properties
    const commonLambdaProps = {
      assumedBy: new iam.ServicePrincipal("lambda.amazonaws.com"),
    };

    const logLambdaPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents",
      ],
      resources: ["*"],
    });

    const createLambdaRole = (
      roleName: string,
      additionalPolicies: iam.PolicyStatement[] = [],
    ) => {
      const role = new iam.Role(this, roleName, {
        ...commonLambdaProps,
      });

      role.addToPolicy(logLambdaPolicy);

      additionalPolicies.forEach((policy) => role.addToPolicy(policy));

      return role;
    };

    const createRustFunction = (
      id: string,
      packageName: string,
      role: iam.Role,
      timeout: cdk.Duration,
      environment: { [key: string]: string },
    ) => {
      return new RustFunction(this, id, {
        package: packageName,
        setupLogging: true,
        functionName: `GenAI-${packageName}-${region}-${account}-${rndInt}`,
        role: role,
        timeout: timeout,
        environment: environment,
      });
    };

    const startIngestKb = createLambdaRole("GenAI_startingestkbRole", [
      bedrockPolicy,
    ]);
    const checkIngestKb = createLambdaRole("GenAI_checkingestkbRole", [
      bedrockPolicy,
    ]);

    const startIngestKbRF = createRustFunction(
      "StartIngestKBRLF",
      "startingestkb",
      startIngestKb,
      cdk.Duration.seconds(30),
      {},
    );
    const checkIngestKbRF = createRustFunction(
      "CheckIngestKBRLF",
      "checkingestkb",
      checkIngestKb,
      cdk.Duration.seconds(30),
      {},
    );
    // Step Function Related for Syncing the Knowledge bases automatically
    const GenAI_SyncKnowledgeBaseSfnRole = new iam.Role(
      this,
      "GenAI_SyncKnowledgeBaseSfnRole",
      {
        assumedBy: new iam.ServicePrincipal("states.amazonaws.com"),
        managedPolicies: [
          iam.ManagedPolicy.fromAwsManagedPolicyName("AWSXrayWriteOnlyAccess"),
        ],
      },
    );

    GenAI_SyncKnowledgeBaseSfnRole.addToPolicy(stepFunctionLogPolicy);
    GenAI_SyncKnowledgeBaseSfnRole.addToPolicy(stepFunctionInvokeLambdaPolicy);

    const GenAI_beginsynckb = createLambdaRole("GenAI_beginsynckbRole", [
      dynamoKnowledgeBasePolicy,
      beginSyncStepFunctionPolicy,
    ]);

    // Define the Step Function tasks
    const startIngestionJob = new tasks.LambdaInvoke(
      this,
      "StartIngestionJob",
      {
        lambdaFunction: startIngestKbRF,
        payload: sfn.TaskInput.fromObject({
          knowledge_base_id: sfn.JsonPath.stringAt("$.knowledge_base_id"),
          data_source_ids: sfn.JsonPath.stringAt("$.data_source_ids"),
          len_ds_ids: sfn.JsonPath.stringAt("$.len_ds_ids"),
          current_idx: sfn.JsonPath.stringAt("$.current_idx"),
        }),
        retryOnServiceExceptions: true,
        resultPath: "$.Payload",
      },
    );

    const wait = new sfn.Wait(this, "Wait", {
      time: sfn.WaitTime.duration(cdk.Duration.seconds(15)),
    });

    const checkIngestKBJob = new tasks.LambdaInvoke(this, "CheckIngestKBJob", {
      lambdaFunction: checkIngestKbRF,
      payload: sfn.TaskInput.fromObject({
        knowledge_base_id: sfn.JsonPath.stringAt("$.knowledge_base_id"),
        data_source_ids: sfn.JsonPath.stringAt("$.data_source_ids"),
        len_ds_ids: sfn.JsonPath.stringAt("$.len_ds_ids"),
        current_idx: sfn.JsonPath.stringAt("$.current_idx"),
        job_id: sfn.JsonPath.stringAt("$.job_id"),
      }),
      retryOnServiceExceptions: true,
      resultPath: "$.Payload",
    });

    const choice = new sfn.Choice(this, "Choice")
      .when(
        sfn.Condition.numberLessThanJsonPath("$.current_idx", "$.len_ds_ids"),
        new sfn.Wait(this, "Wait (1)", {
          time: sfn.WaitTime.duration(cdk.Duration.seconds(30)),
        }).next(checkIngestKBJob),
      )
      .when(
        sfn.Condition.numberEqualsJsonPath("$.current_idx", "$.len_ds_ids"),
        new sfn.Succeed(this, "Success"),
      );

    // Define the State Machine
    const definition = startIngestionJob
      .next(wait)
      .next(checkIngestKBJob)
      .next(choice);

    this.syncSFN = new sfn.StateMachine(this, "KBSyncMachine", {
      definition,
      timeout: cdk.Duration.minutes(5),
      role: GenAI_SyncKnowledgeBaseSfnRole,
    });
    this.beginSyncKBsRLF = createRustFunction(
      "BeginSyncKBRLF",
      "beginsynckb",
      GenAI_beginsynckb,
      cdk.Duration.seconds(30),
      {
        DB_NAME: GenAIDomainTable.tableName,
        SYNC_SF_ARN: this.syncSFN.stateMachineArn,
      },
    );
  }
}
