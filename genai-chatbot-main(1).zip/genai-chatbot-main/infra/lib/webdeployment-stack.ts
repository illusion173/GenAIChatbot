import * as cdk from "aws-cdk-lib";
import {
  RestApi,
  LambdaIntegration,
  CognitoUserPoolsAuthorizer,
} from "aws-cdk-lib/aws-apigateway";
import {
  Role,
  PolicyStatement,
  Effect,
  FederatedPrincipal,
} from "aws-cdk-lib/aws-iam";
import { RustFunction, Settings } from "rust.aws-cdk-lambda"; // Importing RustFunction
import { Construct } from "constructs";
import * as cognito from "aws-cdk-lib/aws-cognito";
import * as apigateway from "aws-cdk-lib/aws-apigateway";
import * as GenAITypes from "../lib/GenAICdkTypes";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import * as iam from "aws-cdk-lib/aws-iam";
import * as ssm from "aws-cdk-lib/aws-ssm";
import * as s3d from "aws-cdk-lib/aws-s3-deployment";
import * as aws_logs from "aws-cdk-lib/aws-logs";
import * as path from "path";
import * as amplify from "@aws-cdk/aws-amplify";
interface WebDeploymentStackProps extends cdk.StackProps {
  LambdaFunctionInfo: GenAITypes.LambdaFunctions;
  S3Info: GenAITypes.GenAIS3BucketInformation;
  GenAIDomainTable: dynamodb.ITable;
  GenAIConversationTable: dynamodb.ITable;
  CognitoAPIGWInfo: GenAITypes.GenAICognitoAPIGWInfo;
}

export class WebDeploymentStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: WebDeploymentStackProps) {
    super(scope, id, props);

    const {
      LambdaFunctionInfo,
      S3Info,
      GenAIDomainTable,
      GenAIConversationTable,
      CognitoAPIGWInfo,
    } = props;

    const removalPolicy = cdk.RemovalPolicy.DESTROY; // todo: read from context
    const region = cdk.Stack.of(this).region;
    const account = cdk.Stack.of(this).account;
    const authAPIConfig = new ssm.StringParameter(this, "auth-api-config", {
      stringValue: `
    {
      "aws_project_region": "${region}",
      "aws_cloud_logic_custom": [
        {
          "name": "${CognitoAPIGWInfo.genAIAPIGateway.restApiName}",
          "endpoint": "${CognitoAPIGWInfo.genAIAPIGateway.url}",
          "region": "${region}"
        }
      ],
      "aws_cognito_identity_pool_id": "${CognitoAPIGWInfo.genAIIdentityPool.ref}",
      "aws_cognito_region": "${region}",
      "aws_user_pools_id": "${CognitoAPIGWInfo.genAICognitoUserPool.userPoolId}",
      "aws_user_pools_web_client_id": "${CognitoAPIGWInfo.genAICognitoWebClient.userPoolClientId}",
      "oauth": {},
      "aws_cognito_username_attributes": [
        "EMAIL"
      ],
      "aws_cognito_social_providers": [],
      "aws_cognito_signup_attributes": [
        "EMAIL"
      ],
      "aws_cognito_mfa_configuration": "OFF",
      "aws_cognito_mfa_types": [
        "SMS"
      ],
      "aws_cognito_password_protection_settings": {
        "passwordPolicyMinLength": 8,
        "passwordPolicyCharacters": []
      },
      "aws_cognito_verification_mechanisms": [
        "EMAIL"
      ]
    }
  `,
    });

    // Auth API config
    new s3d.BucketDeployment(this, "auth-config-deployment", {
      logRetention: aws_logs.RetentionDays.ONE_WEEK,
      //distribution,
      destinationBucket: S3Info.webDeployBucket,
      sources: [
        s3d.Source.data(
          "src/amplifyconfiguration.json",
          authAPIConfig.stringValue,
        ),
      ],
    });

    // Amplify App
    //
    //
    /*
    // Main Branch
    const mainBranch = amplifyApp.addBranch("main", {
      autoBuild: true,
    });

    // Output Amplify URL
    new cdk.CfnOutput(this, "GenAmplifyAppURL", {
      value: `https://${mainBranch.branchName}.${amplifyApp.defaultDomain}`,
    });
    */
  }
}
