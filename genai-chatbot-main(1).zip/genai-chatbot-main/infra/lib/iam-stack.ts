import * as cdk from "aws-cdk-lib";
import * as iam from "aws-cdk-lib/aws-iam";
import { Construct } from "constructs";
import * as GenAITypes from "./GenAICdkTypes";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";

interface IAMStackProps extends cdk.StackProps {
  S3Info: GenAITypes.GenAIS3BucketInformation;
  GenAIDomainTable: dynamodb.ITable;
  GenAIConversationTable: dynamodb.ITable;
}

export class IamStack extends cdk.Stack {
  public readonly GenAI_IamRoles: GenAITypes.GenAIIamRoles;

  constructor(scope: Construct, id: string, props: IAMStackProps) {
    super(scope, id, props);

    const { S3Info, GenAIDomainTable, GenAIConversationTable } = props;
    const region = this.region;
    const bedrockArn = `arn:aws:bedrock:${region}::foundation-model/amazon.titan-embed-text-v2:0`;

    const logLambdaPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents",
      ],
      resources: ["*"],
    });

    // Common Lambda Execution Role properties
    const commonLambdaProps = {
      assumedBy: new iam.ServicePrincipal("lambda.amazonaws.com"),
    };

    const createLambdaRole = (
      roleName: string,
      additionalPolicies: iam.PolicyStatement[] = [],
    ) => {
      const role = new iam.Role(this, roleName, {
        ...commonLambdaProps,
      });

      role.addToPolicy(logLambdaPolicy);

      additionalPolicies.forEach((policy) => role.addToPolicy(policy));

      return role;
    };

    // S3 bucket policies
    //
    //
    const s3TempWorkBucketPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["s3:*"],
      resources: [
        S3Info.tempWorkBucket.arnForObjects("*"),
        S3Info.tempWorkBucket.bucketArn,
      ],
    });

    const s3DataSourceBucketPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["s3:*"],
      resources: [
        S3Info.dataSourceFileBucket.arnForObjects("*"),
        S3Info.dataSourceFileBucket.bucketArn,
      ],
    });

    const s3ServiceBucketPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["s3:*"],
      resources: [
        S3Info.serviceLandingBucket.arnForObjects("*"),
        S3Info.serviceLandingBucket.bucketArn,
      ],
    });

    const s3UserBucketPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["s3:*"],
      resources: [
        S3Info.userLandingBucket.arnForObjects("*"),
        S3Info.userLandingBucket.bucketArn,
      ],
    });

    const s3UnsupportedBucketPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["*"],
      resources: [
        S3Info.unsuppportedFileBucket.arnForObjects("*"),
        S3Info.unsuppportedFileBucket.bucketArn,
      ],
    });

    // DynamoDB policies
    const dynamoKnowledgeBasePolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["dynamodb:*"],
      resources: [
        GenAIDomainTable.tableArn,
        `${GenAIDomainTable.tableArn}/index/audit_domain-subdomain-index`,
        `${GenAIDomainTable.tableArn}/index/knowledge_base_id`,
      ],
    });

    const dynamoConversationPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["dynamodb:*"],
      resources: [
        GenAIConversationTable.tableArn,
        `${GenAIConversationTable.tableArn}/index/user_email-index`,
      ],
    });

    // Bedrock policy
    const bedrockPolicy = new iam.PolicyStatement({
      effect: iam.Effect.ALLOW,
      actions: ["bedrock:*"],
      resources: ["*", bedrockArn],
    });

    const transcribePolicy = new iam.PolicyStatement({});

    const loadkbdataRustFunction = createLambdaRole("GenAI_loadkbdataRole", [
      dynamoKnowledgeBasePolicy,
      s3UnsupportedBucketPolicy,
      s3ServiceBucketPolicy,
      s3UserBucketPolicy,
      s3DataSourceBucketPolicy,
      s3TempWorkBucketPolicy,
    ]);

    loadkbdataRustFunction.addManagedPolicy(
      iam.ManagedPolicy.fromAwsManagedPolicyName("AmazonTranscribeFullAccess"),
    );
    loadkbdataRustFunction.addManagedPolicy(
      iam.ManagedPolicy.fromAwsManagedPolicyName("AmazonTextractFullAccess"),
    );
    // Define the IAM roles for Lambdas
    const roles = {
      assignServiceTags: createLambdaRole("GenAI_assignservicetagsRole", [
        s3ServiceBucketPolicy,
        s3UnsupportedBucketPolicy,
      ]),
      assignUserTags: createLambdaRole("GenAI_assignusertagsRole", [
        s3UserBucketPolicy,
        s3UnsupportedBucketPolicy,
      ]),
      loadKbData: loadkbdataRustFunction,
      startIngestKb: createLambdaRole("GenAI_startingestkbRole", [
        bedrockPolicy,
      ]),
      checkIngestKb: createLambdaRole("GenAI_checkingestkbRole", [
        bedrockPolicy,
      ]),
      chatbot: createLambdaRole("GenAI_chatbotRole", [
        bedrockPolicy,
        dynamoKnowledgeBasePolicy,
        s3DataSourceBucketPolicy,
      ]),
      getDomainsSubdomains: createLambdaRole("GenAI_getdomainssubdomainsRole", [
        dynamoKnowledgeBasePolicy,
      ]),
      getKnowledgeBaseId: createLambdaRole("GenAI_getknowledgebaseidRole", [
        dynamoKnowledgeBasePolicy,
      ]),
      grabConversation: createLambdaRole("GenAI_grabconversationRole", [
        dynamoConversationPolicy,
      ]),
      handleDownload: createLambdaRole("GenAI_handledownloadRole", [
        s3DataSourceBucketPolicy,
      ]),
      handleUpload: createLambdaRole("GenAI_handleuploadRole", [
        s3UserBucketPolicy,
      ]),
      insertDomain: createLambdaRole("GenAI_insertdomainRole", [
        dynamoKnowledgeBasePolicy,
      ]),
      listConversations: createLambdaRole("GenAI_listconversationRole", [
        dynamoConversationPolicy,
      ]),
      saveConversation: createLambdaRole("GenAI_saveconversationRole", [
        dynamoConversationPolicy,
      ]),
    };

    // Assign roles to the struct
    this.GenAI_IamRoles = {
      lambdaERAssignServiceTags: roles.assignServiceTags,
      lambdaERAssignUserTags: roles.assignUserTags,
      lambdaERLoadKbData: roles.loadKbData,
      lambdaERChatbot: roles.chatbot,
      lambdaERGetDomainsSubdomains: roles.getDomainsSubdomains,
      lambdaERGetKnowledgeBaseId: roles.getKnowledgeBaseId,
      lambdaERGrabConversation: roles.grabConversation,
      lambdaERHandleDownload: roles.handleDownload,
      lambdaERHandleUpload: roles.handleUpload,
      lambdaERInsertDomain: roles.insertDomain,
      lambdaERListConversation: roles.listConversations,
      lambdaERSaveConversation: roles.saveConversation,
    };
  }
}
