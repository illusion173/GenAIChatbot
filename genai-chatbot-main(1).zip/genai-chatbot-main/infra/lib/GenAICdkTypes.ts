import * as iam from "aws-cdk-lib/aws-iam";
import * as s3 from "aws-cdk-lib/aws-s3";
import { RustFunction } from "rust.aws-cdk-lambda";
import * as cognito from "aws-cdk-lib/aws-cognito";
import * as apigateway from "aws-cdk-lib/aws-apigateway";
export type GenAIS3BucketInformation = {
  userLandingBucket: s3.Bucket;
  serviceLandingBucket: s3.Bucket;
  unsuppportedFileBucket: s3.Bucket;
  dataSourceFileBucket: s3.Bucket;
  webDeployBucket: s3.Bucket;
  tempWorkBucket: s3.Bucket;
};

export type LambdaFunctions = {
  assignServiceTags: RustFunction;
  assignUserTags: RustFunction;
  loadKbData: RustFunction;

  getDomainsSubdomains: RustFunction;
  insertDomain: RustFunction;
  grabConversation: RustFunction;
  listConversations: RustFunction;
  saveConversation: RustFunction;
  handleUpload: RustFunction;
  handleDownload: RustFunction;
  chatbot: RustFunction;
  getKnowledgeBaseId: RustFunction;
};

export type GenAIIamRoles = {
  lambdaERAssignServiceTags: iam.Role;
  lambdaERAssignUserTags: iam.Role;
  lambdaERLoadKbData: iam.Role;

  lambdaERChatbot: iam.Role;
  lambdaERGetDomainsSubdomains: iam.Role;
  lambdaERGetKnowledgeBaseId: iam.Role;
  lambdaERGrabConversation: iam.Role;
  lambdaERHandleDownload: iam.Role;
  lambdaERHandleUpload: iam.Role;
  lambdaERInsertDomain: iam.Role;
  lambdaERListConversation: iam.Role;
  lambdaERSaveConversation: iam.Role;
};

export type GenAICognitoAPIGWInfo = {
  genAICognitoUserPool: cognito.UserPool;
  genAICognitoWebClient: cognito.UserPoolClient;
  genAIIdentityPool: cognito.CfnIdentityPool;
  genAIAPIGateway: apigateway.RestApi;
};
