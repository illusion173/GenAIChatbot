import * as cdk from "aws-cdk-lib";
import * as s3 from "aws-cdk-lib/aws-s3";
import { Construct } from "constructs";
import { GenAIS3BucketInformation } from "./GenAICdkTypes";

export class S3Stack extends cdk.Stack {
  public readonly S3BucketInfo: GenAIS3BucketInformation;

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    // Get the current AWS region
    const region = cdk.Stack.of(this).region;
    const removalPolicy = cdk.RemovalPolicy.DESTROY; // todo: read from context

    // Get the AWS account ID
    const account = cdk.Stack.of(this).account;

    // Define the bucket name with a specific prefix, region, account ID, and random num
    const userLandingBucketName = `genai-userlanding-${region}-${account}`;
    const serviceLandingBucketName = `genai-servicelanding-${region}-${account}`;
    const unsupportedFilesLandingBucketName = `genai-unsupportedfileslanding-${region}-${account}`;
    const dataSourceLandingBucketName = `genai-datasourcelanding-${region}-${account}`;
    const webDeployBucketName = `genai-webdeploy-${region}-${account}`;
    const tempWorkBucketName = `genai-tempwork-${region}-${account}`;

    const commonBucketPropts = {
      removalPolicy: removalPolicy,
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      autoDeleteObjects: true, // emptying bucket prior to deletion
      encryption: s3.BucketEncryption.S3_MANAGED,
    };

    // Create work area bucket
    const tempWorkBucket = new s3.Bucket(this, "tempWorkBucket", {
      bucketName: tempWorkBucketName,
      ...commonBucketPropts,
    });

    // Create User Landing Bucket
    const userLandingBucket = new s3.Bucket(this, "userLandingBucket", {
      bucketName: userLandingBucketName,
      cors: [
        {
          allowedMethods: [s3.HttpMethods.PUT],
          allowedOrigins: ["*"],
          allowedHeaders: ["*"],
          exposedHeaders: [],
        },
      ],
      eventBridgeEnabled: true,
      ...commonBucketPropts,
    });

    // Create service landing bucket
    const serviceLandingBucket = new s3.Bucket(this, "serviceLandingBucket", {
      bucketName: serviceLandingBucketName,
      eventBridgeEnabled: true,
      ...commonBucketPropts,
    });

    // Create unsupported files bucket.
    const unsuppportedFileBucket = new s3.Bucket(
      this,
      "unsuppportedFileBucket",
      {
        bucketName: unsupportedFilesLandingBucketName,
        ...commonBucketPropts,
      },
    );

    // Final Destination data source bucket.
    const dataSourceFileBucket = new s3.Bucket(this, "dataSourceFileBucket", {
      bucketName: dataSourceLandingBucketName,
      cors: [
        {
          allowedMethods: [s3.HttpMethods.GET],
          allowedOrigins: ["*"],
          allowedHeaders: ["*"],
          exposedHeaders: [],
        },
      ],
      ...commonBucketPropts,
    });

    const webDeployBucketProps = {
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      autoDeleteObjects: true, // emptying bucket prior to deletion
      removalPolicy,
      cors: [
        {
          allowedMethods: [
            s3.HttpMethods.GET,
            s3.HttpMethods.HEAD,
            s3.HttpMethods.PUT,
            s3.HttpMethods.POST,
            s3.HttpMethods.DELETE,
          ],
          allowedOrigins: ["*"],
          allowedHeaders: ["*"],
          exposedHeaders: [
            "x-amz-server-side-encryption",
            "x-amz-request-id",
            "x-amz-id-2",
            "ETag",
            "x-amz-meta-foo",
          ],
          maxAge: 3000,
        },
      ],
    };

    const webDeployBucket = new s3.Bucket(this, "webDeployBucket", {
      bucketName: webDeployBucketName,
      ...webDeployBucketProps,
    });

    this.S3BucketInfo = {
      userLandingBucket: userLandingBucket,
      serviceLandingBucket: serviceLandingBucket,
      unsuppportedFileBucket: unsuppportedFileBucket,
      dataSourceFileBucket: dataSourceFileBucket,
      webDeployBucket: webDeployBucket,
      tempWorkBucket: tempWorkBucket,
    };
  }
}
