import * as cdk from "aws-cdk-lib";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import { Construct } from "constructs";

export class DynamoDBStack extends cdk.Stack {
  public readonly GenAIDomainKBTB: dynamodb.Table;
  public readonly GenAIConversationTB: dynamodb.Table;

  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);
    // Generate a random Id arbitrary, just to make sure no duplicates names
    const rndInt = Math.floor(Math.random() * 10000000) + 1;

    // Get the current AWS region
    const region = cdk.Stack.of(this).region;

    // Get the AWS account ID
    const account = cdk.Stack.of(this).account;

    // Establish names
    const genAIDomainKBTBName = `GenAIChatbotKBTB-${region}-${account}-${rndInt}`;
    const GenAIConversationTBName = `GenAIConversationTB-${region}-${account}-${rndInt}`;

    // Define the first DynamoDB table with the new schema
    this.GenAIDomainKBTB = new dynamodb.Table(this, "GenAIDomainKBTB", {
      partitionKey: { name: "domain_id", type: dynamodb.AttributeType.NUMBER },
      removalPolicy: cdk.RemovalPolicy.DESTROY, // Optional: helps with cleanup during development
      tableName: genAIDomainKBTBName,
    });

    // Add the GSI for knowledge_base_id
    this.GenAIDomainKBTB.addGlobalSecondaryIndex({
      indexName: "knowledge_base_id",
      partitionKey: {
        name: "knowledge_base_id",
        type: dynamodb.AttributeType.STRING,
      },
      projectionType: dynamodb.ProjectionType.ALL,
    });

    // Add the GSI for audit_domain and subdomain
    this.GenAIDomainKBTB.addGlobalSecondaryIndex({
      indexName: "audit_domain-subdomain-index",
      partitionKey: {
        name: "audit_domain",
        type: dynamodb.AttributeType.STRING,
      },
      sortKey: { name: "subdomain", type: dynamodb.AttributeType.STRING },
      projectionType: dynamodb.ProjectionType.ALL,
    });

    // provisioned mode
    this.GenAIDomainKBTB.autoScaleReadCapacity({
      minCapacity: 1,
      maxCapacity: 10,
    }).scaleOnUtilization({
      targetUtilizationPercent: 70,
    });

    this.GenAIDomainKBTB.autoScaleWriteCapacity({
      minCapacity: 1,
      maxCapacity: 10,
    }).scaleOnUtilization({
      targetUtilizationPercent: 70,
    });

    // Define the second DynamoDB table
    this.GenAIConversationTB = new dynamodb.Table(this, "GenAIConversationTB", {
      partitionKey: {
        name: "conversation_id",
        type: dynamodb.AttributeType.STRING,
      },
      removalPolicy: cdk.RemovalPolicy.DESTROY, // Optional: helps with cleanup during development
      tableName: GenAIConversationTBName,
    });

    // Add the GSI for user_email
    this.GenAIConversationTB.addGlobalSecondaryIndex({
      indexName: "user_email-index",
      partitionKey: { name: "user_email", type: dynamodb.AttributeType.STRING },
      projectionType: dynamodb.ProjectionType.ALL,
    });

    this.GenAIConversationTB.autoScaleReadCapacity({
      minCapacity: 1,
      maxCapacity: 10,
    }).scaleOnUtilization({
      targetUtilizationPercent: 70,
    });

    this.GenAIConversationTB.autoScaleWriteCapacity({
      minCapacity: 1,
      maxCapacity: 10,
    }).scaleOnUtilization({
      targetUtilizationPercent: 70,
    });
  }
}
