import * as lambda from "aws-cdk-lib/aws-lambda";
import * as events from "aws-cdk-lib/aws-events";
import * as targets from "aws-cdk-lib/aws-events-targets";
import * as GenAITypes from "../lib/GenAICdkTypes";
import * as cdk from "aws-cdk-lib";
import { Construct } from "constructs";
import { RustFunction } from "rust.aws-cdk-lambda";

interface EventBridgeStackProps extends cdk.StackProps {
  syncKBRLF: RustFunction;
  S3Info: GenAITypes.GenAIS3BucketInformation;
  LambdaFunctionInfo: GenAITypes.LambdaFunctions;
}
export class EventBridgeStack extends cdk.Stack {
  public readonly serviceRule: events.Rule;
  public readonly assignedTagsRule: events.Rule;
  public readonly syncCRONRule: events.Rule;

  constructor(scope: Construct, id: string, props: EventBridgeStackProps) {
    super(scope, id, props);

    const { syncKBRLF, S3Info, LambdaFunctionInfo } = props;
    // Define the EventBridge rule
    this.serviceRule = new events.Rule(
      this,
      "GenAI-ServiceS3ObjectCreatedRule",
      {
        eventPattern: {
          source: ["aws.s3"],
          detailType: ["Object Created"],
          detail: {
            bucket: {
              name: [S3Info.serviceLandingBucket.bucketName],
            },
          },
        },
      },
    );

    this.serviceRule.addTarget(
      new targets.LambdaFunction(LambdaFunctionInfo.assignServiceTags),
    );

    this.assignedTagsRule = new events.Rule(
      this,
      "GenAI-S3ObjectsTagsAddedRule",
      {
        eventPattern: {
          source: ["aws.s3"],
          detailType: ["Object Tags Added"],
          detail: {
            bucket: {
              name: [
                S3Info.serviceLandingBucket.bucketName,
                S3Info.userLandingBucket.bucketName,
              ],
            },
          },
        },
      },
    );

    this.assignedTagsRule.addTarget(
      new targets.LambdaFunction(LambdaFunctionInfo.loadKbData),
    );

    // Define the EventBridge rule
    this.syncCRONRule = new events.Rule(this, "ScheduleRule", {
      schedule: events.Schedule.rate(cdk.Duration.hours(24)), // rate(24 hours)
      enabled: true,
    });

    this.syncCRONRule.addTarget(new targets.LambdaFunction(syncKBRLF));
  }
}
