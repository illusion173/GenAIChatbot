import * as cdk from "aws-cdk-lib";
import * as lambda from "aws-cdk-lib/aws-lambda";
import * as dynamodb from "aws-cdk-lib/aws-dynamodb";
import * as iam from "aws-cdk-lib/aws-iam";
import * as GenAITypes from "../lib/GenAICdkTypes";
import { Construct } from "constructs";
import { RustFunction, Settings } from "rust.aws-cdk-lambda";
import path = require("path");

interface LambdaStackProps extends cdk.StackProps {
  S3Info: GenAITypes.GenAIS3BucketInformation;
  IAMInfo: GenAITypes.GenAIIamRoles;
  GenAIDomainTable: dynamodb.ITable;
  GenAIConversationTable: dynamodb.ITable;
}

export class LambdaStack extends cdk.Stack {
  public readonly LambdaInfo: GenAITypes.LambdaFunctions;

  constructor(scope: Construct, id: string, props: LambdaStackProps) {
    super(scope, id, props);

    const { S3Info, IAMInfo, GenAIDomainTable, GenAIConversationTable } = props;

    // Set the base Cargo workspace directory
    Settings.WORKSPACE_DIR = "lambdas";
    Settings.TARGET = "x86_64-unknown-linux-gnu";
    Settings.RUNTIME = lambda.Runtime.PROVIDED_AL2023;

    const region = cdk.Stack.of(this).region;
    const account = cdk.Stack.of(this).account;
    const rndInt = Math.floor(Math.random() * 10000000) + 1;

    const createRustFunction = (
      id: string,
      packageName: string,
      role: iam.Role,
      timeout: cdk.Duration,
      environment: { [key: string]: string },
    ) => {
      return new RustFunction(this, id, {
        package: packageName,
        setupLogging: true,
        functionName: `GenAI-${packageName}-${region}-${account}-${rndInt}`,
        role: role,
        timeout: timeout,
        environment: environment,
      });
    };

    this.LambdaInfo = {
      assignServiceTags: createRustFunction(
        "AssignServiceTagsRLF",
        "assignservicetags",
        IAMInfo.lambdaERAssignServiceTags,
        cdk.Duration.seconds(30),
        {
          DESTINATION_BUCKET: S3Info.serviceLandingBucket.bucketName,
          FAILED_BUCKET: S3Info.unsuppportedFileBucket.bucketName,
        },
      ),
      assignUserTags: createRustFunction(
        "AssignUserTagsRLF",
        "assignusertags",
        IAMInfo.lambdaERAssignUserTags,
        cdk.Duration.seconds(30),
        {
          USER_BUCKET: S3Info.userLandingBucket.bucketName,
          FAILED_BUCKET: S3Info.unsuppportedFileBucket.bucketName,
        },
      ),
      loadKbData: createRustFunction(
        "LoadKbDataRLF",
        "loadkbdata",
        IAMInfo.lambdaERLoadKbData,
        cdk.Duration.seconds(60),
        {
          DESTINATION_BUCKET: S3Info.dataSourceFileBucket.bucketName,
          FAILED_BUCKET: S3Info.unsuppportedFileBucket.bucketName,
          PROMPT_TABLE: GenAIDomainTable.tableName,
          WORK_BUCKET: S3Info.tempWorkBucket.bucketName,
        },
      ),
      chatbot: createRustFunction(
        "ChatbotRLF",
        "chatbot",
        IAMInfo.lambdaERChatbot,
        cdk.Duration.seconds(120),
        {
          DATA_SOURCE_BUCKET: S3Info.dataSourceFileBucket.bucketName,
          PROMPT_TABLE: GenAIDomainTable.tableName,
        },
      ),
      getDomainsSubdomains: createRustFunction(
        "GetDomainsSubdomainsRLF",
        "getdomainssubdomains",
        IAMInfo.lambdaERGetDomainsSubdomains,
        cdk.Duration.seconds(30),
        {
          PROMPT_TABLE: GenAIDomainTable.tableName,
        },
      ),
      getKnowledgeBaseId: createRustFunction(
        "GetKnowledgeBaseIdRLF",
        "getknowledgebaseid",
        IAMInfo.lambdaERGetKnowledgeBaseId,
        cdk.Duration.seconds(30),
        {
          PROMPT_TABLE: GenAIDomainTable.tableName,
        },
      ),
      grabConversation: createRustFunction(
        "GrabConversationRLF",
        "grabconversation",
        IAMInfo.lambdaERGrabConversation,
        cdk.Duration.seconds(30),
        {
          CONVERSATION_TABLE_NAME: GenAIConversationTable.tableName,
        },
      ),
      handleDownload: createRustFunction(
        "HandleDownloadRLF",
        "handledownload",
        IAMInfo.lambdaERHandleDownload,
        cdk.Duration.seconds(30),
        {
          DOWNLOAD_BUCKET: S3Info.dataSourceFileBucket.bucketName,
        },
      ),
      handleUpload: createRustFunction(
        "HandleUploadRLF",
        "handleupload",
        IAMInfo.lambdaERHandleUpload,
        cdk.Duration.seconds(30),
        {
          UPLOAD_BUCKET: S3Info.userLandingBucket.bucketName,
        },
      ),
      insertDomain: createRustFunction(
        "InsertDomainRLF",
        "insertdomain",
        IAMInfo.lambdaERInsertDomain,
        cdk.Duration.seconds(30),
        {
          PROMPT_TABLE: GenAIDomainTable.tableName,
        },
      ),
      listConversations: createRustFunction(
        "ListConversationsRLF",
        "listconversations",
        IAMInfo.lambdaERListConversation,
        cdk.Duration.seconds(30),
        {
          CONVERSATION_TABLE_NAME: GenAIConversationTable.tableName,
        },
      ),
      saveConversation: createRustFunction(
        "SaveConversationRLF",
        "saveconversation",
        IAMInfo.lambdaERSaveConversation,
        cdk.Duration.seconds(30),
        {
          CONVERSATION_TABLE_NAME: GenAIConversationTable.tableName,
        },
      ),
    };
  }
}
