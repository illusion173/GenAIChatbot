import boto3
import re
import datetime
import json

# Initialize a session using Amazon CloudWatch
client = boto3.client("logs")


def get_report_logs(log_group_name):
    # Define a paginator to handle log streams if there are many
    paginator = client.get_paginator("describe_log_streams")
    log_streams = []

    # Paginate through all log streams in the log group
    for page in paginator.paginate(logGroupName=log_group_name):
        log_streams.extend(page["logStreams"])

    report_logs = []

    # Retrieve log events from each log stream
    for log_stream in log_streams:
        log_stream_name = log_stream["logStreamName"]

        response = client.get_log_events(
            logGroupName=log_group_name,
            logStreamName=log_stream_name,
            startFromHead=True,
        )

        # Filter logs to include only those that have the "REPORT" message
        for event in response["events"]:
            message = event["message"]
            if re.search(r"\bREPORT\b", message):
                report_logs.append(message)

    return report_logs


def save_combined_logs_to_json(log_data):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    filename = (
        f"combined_report_logs_{timestamp.replace(':', '').replace(' ', '_')}.json"
    )

    # Add the timestamp to the log data
    log_data["created_at"] = timestamp

    with open(filename, "w") as file:
        json.dump(log_data, file, indent=4)

    print(f"Combined logs saved to {filename}")


if __name__ == "__main__":
    log_group_names = [
        "/aws/lambda/assignservicetags",
        "/aws/lambda/assignusertags",
    ]  # Example log group names
    combined_log_data = {}

    for log_group_name in log_group_names:
        report_logs = get_report_logs(log_group_name)
        combined_log_data[log_group_name] = report_logs

    save_combined_logs_to_json(combined_log_data)
