import boto3
import json
from datetime import datetime


def list_tables_and_check_encryption():
    # Initialize a session using Amazon DynamoDB
    dynamodb = boto3.client("dynamodb")

    # Retrieve a list of all tables
    response = dynamodb.list_tables()
    tables = response["TableNames"]

    # Dictionary to store encryption details
    encryption_details = {}

    # Check encryption settings for each table
    for table_name in tables:
        try:
            table_info = dynamodb.describe_table(TableName=table_name)
            # encryption = table_info["Table"]["SSEDescription"]
            encryption_details[table_name] = json_serializable(table_info)
        except dynamodb.exceptions.ClientError as e:
            error_code = e.response["Error"]["Code"]
            encryption_details[table_name] = {"error": str(e)}

    # Write the encryption details to a JSON file
    with open("dynamodbEncryptionDetails.json", "w") as json_file:
        json.dump(encryption_details, json_file, indent=4, default=str)


def json_serializable(obj):
    """
    Convert non-serializable datetime objects to strings.
    """
    if isinstance(obj, datetime):
        return obj.isoformat()
    elif isinstance(obj, dict):
        return {k: json_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [json_serializable(i) for i in obj]
    else:
        return obj


if __name__ == "__main__":
    list_tables_and_check_encryption()
