import boto3
import json
from datetime import datetime


def get_config_rules(client):
    rules = []
    paginator = client.get_paginator("describe_config_rules")
    for page in paginator.paginate():
        rules.extend(page["ConfigRules"])
    return rules


def get_compliance_by_config_rule(client, rule_name):
    response = client.get_compliance_details_by_config_rule(ConfigRuleName=rule_name)
    return response["EvaluationResults"]


def main():
    # Initialize the boto3 client
    client = boto3.client("config")

    # Retrieve all config rules
    config_rules = get_config_rules(client)

    # Collect findings
    findings = {}
    for rule in config_rules:
        rule_name = rule["ConfigRuleName"]
        findings[rule_name] = get_compliance_by_config_rule(client, rule_name)

    # Get current datetime
    current_datetime = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    # Prepare the output file name
    output_filename = f"config_findings_{current_datetime}.json"

    # Save findings to a JSON file
    with open(output_filename, "w") as outfile:
        json.dump(findings, outfile, indent=4, default=str)

    print(f"Findings have been saved to {output_filename}")


if __name__ == "__main__":
    main()
