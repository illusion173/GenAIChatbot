import boto3
import json


def list_buckets_and_check_encryption():
    # Initialize a session using Amazon S3
    s3 = boto3.client("s3")

    # Retrieve a list of all buckets
    response = s3.list_buckets()
    buckets = response["Buckets"]

    # Dictionary to store encryption details
    encryption_details = {}

    # Check encryption settings for each bucket
    for bucket in buckets:
        bucket_name = bucket["Name"]
        try:
            encryption_call_resp = s3.get_bucket_encryption(Bucket=bucket_name)
            encryption_details[bucket_name] = encryption_call_resp
            # print(encryption)
            # rules = encryption["ServerSideEncryptionConfiguration"]["Rules"]
            # encryption_details[bucket_name] = {"encryption": rules}
        except s3.exceptions.ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "ServerSideEncryptionConfigurationNotFoundError":
                encryption_details[bucket_name] = {
                    "encryption": None,
                    "message": "No encryption at rest enabled.",
                }
            else:
                encryption_details[bucket_name] = {"error": str(e)}

    # Write the encryption details to a JSON file
    with open("s3EncryptionDetails.json", "w") as json_file:
        json.dump(encryption_details, json_file, indent=4)


if __name__ == "__main__":
    list_buckets_and_check_encryption()
