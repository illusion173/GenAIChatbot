import boto3
import json


def list_users_and_analyze_access():
    # Initialize a session using Amazon IAM
    iam = boto3.client("iam")
    access_analyzer = boto3.client("accessanalyzer")

    # Retrieve a list of all IAM users
    response = iam.list_users()
    users = response["Users"]

    access_analyzer_arn = (
        "arn:aws:access-analyzer:us-east-1:533267267261:analyzer/analyzer-JW-Mac-Intern"
    )

    # Analyze access for each user
    for user in users:
        user_name = user["UserName"]
        try:

            # Get the findings for the analyzer
            findings = access_analyzer.list_findings(analyzerArn=access_analyzer_arn)

            # Output the findings to a JSON file
            with open(f"{user_name}AccessAnalysis.json", "w") as json_file:
                json.dump(findings, json_file, indent=4, default=str)

        except iam.exceptions.ClientError as e:
            error_code = e.response["Error"]["Code"]
            print(f"Error analyzing access for user {user_name}: {e}")


if __name__ == "__main__":
    list_users_and_analyze_access()
