import boto3
import json


def describe_all_instances():
    # Initialize the boto3 client for EC2
    ec2 = boto3.client("ec2")

    # Describe all instances
    response = ec2.describe_instances()

    # Initialize an empty list to hold all instance details
    all_instances_details = []

    # Iterate through all reservations and instances
    for reservation in response["Reservations"]:
        for instance in reservation["Instances"]:
            all_instances_details.append(instance)

    # Print the complete details in a pretty-printed JSON format
    print(json.dumps(all_instances_details, indent=4, default=str))

    # Optionally, save the details to a file
    output_filename = "all_instances_details.json"
    with open(output_filename, "w") as outfile:
        json.dump(all_instances_details, outfile, indent=4, default=str)

    print(f"All instance details have been saved to {output_filename}")


if __name__ == "__main__":
    describe_all_instances()
