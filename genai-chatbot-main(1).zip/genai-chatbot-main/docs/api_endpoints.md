# API Endpoints for GenAiChatbot

Based on API Gateway, AWS Cognito is additionally needed for authenticated calls.

## Upload File

### Query String Params

```json
    file_name: String,
    domain : String,
    sub_domain: String
```

### Response Body

```json
UploadResponse {
    presigned_url: String,
}
```

## Assign Object Tags

### Request Body

```json
UserTagSubmission {
    file_key: String, // domain/subdomain/filename
    phi: bool,
    pii: bool,
    summarize: bool,
    image_type: Option<String>,
}
```

### Response Body

```json
"Success Message"
```

## Download File

### Query String Params

```json
    file_key: String,  // This will need to be built within the website. domain/subdomain/filename
```

### Response Body

```json
ResponseDownload {
    presigned_url: String,
}
```

## Retrieve Knowledge Base Id

### Query String Params

```json
    domain: String,
    sub_domain: String,
```

### Response Body

```json
ResponseKnowledgeBaseId {
    knowledge_base_id: String,
}
```

## Initiate Chatbot Session

### Request Body

```json
UserChatbotRequest {
    question: String,
    knowledge_base_id: String,
}
```

### Response Body

```json
// Response
ChatBotResponse {
    answer: String,
    session_id: String,
    knowledge_base_id: String,
    related_objects: Option<Vec<RelatedCitation>>, // Option means it may exist, in Rust, a vector is a continous growable array.
}

// Related Type
RelatedCitation {
    pub file_key: String,
    pub cited_text: String,
}
```

## Continue Chatbot Session

### Request

```json

UserChatbotRequest {
    question: String,
    session_id: String
    knowledge_base_id: String,
}
```

### Response

```json
ChatBotResponse {
    answer: String,
    session_id: String,
    knowledge_base_id: String,
    related_objects: Option<Vec<S3object>>, // Option means it may exist, in Rust, a vector is a continous growable array.
}

// Related Type
S3object {
    bucket: String,
    key: String,
}
```
