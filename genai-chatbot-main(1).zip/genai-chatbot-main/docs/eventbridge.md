# EventBridge Rules And Related Information

## Rules

#### SyncKnowledgeBase Rule

### Description

This rule is an EventBridge job that triggers the beginsynckb lambda function. Run every 24 hr via a [rate-based schedule](https://docs.aws.amazon.com/scheduler/latest/UserGuide/schedule-types.html?icmpid=docs_console_unmapped#rate-based).
(Made in Console for now)

#### Services S3 Tag Assignment Rule

### Description

This EventBridge pattern refers to when a service uploads an item to its respective bucket and domain/subdomain. \
This rule triggers the lambda function assignservicetags.

**Pattern**

```json
{
  "source": ["aws.s3"],
  "detail-type": ["Object Created"],
  "detail": {
    "bucket": {
      "name": ["servicelandingbucketnamehere"]
    },
    "object": {
      "key": [
        {
          "prefix": "infrastructure/"
        },
        {
          "prefix": "performance/"
        },
        {
          "prefix": "security/"
        },
        {
          "prefix": "legal/"
        },
        {
          "prefix": "financial/"
        }
      ]
    }
  }
}
```

#### Load Into KB Processing

### Description

This EventBridge pattern refers to when any object from the service and user uploaded has retrieved tags and is considered ready for processing into the knowledge base. \
This rule triggers the lambda function loadkbdata.

**Pattern**

```json
{
  "source": ["aws.s3"],
  "detail-type": ["Object Tags Added"],
  "detail": {
    "bucket": {
      "name": ["servicelandingbucketnamehere", "userlandingbucketnamehere"]
    }
  }
}
```
