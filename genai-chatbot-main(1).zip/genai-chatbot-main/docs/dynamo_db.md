# Information Regarding DynamoDB

# Description

GenAI Chatbot is powered by two dynamodb table.

- The "Domain Table" which contains the information related to the audit domain and sub domain. Must have all of the data points in the schema for it to work.
- The "Conversation Table" which contains saved conversation information between the user and the chatbot.

## Schema for Domain table

| domain_id: Number | audit_domain: String             | subdomain: String             | knowledge_base_id: String | data_source_ids: List[String] | invoke_prompt: String | gen_prompt: String | model_id: String |
| ----------------- | -------------------------------- | ----------------------------- | ------------------------- | ----------------------------- | --------------------- | ------------------ | ---------------- |
| Primary Key       | GSI: audit-sub-index Primary Key | GSI: audit-sub-index Sort Key | GSI: knowledge_base_id    |                               |                       |                    |                  |

### Column Explanation

- domain_id: A random int id for the system to index on. Randomly assigned.
- audit_domain: What the user types to be the main audit domain they want to talk about
- the subdomain: What the user types to be in the subdomain (ex. security/dataprotection).
- knowledge_base_id: Retrieve this value from bedrock, this will be the knowledge base id for the domain & subdomain.
- data_source_ids: Retrievee this value from bedrock, this will be the list of string data source ids the knowledge base sources its RAG from.
- invoke_prompt: When the user wants to summarize (via the tag system) an object, the llm will use this prompt to summarize the object.
- gen_prompt: The chatbot will use this as its system context prompt.
- model_id: The llm model arn that the bedrock will use for the summarization and chatbot for that audit domain.

## Schema for Conversation Table

| conversation_id: String | audit_domain: String | conversation_title: String | datetime_submitted: String | knowledge_base_id: String | messages: List[Map] | saved_file_list: List[String] | session_id: String | sub_domain: String | user_email: String                |
| ----------------------- | -------------------- | -------------------------- | -------------------------- | ------------------------- | ------------------- | ----------------------------- | ------------------ | ------------------ | --------------------------------- |
| Primary Key             |                      |                            |                            |                           |                     |                               |                    |                    | GSI: user_email-index Primary Key |

### Message Details

| from: String | text: String | related_citations: List[Map] |
| ------------ | ------------ | ---------------------------- |

### Citation Details

| cited_text: String | file_key: String |
| ------------------ | ---------------- |
