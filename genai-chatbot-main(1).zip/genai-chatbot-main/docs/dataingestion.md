# Overall View of Data Ingestion in GenAiChatbot

## User Uploaded Files

1. User requests presigned url to upload file from react web client.
2. User uses presigned url to upload file into respective bucket with domain/subdomain.
3. User adds tags via http request from react web client, this runs assignusertags lambda function.
4. EventBridge detects that tags were assigned, pass file to Lambda loadkbdata.
5. Depending on tags, new files may be created, initial files may be summarized by the model itself.
6. Lambda stores the file and related metadata file to the knowledge base bucket.
7. Every 24 hour cron job runs synckb to sync a knowledge base with the data source(s).

## Service Uploaded Files

1. Service places item into respective s3 bucket into domain/subdomain.
2. EventBridge detects an item was placed, runs assignservicetags lambda function.
3. EventBridge detects an item had tags placed, runs loadkbdata lambda function.
4. Depending on tags, new files may be created, initial files may be summarized by the model itself.
5. Lambda stores the file and related metadta file to the knowledge base bucket.
6. Every 24 hour cron job runs synckb to sync a knowledge base with the data source(s).
