# Related Chatbot Information

In order for a user to do RAG interactions with the chatbot, they must access via the react web client.

The Chatbot operates as follows:

1. The user defines the specific audit domain and subdomain they want to ask and do RAG retrievals on.
2. An API Gateway request is done, getknowledgebaseid lambda function is ran and returns the required knowledge base id.
3. User begins a chat by asking a question.
4. The initial question, with the specific knowledge base id, is sent via API Gateway to the lambda function chatbot.
5. The lambda function will search for the generation prompt based on the knowledge base id.
6. The lambda function will then do a RAG call based on the generation prompt, the specific knowledge base, and the question the user has asked.
7. The lambda function will return the answer, a session id, the used knowledge base id, and a list of object bucket and key pairs that the chatbot used to generate the response as citations.
8. To continue the conversation the user will have to do another call, similar to step 4, but with the session id.
9. From this point, users can then download related files from the citations returned by the chatbot via the react web client.
