# Instructions Related for CDK deployment

# **REQUIREMENTS READ ME FIRST**

Before moving on, please download and install the required tools and libraries for this project to work properly.

- Download and install the [Rust Programming Language](https://www.rust-lang.org/) version 1.80.1

- Install [Python3](https://www.python.org/downloads/)

- Download and install the [AWS ClI](https://aws.amazon.com/cli/) V2.

- Ensure you have [npm and nodejs](https://nodejs.org/en), latest version.

- Ensure you have an IAM Role with permissions to provision aws resources from access keys.

- Configure AWS cli with retrieved access keys.

- Install AWS Amplify by `npm install -g @aws-amplify/cli`, latest version.

- [Configure Amplify](https://docs.amplify.aws/gen1/javascript/tools/cli/start/set-up-cli/)

- Install and configure [Cargo Lambda](https://www.cargo-lambda.info/) for Rust Deployment on AWS.

- Read getting started with the [AWS CDK V2](https://docs.aws.amazon.com/cdk/v2/guide/getting_started.html)

# Backend Deployment

- Ensure you have valid permissions to deploy resources from a cloudformation/cdk stack.

- Navigate to infra directory

- ```
  npm i
  ```

- ```
  npm run build
  ```

- ```
  cdk synth
  ```

- ```
  cdk deploy --app "npx ts-node --prefer-ts-exts bin/infra.ts" --all
  ```

- After cdk deployment, to add a knowledge base you add it to the appropriate dynamodb table, with the data following the set schema in the [docs](/docs/dynamo_db.md).
- After adding the knowledgebase to the dynamodb, add appropriate folders to the servicelanding, userlanding and datasource buckets depending on your desired domains/subdomains.
- Example: if my domain is security with subdomain dataprotection I would need to add the security folder and the dataprotection folder inside.
- Remember to sync the knowledgebase after uploading, without syncing the knowledgebase will not ingest the new information entered S3.
- There is a step function that does this automatically, check the cdk stack for the rate.

# Frontend Deployment

**NOTE** Must complete the backend cdk deployment FIRST.

- Go into the s3 console.

- Inside the created "genai-webdeploy" bucket that is created after the cdk deployment, there is a folder src/ with a file named amplifyconfiguration.json.

- Insert this file into the src/ folder of the next js project, this will resolve API calls, Cognito authentication endpoints, sign in, etc.

- Create a user in the Cognito Console, the created group name should start with "GenAI-CognitoUserPool", attach the user to the created User Group.

- Run the npm commands as stated in the [frontend docs](../genaifrontend/README.md) to run it locally.

- From this point, the website can be deployed from Amplify Hosting itself, and can be hosted as a static website from S3, CodeCommit and Github.

# Editing the CDK

- Navigate to infra

- The directory "lambdas" contain all current Rust Lambda functions that get deployed by the cdk. For proper editing, I'd recommend editing the "backend" folder lambdas first then copying the code to the "infra/Lambdas" directory.

- Make sure to remove the env vars and IAM Roles from the cargo.toml after copying to the infra directory, the env vars and roles are resolved at cdk compile time.

- The directory "lib" contains all the stacks that GenAI bot depends on to run.

# Editing the Lambda Functions

- Ensure to read and download the requirements above.

- Please note, the current lambdas folder inside the infra folder is what is deployed into your own when you run the CDK stack into your account.

- DO NOT REMOVE or CHANGE lambda directory names until viewing how [Rust Lambda functions are deployed on CDK](../infra/lib/lambda-stack.ts).

- Rust relies on [WORKSPACES](../infra/lambdas/Cargo.toml) for compilation, and individual CARGO.tomls for dependencies.

- For more information on the Rust programming language, see [the Rust Book](https://doc.rust-lang.org/book/).
