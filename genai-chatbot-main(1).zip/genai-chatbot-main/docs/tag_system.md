# Tag System Information

## Description

In order to facilitate granular control of different types of files, one can assign object tags.

## Adding new tags to the system

Please look into [assignservicetags](../backend/lambdas/assignservicetags/) to add new service tag analyzation.
Please look into [assignusertags](../backend/lambdas/assignusertags/) to add new user tag analyzation.
About adding add tags to the system, look into the struct stated in [genaitypes](../backend/lambdas/genaitypes/src/lib.rs).

### Adding Tags To Object - Service

When objects are inputted into the base landing bucket, an eventbridge rule triggers a lambda function to assign tags.

#### Curent Supported Service Tags

| Tag         | phi: bool                                   | pii: bool                                   | summarize: bool                                                                                                                                                                                         | image_type: String                                                                                          |
| ----------- | ------------------------------------------- | ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| Options     | true,false                                  | true, false                                 | true, false                                                                                                                                                                                             | "document", "expense", "general"                                                                            |
| Explanation | Tell the system if the file may contain PHI | Tell the system if the file may contain PII | Tell the system that you want to summarize the findings in the file, this will be done by the llm designated in the domain/subdomain. The "invoke_prompt" is the prompt that will be used to summarize. | Allowed image types: document (for forms and general documents), expense (for receipts and expense reports) |

### Adding Tags to a User Uploaded Object - User Upload

To add tags for user uploaded objects, the user must use the react web client when uploading the file.

#### Current Supported User Tags

| Tag         | phi: bool                                   | pii: bool                                   | summarize: bool                                                                                                                                                                                         | image_type: String                                                                                          |
| ----------- | ------------------------------------------- | ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| Options     | true,false                                  | true, false                                 | true, false                                                                                                                                                                                             | "document", "expense", "general"                                                                            |
| Explanation | Tell the system if the file may contain PHI | Tell the system if the file may contain PII | Tell the system that you want to summarize the findings in the file, this will be done by the llm designated in the domain/subdomain. The "invoke_prompt" is the prompt that will be used to summarize. | Allowed image types: document (for forms and general documents), expense (for receipts and expense reports) |
