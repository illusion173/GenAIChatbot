# Sync Knowledge Base Step Function

## Description

Currently, knowlwedge bases only support one data source to be synced at a time. See [quotas](https://docs.aws.amazon.com/bedrock/latest/userguide/quotas.html) for more.

As a result, one must do a an asynchronous ingestion if the knowledge base has multiple data sources.

This step function facilitates this operation.

To see where the step function is called to run, please see the [lambda](/docs/lambdas.md) function beginsynckb.

For the lambda functions called in this step function, please see [lambdas](/docs/lambdas.md), primarily, startingestkb and checkingestkb.

**Json Definition of Step Function**

```json
{
  "Comment": "A description of my state machine",
  "StartAt": "StartIngestionJob",
  "States": {
    "StartIngestionJob": {
      "Type": "Task",
      "Resource": "arn:aws:states:::lambda:invoke",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-east-1:533267267261:function:startingestkb:$LATEST",
        "Payload": {
          "knowledge_base_id.$": "$.knowledge_base_id",
          "data_source_ids.$": "$.data_source_ids",
          "len_ds_ids.$": "$.len_ds_ids",
          "current_idx.$": "$.current_idx"
        }
      },
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException",
            "Lambda.TooManyRequestsException"
          ],
          "IntervalSeconds": 1,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "Next": "Wait",
      "OutputPath": "$.Payload"
    },
    "Wait": {
      "Type": "Wait",
      "Seconds": 15,
      "Next": "CheckIngestKBJob"
    },
    "CheckIngestKBJob": {
      "Type": "Task",
      "Resource": "arn:aws:states:::lambda:invoke",
      "OutputPath": "$.Payload",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-east-1:533267267261:function:checkingestkb:$LATEST",
        "Payload": {
          "knowledge_base_id.$": "$.knowledge_base_id",
          "data_source_ids.$": "$.data_source_ids",
          "len_ds_ids.$": "$.len_ds_ids",
          "current_idx.$": "$.current_idx",
          "job_id.$": "$.job_id"
        }
      },
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException",
            "Lambda.TooManyRequestsException"
          ],
          "IntervalSeconds": 1,
          "MaxAttempts": 3,
          "BackoffRate": 2
        }
      ],
      "Next": "Choice"
    },
    "Choice": {
      "Type": "Choice",
      "Choices": [
        {
          "Variable": "$.current_idx",
          "NumericLessThanPath": "$.len_ds_ids",
          "Next": "Wait (1)"
        },
        {
          "Variable": "$.current_idx",
          "NumericEqualsPath": "$.len_ds_ids",
          "Next": "Success"
        }
      ]
    },
    "Wait (1)": {
      "Type": "Wait",
      "Next": "CheckIngestKBJob",
      "Seconds": 30
    },
    "Success": {
      "Type": "Succeed"
    }
  }
}
```
