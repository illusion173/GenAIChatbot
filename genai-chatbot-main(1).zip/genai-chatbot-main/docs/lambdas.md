# Lambda Function Information

## Description

The Lambda functions used in this solution are written in Rust.

Rust is a multi-paradigm, general-purpose programming language focused on safety, performance, and concurrency, designed to prevent common programming errors such as null pointer dereferencing and buffer overflows. It achieves memory safety without garbage collection, making it ideal for performance-critical applications.

For more information please visit:

- [Rustlang Org](https://www.rust-lang.org/) for installation.
- ["The Book"](https://doc.rust-lang.org/book/) to learn how Rust works.
- [AWS Rust SDK](https://aws.amazon.com/sdk-for-rust/) to learn how to program Rust on AWS.
- [Cargo Lambda](https://www.cargo-lambda.info/) to learn how to build and deploy Rust Lambda functions on AWS.

## Permissions

To see permissions for these lambda functions, please see [IAM.md](/docs/IAM.md)

## Compilation

For compilation, one must use [Cargo Lambda Build Instructions](https://www.cargo-lambda.info/commands/build.html).
Navigate to backend/lambdas.

```bash
cargo lambda build --release
```

## Deployment

For deployment, one must use [Cargo Lambda Deploy Instructions](https://www.cargo-lambda.info/commands/deploy.html)

```bash
cargo lambda deploy lambdafunctionnamehere

```

For this project, a sh script is made to automate deployment. Navigate to backend/lambdas, see [deploylambdas.sh](../backend/lambdas/deploylambdas.sh).

This script relies on locally set permissions to an IAM account via Acess Keys.

## API Lambdas

These lambda functions are called by API Gateway from the front end.

To see their inputs and outputs, see [API Endpoints](/docs/api_endpoints.md)

### getknowledgebaseid [Code](../backend/lambdas/getknowledgebaseid/)

#### Description

This lambda function operates as a handler for a user's request to retrieve the knowledge base id for the specific domain/subdomain. It will be called by API Gateway.

The user must state what domain/subdomain they want to work with and thus get the proper knowledge base id to initiate the conversation with the chatbot.

### chatbot [Code](../backend/lambdas/chatbot/)

#### Description

This lambda operates as the handler for a user's question from the front end. This lambda will be called by API Gateway.

### handledownload [Code](../backend/lambdas/handledownload/)

#### Description

This lambda operates as a handler for a user's request from the front end to download a file. The user will use bucket and s3 key to get a presigned url to download from.

### handleupload [Code](../backend/lambdas/handleupload/)

#### Description

This lambda operates as a handler for a user's request from the front end to upload a file. The user will only be allowed to upload the allowed file types as defined in the code.

This lambda function responds with a presigned url.

### assignusertags [Code](../backend/lambdas/assignusertags/)

#### Description

This lambda operates as a handler for a user's request from the front end to assign tags to a file. The user will be presented options in the front end to assign specific tags to the s3 object.
This lambda will only be ran after the uploading of a file.

## System Lambdas

These lambdas are internal and are not exposed to the user.

### assignservicetags [Code](../backend/lambdas/assignservicetags/)

#### Description

When an AWS service, (or really any other file inputted), can be logically assigned service tags. This is primarily done through the code itself, so if one wants to add a new tag, please see [tag system](/docs/tag_system.md) for instructions.

### beginsynckb [Code](../backend/lambdas/beginsynckb/)

#### Description

This lambda function serves as a starting point to begin the syncing of knowledge bases with their respective data source(s) asynchronously.
This lambda function is triggered by a cron job by eventbridge, for further information click [here](/docs/eventbridge.md).
This lambda function goes off the values in the [dynamodb table](/docs/dynamo_db.md). The values that are needed are the knowledge base id and data source ids.
This lambda will then trigger a step function and input the values derive from the dynamo_db table, see [synckb-step-function](/docs/synckb-step-function.md) for further details.

### startingestkb [Code](../backend/lambdas/startingestkb/)

#### Description

This lambda function operates as the physical calling to bedrock to initiate a data source sync. This function is ran in the [synckb-step-function](/docs/synckb-step-function.md).

### loadkbdata [Code](../backend/lambdas/loadkbdata/)

#### Description

This lambda function is triggered by an eventbridge rule, Load Into KB Processing, see [here](/docs/eventbridge.md).
This lambda function is triggered when an object inside the service and user buckets have been assigned tags.
This function does specific jobs based on the file type, if its a service or user uploaded file, and for more granular control of files, one can use the valid s3 object tags.
[Tag System](/docs/tag_system.md)
