use serde::{Deserialize, Serialize};

// CURRENTLY ALLOWED TYPES
#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct UserTagSubmission {
    pub file_key: String,
    pub phi: bool,
    pub pii: bool,
    pub summarize: bool,
    pub image_type: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct S3Detail {
    pub version: String,
    pub bucket: S3Bucket,
    pub object: S3Object,
    #[serde(rename = "request-id")]
    pub request_id: String,
    pub requester: String,
    #[serde(rename = "source-ip-address")]
    pub source_ip_address: String,
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct S3Bucket {
    pub name: String,
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct S3Object {
    pub key: String,
    pub etag: String,
    #[serde(rename = "version-id")]
    pub version_id: Option<String>,
}

// beginsynckb struct
#[derive(Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct DynamoTableIdRow {
    pub knowledge_base_id: String,
    pub data_source_ids: Vec<String>,
    pub len_ds_ids: Option<usize>,
    pub current_idx: Option<usize>,
}

// startingestkb struct
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct StartKnowledgeBaseSyncInfo {
    pub knowledge_base_id: String,
    pub data_source_ids: Vec<String>,
    pub len_ds_ids: usize,
    pub current_idx: usize,
    pub job_id: Option<String>,
}

//checkingestkb types
#[derive(Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct CheckKnowledgeBaseSyncInfo {
    pub knowledge_base_id: String,
    pub data_source_ids: Vec<String>,
    pub len_ds_ids: usize,
    pub current_idx: usize,
    pub job_id: String,
}

// chatbot types
#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct UserChatbotRequest {
    pub question: String,
    pub session_id: Option<String>,
    pub knowledge_base_id: String,
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct RelatedCitation {
    pub file_key: String,
    pub cited_text: String,
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct ChatBotResponse {
    pub answer: String,
    pub session_id: String,
    pub knowledge_base_id: String,
    pub related_citations: Option<Vec<RelatedCitation>>,
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct Message {
    pub from: String,
    pub text: String,
    pub related_citations: Option<Vec<RelatedCitation>>,
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct SaveConversationRequest {
    pub datetime_submitted: String,
    pub conversation_id: String,
    pub conversation_title: String,
    pub knowledge_base_id: String,
    pub session_id: String,
    pub audit_domain: String,
    pub sub_domain: String,
    pub saved_file_list: Vec<String>,
    pub messages: Vec<Message>,
    pub user_email: String,
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct DomainData {
    pub domain_id: u32,
    pub audit_domain: String,
    pub data_source_ids: Vec<String>,
    pub gen_prompt: String,
    pub invoke_prompt: String,
    pub knowledge_base_id: String,
    pub model_id: String,
    pub subdomain: String,
}
