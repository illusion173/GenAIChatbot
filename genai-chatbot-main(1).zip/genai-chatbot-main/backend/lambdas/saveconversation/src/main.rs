use std::collections::HashMap;

use aws_sdk_dynamodb::types::AttributeValue;
use aws_sdk_dynamodb::Client;
use lambda_http::{
    run, service_fn,
    tracing::{self, info},
    Body, Error, Request, RequestExt, Response,
};

async fn insert_conversation_row(
    table_name: &str,
    conversation_request: genaitypes::SaveConversationRequest,
) -> Result<(), Error> {
    let config = aws_config::load_from_env().await;
    let client = Client::new(&config);

    let mut item = HashMap::new();
    item.insert(
        "datetime_submitted".to_owned(),
        AttributeValue::S(conversation_request.datetime_submitted),
    );
    item.insert(
        "conversation_id".to_owned(),
        AttributeValue::S(conversation_request.conversation_id),
    );
    item.insert(
        "conversation_title".to_owned(),
        AttributeValue::S(conversation_request.conversation_title),
    );
    item.insert(
        "knowledge_base_id".to_owned(),
        AttributeValue::S(conversation_request.knowledge_base_id),
    );
    item.insert(
        "session_id".to_owned(),
        AttributeValue::S(conversation_request.session_id),
    );
    item.insert(
        "audit_domain".to_owned(),
        AttributeValue::S(conversation_request.audit_domain),
    );
    item.insert(
        "sub_domain".to_owned(),
        AttributeValue::S(conversation_request.sub_domain),
    );
    item.insert(
        "user_email".to_owned(),
        AttributeValue::S(conversation_request.user_email),
    );

    let saved_file_list = conversation_request
        .saved_file_list
        .into_iter()
        .map(AttributeValue::S)
        .collect();
    item.insert(
        "saved_file_list".to_owned(),
        AttributeValue::L(saved_file_list),
    );

    let messages = conversation_request
        .messages
        .into_iter()
        .map(|msg| {
            let mut msg_map = HashMap::new();
            msg_map.insert("from".to_string(), AttributeValue::S(msg.from));
            msg_map.insert("text".to_string(), AttributeValue::S(msg.text));
            if let Some(citations) = msg.related_citations {
                let citations_list = citations
                    .into_iter()
                    .map(|citation| {
                        let mut citation_map = HashMap::new();
                        citation_map.insert(
                            "cited_text".to_owned(),
                            AttributeValue::S(citation.cited_text),
                        );
                        citation_map
                            .insert("file_key".to_owned(), AttributeValue::S(citation.file_key));
                        AttributeValue::M(citation_map)
                    })
                    .collect();
                msg_map.insert(
                    "related_citations".to_string(),
                    AttributeValue::L(citations_list),
                );
            }
            AttributeValue::M(msg_map)
        })
        .collect();
    item.insert("messages".to_owned(), AttributeValue::L(messages));

    client
        .put_item()
        .table_name(table_name)
        .set_item(Some(item))
        .send()
        .await?;

    Ok(())
}

async fn function_handler(event: Request) -> Result<Response<Body>, Error> {
    let conversation_table_name =
        std::env::var("CONVERSATION_TABLE_NAME").expect("CONVERSATION_TABLE_NAME must be set.");

    // Extract some useful information from the request
    let body_str = match std::str::from_utf8(event.body().as_ref()) {
        Ok(body_str) => body_str,
        Err(_error) => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,POST")
                .status(400)
                .body(Body::from("Unable to derive request body, utf-8 error?"))
                .expect("Failed to build a response"))
        }
    };

    let conversation_request_struct: genaitypes::SaveConversationRequest =
        match serde_json::from_str(body_str) {
            Ok(conversation_request_request) => conversation_request_request,
            Err(error) => {
                let error_msg = format!("ERROR: {:?}", error);
                info!(error_msg);
                return Ok(Response::builder()
                    .header("content-type", "application/json")
                    .header("Access-Control-Allow-Origin", "*")
                    .header("Access-Control-Allow-Methods", "OPTIONS,POST")
                    .status(400)
                    .body(Body::from("Invalid Request Body, may be missing a key?"))
                    .expect("Failed to build a response, for deserialize operation."));
            }
        };

    // Insert the conversation request into DynamoDB
    match insert_conversation_row(&conversation_table_name, conversation_request_struct).await {
        Ok(_) => {
            let message = "Success Inputting Conversation";
            let resp = Response::builder()
                .status(200)
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,POST")
                .header("content-type", "text/html")
                .body(message.into())
                .map_err(Box::new)?;
            Ok(resp)
        }
        Err(err) => {
            eprintln!("Error inserting into DynamoDB: {:?}", err);
            let message = "Failed to input conversation";
            let resp = Response::builder()
                .status(500)
                .header("content-type", "text/html")
                .body(message.into())
                .map_err(Box::new)?;
            Ok(resp)
        }
    }
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();
    run(service_fn(function_handler)).await
}
