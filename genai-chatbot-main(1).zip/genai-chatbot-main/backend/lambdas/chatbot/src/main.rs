use bedrock_wrapper::bedrock_rag;
use lambda_http::{run, service_fn, tracing, Body, Error, Request, Response};
mod bedrock_wrapper;
mod db_wrapper;
use genaitypes::*;
async fn function_handler(event: Request) -> Result<Response<Body>, Error> {
    // Extract some useful information from the request
    let body_str = match std::str::from_utf8(event.body().as_ref()) {
        Ok(body_str) => body_str,
        Err(_error) => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(400)
                .body(Body::from("Unable to derive request body, utf-8 error?"))
                .expect("Failed to build a response"))
        }
    };

    let chat_request: UserChatbotRequest = match serde_json::from_str(body_str) {
        Ok(user_chat_bot_request) => user_chat_bot_request,
        Err(_error) => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(400)
                .body(Body::from(
                    "Invalid Request Body,may be missing question,knowledge_base_id ",
                ))
                .expect("Failed to build a response, for deserialize operation."))
        }
    };

    let chat_response: ChatBotResponse = match bedrock_rag(
        chat_request.session_id,
        chat_request.knowledge_base_id.as_str(),
        chat_request.question.as_str(),
    )
    .await
    {
        Ok(chatbotresponsesuceed) => chatbotresponsesuceed,
        Err(error) => {
            println! {"{:?}",error};
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(400)
                .body(Body::from("Error while trying to RAG, check cloudwatch?"))
                .expect("Failed to build a response, for deserialize operation."));
        }
    };

    // We need to return both message back, s3 objects related, session id
    let chat_response_string = serde_json::to_string(&chat_response)?;

    // Return something that implements IntoResponse.
    // It will be serialized to the right response event automatically by the runtime
    let resp = Response::builder()
        .status(200)
        .header("content-type", "application/json")
        .header("Access-Control-Allow-Origin", "*")
        .header("Access-Control-Allow-Methods", "OPTIONS,GET")
        .body(chat_response_string.into())
        .map_err(Box::new)?;
    Ok(resp)
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
