use aws_sdk_dynamodb::types::AttributeValue;
use aws_sdk_dynamodb::Client as DynamoDbClient;
use lambda_http::Error;
use std::env;

pub async fn get_model_id(knowledge_base_id: &str) -> Result<String, Error> {
    let config = aws_config::load_from_env().await;
    let prompt_table_name = env::var("PROMPT_TABLE").expect("PROMPT_TABLE must be set.");

    let client = DynamoDbClient::new(&config);
    let global_secondary_index_name = "knowledge_base_id";
    // Define the projection expression to specify the attributes to retrieve
    let attribute_needed = "model_id";

    // Execute the query
    let result = client
        .query()
        .table_name(prompt_table_name)
        .index_name(global_secondary_index_name)
        .key_condition_expression("#k = :v")
        .expression_attribute_names("#k", "knowledge_base_id")
        .expression_attribute_values(":v", AttributeValue::S(knowledge_base_id.to_string()))
        .projection_expression(attribute_needed)
        .send()
        .await?;

    let items = result
        .items
        .expect("No items? Check prompt table and query.");
    // Get the first item from the vec
    if let Some(first_item) = items.get(0) {
        if let Some(attr_value) = first_item.get(attribute_needed) {
            if let AttributeValue::S(generation_prompt) = attr_value {
                return Ok(generation_prompt.clone());
            }
        }
    }

    let error_msg = format!("No item found for knowledge_base_id: {}", knowledge_base_id);
    return Err(error_msg.into());
}

pub async fn get_generation_prompt(knowledge_base_id: &str) -> Result<String, Error> {
    let config = aws_config::load_from_env().await;
    let prompt_table_name = env::var("PROMPT_TABLE").expect("PROMPT_TABLE must be set.");

    let client = DynamoDbClient::new(&config);
    let global_secondary_index_name = "knowledge_base_id";
    // Define the projection expression to specify the attributes to retrieve
    let attribute_needed = "gen_prompt";

    // Execute the query
    let result = client
        .query()
        .table_name(prompt_table_name)
        .index_name(global_secondary_index_name)
        .key_condition_expression("#k = :v")
        .expression_attribute_names("#k", "knowledge_base_id")
        .expression_attribute_values(":v", AttributeValue::S(knowledge_base_id.to_string()))
        .projection_expression(attribute_needed)
        .send()
        .await?;

    let items = result
        .items
        .expect("No items? Check prompt table and query.");
    // Get the first item from the vec
    if let Some(first_item) = items.get(0) {
        if let Some(attr_value) = first_item.get(attribute_needed) {
            if let AttributeValue::S(generation_prompt) = attr_value {
                return Ok(generation_prompt.clone());
            }
        }
    }

    let error_msg = format!("No item found for knowledge_base_id: {}", knowledge_base_id);
    return Err(error_msg.into());
}
