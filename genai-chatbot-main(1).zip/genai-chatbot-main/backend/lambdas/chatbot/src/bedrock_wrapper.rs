use super::db_wrapper;

use aws_sdk_bedrockagentruntime::operation::retrieve_and_generate::RetrieveAndGenerateOutput;
use aws_sdk_bedrockagentruntime::types::InferenceConfig;
use aws_sdk_bedrockagentruntime::types::KnowledgeBaseRetrievalConfiguration;
use aws_sdk_bedrockagentruntime::types::KnowledgeBaseVectorSearchConfiguration;
use aws_sdk_bedrockagentruntime::types::PromptTemplate;
use aws_sdk_bedrockagentruntime::types::SearchType;
use aws_sdk_bedrockagentruntime::types::TextInferenceConfig;
use aws_sdk_bedrockagentruntime::types::{
    GenerationConfiguration, KnowledgeBaseRetrieveAndGenerateConfiguration,
    RetrieveAndGenerateInput, RetrieveAndGenerateType,
};
use aws_sdk_bedrockagentruntime::{
    self as bedrockagentruntime, types::RetrieveAndGenerateConfiguration,
};
use genaitypes::*;
use lambda_http::tracing::info;
use lambda_http::Error;

fn parse_s3_uri(s3_uri: &str) -> Result<(String, String), Error> {
    // Ensure the URI starts with "s3://"
    if !s3_uri.starts_with("s3://") {
        return Err(format!("Incorrect S3 URL prefix. url: {}", s3_uri).into());
    }

    // Strip the "s3://" prefix
    let stripped_uri = &s3_uri[5..];

    // Find the first '/' after the bucket name
    if let Some(pos) = stripped_uri.find('/') {
        let bucket = &stripped_uri[..pos];
        let key = &stripped_uri[pos + 1..];
        Ok((bucket.to_string(), key.to_string()))
    } else {
        return Err(format!("Invalid S3 URI: url: {}", s3_uri).into());
    }
}

pub async fn bedrock_rag(
    session_id: Option<String>,
    knowledge_base_id: &str,
    question: &str,
) -> Result<ChatBotResponse, Error> {
    let config = aws_config::load_from_env().await;
    let bedrock_client = bedrockagentruntime::Client::new(&config);

    // Step 3: Use the builder to create the RetrieveAndGenerateInput instance

    let temperature: f32 = 0.1;
    let number_of_results: i32 = 50;
    let input_question = RetrieveAndGenerateInput::builder().text(question).build()?;

    //let retrieval_configuration = debug_asser
    let chatbot_prompt_string = db_wrapper::get_generation_prompt(knowledge_base_id).await?;

    let model_id_arn = db_wrapper::get_model_id(knowledge_base_id).await?;
    let prompt_template = PromptTemplate::builder()
        .text_prompt_template(chatbot_prompt_string)
        .build();
    let text_inference_config = TextInferenceConfig::builder()
        .temperature(temperature)
        .build();
    let inference_config = InferenceConfig::builder()
        .text_inference_config(text_inference_config)
        .build();
    let knowledge_base_vector_config = KnowledgeBaseVectorSearchConfiguration::builder()
        .number_of_results(number_of_results)
        .override_search_type(SearchType::Hybrid)
        .build();
    let retrieval_config = KnowledgeBaseRetrievalConfiguration::builder()
        .vector_search_configuration(knowledge_base_vector_config)
        .build();
    let generation_configuration = GenerationConfiguration::builder()
        .prompt_template(prompt_template)
        .inference_config(inference_config)
        .build();
    let knowledge_base_rag_config = KnowledgeBaseRetrieveAndGenerateConfiguration::builder()
        .knowledge_base_id(knowledge_base_id)
        .model_arn(model_id_arn)
        .retrieval_configuration(retrieval_config)
        .generation_configuration(generation_configuration)
        .build()?;
    let full_rag_config = RetrieveAndGenerateConfiguration::builder()
        .r#type(RetrieveAndGenerateType::KnowledgeBase)
        .knowledge_base_configuration(knowledge_base_rag_config)
        .build()?;
    let response: RetrieveAndGenerateOutput = bedrock_client
        .retrieve_and_generate()
        .set_session_id(session_id)
        .input(input_question)
        .retrieve_and_generate_configuration(full_rag_config)
        .send()
        .await?;

    let chatbot_output = response
        .output
        .expect("Expected a response output from chatbot, check cloudwatch logs.");
    let chatbot_answer = chatbot_output.text;
    let confirmed_session_id = response.session_id;
    let confirmed_knowledge_base_id = knowledge_base_id.to_string();
    // Initialize related_objects as None
    //let mut related_object_vec: Option<Vec<types::S3object>> = None;

    let mut related_citation_vec: Vec<RelatedCitation> = vec![];

    if let Some(citations) = response.citations {
        info!("{:?}", citations);
        for citation in citations {
            let mut new_related_citation: RelatedCitation = RelatedCitation {
                file_key: "".to_string(),
                cited_text: "".to_string(),
            };

            if let Some(retrieved_references) = citation.retrieved_references {
                for reference in retrieved_references {
                    if let Some(content) = reference.content {
                        new_related_citation.cited_text = content.text;
                    }
                    if let Some(s3_uri) = reference
                        .location
                        .and_then(|loc| loc.s3_location)
                        .and_then(|s3| s3.uri)
                    {
                        match parse_s3_uri(&s3_uri) {
                            Ok((bucket, key)) => {
                                info!("{:?}", bucket);
                                info!("{:?}", key);
                                //let string_to_remove = format!("{}")
                                //let result = original_string.replace(string_to_remove, "");
                                new_related_citation.file_key = key;
                            }
                            Err(e) => {
                                return Err(format!("Error Msg While RAG {}", e).into());
                            }
                        }
                    }
                }
            }
            related_citation_vec.push(new_related_citation.clone());
        }

        let chatbot_response_struct = ChatBotResponse {
            answer: chatbot_answer,
            session_id: confirmed_session_id,
            knowledge_base_id: confirmed_knowledge_base_id,
            related_citations: Some(related_citation_vec),
        };
        Ok(chatbot_response_struct)
    } else {
        let chatbot_response_struct = ChatBotResponse {
            answer: chatbot_answer,
            session_id: confirmed_session_id,
            knowledge_base_id: confirmed_knowledge_base_id,
            related_citations: Some(related_citation_vec),
        };
        Ok(chatbot_response_struct)
    }
}
