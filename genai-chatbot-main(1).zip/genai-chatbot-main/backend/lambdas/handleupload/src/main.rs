use aws_sdk_s3::Client as S3Client;
use aws_sdk_s3::{self, presigning::PresigningConfig};
use lambda_http::{run, service_fn, tracing, Body, Error, Request, RequestExt, Response};
use serde::{Deserialize, Serialize};
use std::env;
use std::time::Duration;

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
struct UploadRequest {
    file_name: String,
    domain: String,
    subdomain: String,
}
#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
struct UploadResponse {
    presigned_url: String,
}

async fn put_object(bucket: &str, object: &str, expires_in: u64) -> Result<String, Error> {
    let config = aws_config::load_from_env().await;
    let s3_client = S3Client::new(&config);

    let expires_in = Duration::from_secs(expires_in);

    let presigned_request = s3_client
        .put_object()
        .bucket(bucket)
        .key(object)
        .presigned(PresigningConfig::expires_in(expires_in)?)
        .await?;

    println!("Object URI: {}", presigned_request.uri());
    let presigned_url = presigned_request.uri().to_string();

    Ok(presigned_url)
}

async fn function_handler(event: Request) -> Result<Response<Body>, Error> {
    // Verify Upload Bucket has been set
    let upload_bucket = env::var("UPLOAD_BUCKET").expect("UPLOAD_BUCKET must be set");
    // Extract some useful information from the request
    // Get query string parameters
    let query_string_params = event.query_string_parameters();

    //let filename = query_string_params.first("file_name");
    let audit_domain = match query_string_params.first("domain") {
        Some(audit_domain_string) => audit_domain_string,
        None => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(400)
                .body(Body::from("Missing audit_domain query str param?"))
                .expect("Failed to build a response"))
        }
    };
    let sub_domain = match query_string_params.first("sub_domain") {
        Some(sub_domain_string) => sub_domain_string,
        None => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(400)
                .body(Body::from("Missing sub_domain query str param?"))
                .expect("Failed to build a response"))
        }
    };

    let file_name = match query_string_params.first("file_name") {
        Some(file_name_string) => file_name_string,
        None => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(400)
                .body(Body::from("Missing file_name query str param?"))
                .expect("Failed to build a response"))
        }
    };

    // So the user needs to pass in the category & (Optional) subcategory, this will be used to create the key.
    let destination_key: String;

    destination_key = format!("{}/{}/{}", audit_domain, sub_domain, file_name);
    // 600 seconds for upload time
    let presigned_url_string = put_object(upload_bucket.as_str(), &destination_key, 600).await?;

    let response_struct = UploadResponse {
        presigned_url: presigned_url_string,
    };
    let response_string =
        serde_json::to_string(&response_struct).expect("Failed to serailize json response");
    // Return something that implements IntoResponse.
    // It will be serialized to the right response event automatically by the runtime
    let resp = Response::builder()
        .status(200)
        .header("content-type", "application/json")
        .header("Access-Control-Allow-Origin", "*")
        .header("Access-Control-Allow-Methods", "OPTIONS,GET")
        .body(response_string.into())
        .map_err(Box::new)?;
    Ok(resp)
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
