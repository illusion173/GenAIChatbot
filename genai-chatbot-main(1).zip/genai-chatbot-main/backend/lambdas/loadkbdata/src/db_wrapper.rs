use super::types;
use aws_sdk_dynamodb::types::Select;
use aws_sdk_dynamodb::Client as DynamoDbClient;
use aws_sdk_dynamodb::{operation::query::QueryInput, types::AttributeValue};
use lambda_runtime::Error;
use std::{collections::HashMap, env};
pub async fn get_prompt_info(domain: &str, subdomain: &str) -> Result<types::PromptRowInfo, Error> {
    let config = aws_config::load_from_env().await;
    let prompt_table_name = env::var("PROMPT_TABLE").expect("PROMPT_TABLE must be set.");

    let client = DynamoDbClient::new(&config);

    let attributes_needed = "model_id, invoke_prompt";
    let partition_key = "audit_domain";
    let sort_key = "subdomain";
    let index_name = "audit_domain-subdomain-index";

    // Create the query input
    let response = client
        .query()
        .table_name(prompt_table_name)
        .index_name(index_name)
        .key_condition_expression("#pk = :pkval AND #sk = :skval")
        .expression_attribute_names("#pk", partition_key)
        .expression_attribute_names("#sk", sort_key)
        .expression_attribute_values(":pkval", AttributeValue::S(domain.to_string()))
        .expression_attribute_values(":skval", AttributeValue::S(subdomain.to_string()))
        .projection_expression(attributes_needed)
        .send()
        .await?;

    // Perform the query
    //

    // Retrieve the first item from the query response
    if let Some(items) = response.items {
        if let Some(first_item) = items.into_iter().next() {
            let prompt_item: types::PromptRowInfo = serde_dynamo::from_item(first_item)
                .expect("No Prompt in item row. Check DynamoDB prompt table.");
            return Ok(prompt_item);
        } else {
            return Err("No item found in dynamodb response".into());
        }
    }
    return Err("No items found in dynamodb response".into());
}
