use super::db_wrapper;
use super::storage_wrapper;
use lambda_runtime::tracing::info;
use lambda_runtime::Error;
/// Define the structure for the EventBridge event containing S3 details
use serde::{Deserialize, Serialize};
use std::{collections::HashMap, env, path::Path};
use uuid::Uuid;

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct PromptRowInfo {
    pub model_id: String,
    pub invoke_prompt: String,
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct ObjectTags {
    pub provider_type: String,
    pub datetime: String,
    pub phi: bool,
    pub pii: bool,
    pub image_type: Option<String>,
    pub summarize: bool,
    pub related_source_file: Option<String>,
}

impl ObjectTags {
    pub fn from_hashmap(map: &HashMap<String, String>) -> Self {
        let phi = map
            .get("phi")
            .map(|v| v.parse::<bool>().expect("Expected boolean for 'phi'"));
        let pii = map
            .get("pii")
            .map(|v| v.parse::<bool>().expect("Expected boolean for 'pii'"));
        let summarize = map
            .get("summarize")
            .map(|v| v.parse::<bool>().expect("Expected boolean for 'summarize'"));
        let image_type = map.get("image_type").cloned();
        let provider_type = map
            .get("providertype")
            .expect("Expected a provider type. user or service.")
            .clone();
        let datetime = map
            .get("datetime")
            .expect("Expected an assigned datetime for the object in the object tag.")
            .clone();

        ObjectTags {
            provider_type,
            datetime,
            phi: phi.unwrap_or(false),
            pii: pii.unwrap_or(false),
            image_type,
            summarize: summarize.unwrap_or(false),
            related_source_file: None,
        }
    }

    pub fn to_hashmap(&self) -> HashMap<String, String> {
        let mut map = HashMap::new();
        map.insert("provider_type".to_string(), self.provider_type.clone());
        map.insert("datetime".to_string(), self.datetime.clone());
        map.insert("phi".to_string(), self.phi.to_string());
        map.insert("pii".to_string(), self.pii.to_string());
        map.insert("summarize".to_string(), self.summarize.to_string());
        if let Some(ref image_type) = self.image_type {
            map.insert("image_type".to_string(), image_type.clone());
        }
        if let Some(ref related_source_file) = self.related_source_file {
            map.insert(
                "related_source_file".to_string(),
                related_source_file.clone(),
            );
        }

        map
    }
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct ObjectInfo {
    pub source_bucket_name: String,
    pub source_key: String,
    pub destination_bucket: String,
    pub destination_key: String,
    pub associated_tags: ObjectTags,
    pub file_extension: String,
    pub provider_type: String,
    pub domain: String,
    pub subdomain: String,
    pub failed_bucket: String,
    pub model_id: String,
    pub invoke_prompt: String,
    pub time_str: String,
    pub summary_file_key: String,
    pub object_id: String,
    pub filename_without_extension: String,
    pub summary_metadata_file_key: String,
    pub generated_text_metadata_file_key: String,
    pub generated_text_destination_key: String,
    pub work_bucket_name: String,
}
fn sanitize_key(key: &str) -> String {
    key.chars()
        .map(|c| match c {
            ':' | '+' => '_', // Replace ':' and '+' with '_'
            _ => c,           // Keep other characters unchanged
        })
        .collect()
}

impl ObjectInfo {
    pub async fn new(source_bucket_name: String, source_key: String) -> Result<Self, Error> {
        // Essentially check if the env vars are set, if not PANIC and stop program
        let destination_bucket =
            env::var("DESTINATION_BUCKET").expect("DESTINATION_BUCKET must be set.");
        let failed_bucket = env::var("FAILED_BUCKET").expect("FAILED_BUCKET must be set.");
        let work_bucket = env::var("WORK_BUCKET").expect("WORK_BUCKET MUST BE SET");
        let mut tags_struct =
            storage_wrapper::retrieve_object_tags(source_bucket_name.as_str(), source_key.as_str())
                .await?;

        // We need to again ensure that the file type is valid.
        let extension = Path::new(&source_key)
            .extension()
            .expect("Unable to build file extension, path, check s3 uri.")
            .to_str()
            .expect("Extension is not valid UTF-8");

        // Split file_key into domain, subdomain, and filename parts
        let domain_parts: Vec<&str> = source_key.split('/').collect();

        // Ensure we have at least three parts (domain, subdomain, and filename)
        if domain_parts.len() < 3 {
            return Err(
            "Expected at least three elements in the file key to extract domain, subdomain, and filename.".into()
        );
        }

        // Extract domain, subdomain, and filename with extension
        let domain = domain_parts[0]; // "security"
        let subdomain = domain_parts[1]; // "compliance"
        let filename_with_extension = domain_parts.last().unwrap();
        // Remove the extension from filename
        let filename_without_extension = {
            let path = Path::new(filename_with_extension);
            let stem = path.file_stem().unwrap().to_str().unwrap();
            if stem.contains('.') {
                let stem_path = Path::new(stem);
                stem_path.file_stem().unwrap().to_str().unwrap()
            } else {
                stem
            }
        };

        let prompt_info_struct: PromptRowInfo =
            db_wrapper::get_prompt_info(domain, subdomain).await?;

        let object_id = Uuid::new_v4().to_string();

        // Original submitted file key transformed.
        let destination_source_file_key: String = format!(
            "{}/{}/{}_{}_{}",
            domain,
            subdomain,
            object_id,
            tags_struct.datetime.to_string(),
            filename_with_extension
        );

        tags_struct.related_source_file = Some(destination_source_file_key.clone());

        let summary_metadata_file_key = format!(
            "{}/{}/{}_{}_SUMMARY_{}.txt.metadata.json",
            domain,
            subdomain,
            object_id,
            tags_struct.datetime.to_string(),
            filename_without_extension
        );

        let summary_file_key = format!(
            "{}/{}/{}_{}_SUMMARY_{}.txt",
            domain,
            subdomain,
            object_id,
            tags_struct.datetime.to_string(),
            filename_without_extension
        );

        let mut generated_text_metadata_file_key = format!(
            "{}/{}/{}_{}_{}.txt.metadata.json",
            domain,
            subdomain,
            object_id,
            tags_struct.datetime.to_string(),
            filename_without_extension
        );
        let mut generated_text_destination_key = format!(
            "{}/{}/{}_{}_{}.txt",
            domain,
            subdomain,
            object_id,
            tags_struct.datetime.to_string(),
            filename_without_extension
        );

        let document_extensions = vec!["txt", "md", "html", "doc", "docx", "pdf"];

        if document_extensions.contains(&extension) {
            generated_text_metadata_file_key = format!(
                "{}/{}/{}_{}_{}.metadata.json",
                domain,
                subdomain,
                object_id,
                tags_struct.datetime.to_string(),
                filename_with_extension
            );
        }

        let audio_video_extensions = vec!["mp4", "webm", "mp3", "amr", "flac", "m4a", "ogg", "wav"];

        if audio_video_extensions.contains(&extension) {
            generated_text_metadata_file_key =
                sanitize_key(generated_text_metadata_file_key.as_str());
            generated_text_destination_key = sanitize_key(generated_text_destination_key.as_str());
        }

        Ok(ObjectInfo {
            source_bucket_name,
            source_key: source_key.to_owned(),
            destination_bucket,
            destination_key: destination_source_file_key,
            summary_metadata_file_key,
            summary_file_key,
            generated_text_metadata_file_key,
            generated_text_destination_key,
            file_extension: extension.to_string(),
            provider_type: tags_struct.provider_type.to_string(),
            associated_tags: tags_struct.clone(),
            domain: domain.to_string(),
            subdomain: subdomain.to_string(),
            failed_bucket,
            model_id: prompt_info_struct.model_id,
            invoke_prompt: prompt_info_struct.invoke_prompt,
            time_str: tags_struct.datetime.to_string(),
            object_id,
            filename_without_extension: filename_without_extension.to_string(),
            work_bucket_name: work_bucket,
        })
    }
}
