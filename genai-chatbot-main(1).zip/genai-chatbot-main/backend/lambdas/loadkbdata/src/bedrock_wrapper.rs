use aws_sdk_bedrockruntime::operation::invoke_model::InvokeModelOutput;
use aws_sdk_s3::primitives::Blob;
use bytes::Bytes;
use lambda_runtime::{tracing::info, Error};
use regex::Regex;
use serde_json::{json, Value};
pub async fn summarize_object(
    prompt: &str,
    transcript: &str,
    model_id: &str,
) -> Result<Bytes, Error> {
    // First we need to filter the transcript

    // Regex patterns
    let html_remover = Regex::new(r#"<[^>]*>"#).unwrap();
    let filler_remover = Regex::new(r#"(^| )([Uu]m|[Uu]h|[Ll]ike|[Mm]hm)[,]?"#).unwrap();

    // Remove triple backticks if present (direct string replace in Rust)
    let generated_text = transcript.replace("```", "");

    // Remove HTML tags using regex
    let generated_text = html_remover.replace_all(&generated_text, "");

    // Remove filler words using regex
    let generated_text = filler_remover.replace_all(&generated_text, "");

    let prompt_with_transcript = format!("{}", prompt.replace("{TRANSCRIPT}", &generated_text));

    let config = aws_config::load_from_env().await;

    let bedrock_client = aws_sdk_bedrockruntime::Client::new(&config);
    let body_json = json!({
        "max_tokens": 4096,
        "temperature": 1,
        "messages": [{"role": "user", "content": prompt_with_transcript}],
        "anthropic_version": "bedrock-2023-05-31"
    })
    .to_string();

    let blob_body = Blob::new(body_json.as_bytes());

    let response: InvokeModelOutput = bedrock_client
        .invoke_model()
        .body(blob_body)
        .content_type("application/json".to_string())
        .model_id(model_id)
        .send()
        .await?;

    // Check if response body exists
    let response_body_bytes = response.body().as_ref();

    // Deserialize response body JSON
    let response_body: Value = serde_json::from_slice(response_body_bytes)?;
    info!("RESPONSE BODY FROM INVOKEMODEL: {:?}", response_body);
    // Get the text response from the body
    let text_body = response_body["content"][0]["text"]
        .as_str()
        .expect("Response body is missing 'content[0].text' field")
        .to_string();

    let text_body_bytes = Bytes::from(text_body);

    Ok(text_body_bytes)
}
