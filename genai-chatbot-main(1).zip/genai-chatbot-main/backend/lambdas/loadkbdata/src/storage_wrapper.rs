// Acts as an s3 storage wrapper for files.
//
//
use aws_sdk_s3::primitives::ByteStream;
//use aws_sdk_s3::types::{Tag, Tagging};
use super::types;
use aws_sdk_s3::Client as S3Client;
use bytes::Bytes;
use lambda_runtime::{tracing, Error};
use serde::Serialize;
use std::collections::HashMap;
use tracing::info;
use url::form_urlencoded;
#[derive(Serialize)]
struct MetadataAttributes {
    #[allow(non_snake_case)]
    metadataAttributes: HashMap<String, String>,
}

pub async fn retrieve_object_tags(
    bucket: &str,
    file_key: &str,
) -> Result<types::ObjectTags, Error> {
    let config = aws_config::load_from_env().await;
    let s3_client = S3Client::new(&config);

    // Get the object's tags
    let response = s3_client
        .get_object_tagging()
        .bucket(bucket)
        .key(file_key)
        .send()
        .await?;

    // Vector to store the tags as hash maps
    let mut tags_map = HashMap::new();

    info!("{:?}", response);
    for tag in response.tag_set() {
        let key = tag.key().to_string();
        let value = tag.value().to_string();
        tags_map.insert(key, value);
    }
    info!("{:?}", tags_map);

    let tag_struct = types::ObjectTags::from_hashmap(&tags_map);

    Ok(tag_struct)
}
pub async fn copy_object(
    source_bucket: &str,
    source_key: &str,
    destination_bucket: &str,
    destination_key: &str,
) -> Result<(), Error> {
    let config = aws_config::load_from_env().await;
    let s3_client = S3Client::new(&config);

    let copy_source = format!("{}/{}", source_bucket, source_key);
    info!("COPY SOURCE:");
    info!("{:?}", copy_source);

    let proper_copy_source: String =
        form_urlencoded::byte_serialize(copy_source.as_bytes()).collect();

    s3_client
        .copy_object()
        .copy_source(proper_copy_source)
        .bucket(destination_bucket)
        .key(destination_key)
        .send()
        .await?;

    Ok(())
}

pub async fn delete_object(source_bucket: &str, source_key: &str) -> Result<(), Error> {
    let config = aws_config::load_from_env().await;
    let s3_client = S3Client::new(&config);
    s3_client
        .delete_object()
        .bucket(source_bucket)
        .key(source_key)
        .send()
        .await?;
    Ok(())
}

pub async fn get_object(source_bucket: &str, source_key: &str) -> Result<Bytes, Error> {
    let config = aws_config::load_from_env().await;
    let s3client = S3Client::new(&config);

    let response = s3client
        .get_object()
        .bucket(source_bucket)
        .key(source_key)
        .send()
        .await?;

    let data = response.body.collect().await?;
    let file_content = data.into_bytes();

    Ok(file_content)
}

pub async fn put_object(
    destination_bucket: &str,
    destination_key: &str,
    data: Bytes,
) -> Result<(), Error> {
    let config = aws_config::load_from_env().await;
    let s3client = S3Client::new(&config);
    let body = ByteStream::from(data);
    s3client
        .put_object()
        .bucket(destination_bucket)
        .key(destination_key)
        .body(body)
        .send()
        .await?;
    Ok(())
}

pub async fn create_object_metadata_file(
    tag_hashmap: &HashMap<String, String>,
    destination_bucket: &str,
    destination_key: &str,
) -> Result<(), Error> {
    // Create the MetadataAttributes struct
    let metadata_attributes = MetadataAttributes {
        metadataAttributes: tag_hashmap.clone(),
    };
    let json_data = serde_json::to_vec(&metadata_attributes).unwrap();
    //
    let metadata_binary = Bytes::from(json_data);

    put_object(destination_bucket, destination_key, metadata_binary).await?;
    Ok(())
}
