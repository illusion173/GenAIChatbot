use super::bedrock_wrapper;
use super::storage_wrapper;
use super::types;
use aws_sdk_textract::operation::analyze_expense::AnalyzeExpenseOutput;
use aws_sdk_textract::types::{Document, FeatureType};
use aws_sdk_textract::Client as textractClient;
use bytes::Bytes;
use lambda_runtime::tracing;
use lambda_runtime::Error;
use serde_json::{json, Value};
use tracing::info;

pub async fn handle_documents_forms(object_info: types::ObjectInfo) -> Result<(), Error> {
    let config = aws_config::load_from_env().await;

    let textract_client = textractClient::new(&config);

    let s3_object = aws_sdk_textract::types::S3Object::builder()
        .bucket(object_info.source_bucket_name.to_owned())
        .name(object_info.source_key.to_owned())
        .build();

    // Create the document to be analyzed
    let document = Document::builder().s3_object(s3_object).build();

    // Call the AnalyzeDocument API
    let result = textract_client
        .analyze_document()
        .document(document)
        .set_feature_types(Some(vec![FeatureType::Forms, FeatureType::Tables]))
        .send()
        .await?;

    info!("Item Info {:?}", object_info);

    // Transform the data
    let filtered_blocks: Vec<Value> = result
        .blocks
        .unwrap_or_default()
        .iter()
        .map(|block| {
            let mut filtered_block = serde_json::Map::new();

            // Insert BlockType
            if let Some(block_type) = &block.block_type {
                filtered_block.insert("BlockType".to_string(), json!(block_type.to_string()));
            }

            // Insert Id
            if let Some(id) = &block.id {
                filtered_block.insert("Id".to_string(), json!(id.to_string()));
            }

            // Insert Text
            if let Some(text) = &block.text {
                filtered_block.insert("Text".to_string(), json!(text.to_owned()));
            }

            // Insert Relationships
            if let Some(relationships) = &block.relationships {
                let relationships_json: Vec<Value> = relationships
                    .iter()
                    .map(|rel| {
                        let mut rel_map = serde_json::Map::new();
                        if let Some(rel_type) = &rel.r#type {
                            rel_map.insert("Type".to_string(), json!(rel_type.to_string()));
                        }
                        if let Some(ids) = &rel.ids {
                            rel_map.insert("Ids".to_string(), json!(ids));
                        }
                        Value::Object(rel_map)
                    })
                    .collect();
                filtered_block.insert("Relationships".to_string(), json!(relationships_json));
            }

            // Insert RowIndex
            if let Some(row_index) = &block.row_index {
                filtered_block.insert("RowIndex".to_string(), json!(row_index));
            }

            // Insert ColumnIndex
            if let Some(column_index) = &block.column_index {
                filtered_block.insert("ColumnIndex".to_string(), json!(column_index));
            }

            // Insert EntityTypes
            if let Some(entity_types) = &block.entity_types {
                let entity_types_vec: Vec<String> =
                    entity_types.iter().map(|ent| ent.to_string()).collect();
                filtered_block.insert("EntityTypes".to_string(), json!(entity_types_vec));
            }

            // Insert TextType
            if let Some(text_type) = &block.text_type {
                filtered_block.insert("TextType".to_string(), json!(text_type.to_string()));
            }

            Value::Object(filtered_block)
        })
        .collect();
    // Create the filtered JSON structure
    let filtered_json_string = json!({ "Blocks": filtered_blocks }).to_string();
    let filtered_json_string = serde_json::to_string_pretty(&filtered_json_string)?;

    let tag_map = object_info.associated_tags.to_hashmap();

    // the user wants to summarize the data.
    if object_info.associated_tags.summarize {
        let summarize_object = bedrock_wrapper::summarize_object(
            object_info.invoke_prompt.as_str(),
            filtered_json_string.as_str(),
            object_info.model_id.as_str(),
        )
        .await?;

        // Put the summarized object in S3
        storage_wrapper::put_object(
            object_info.destination_bucket.as_str(),
            object_info.summary_file_key.as_str(),
            summarize_object,
        )
        .await?;
        // Create the metadata file for the summary.
        storage_wrapper::create_object_metadata_file(
            &tag_map,
            object_info.destination_bucket.as_str(),
            object_info.summary_metadata_file_key.as_str(),
        )
        .await?;
    }

    // Copy over the original image
    storage_wrapper::copy_object(
        object_info.source_bucket_name.as_str(),
        object_info.source_key.as_str(),
        object_info.destination_bucket.as_str(),
        object_info.destination_key.as_str(),
    )
    .await?;

    let filtered_json_bytes = Bytes::from(filtered_json_string);

    // Put the findings Json into a txt in s3
    storage_wrapper::put_object(
        object_info.destination_key.as_str(),
        object_info.generated_text_destination_key.as_str(),
        filtered_json_bytes,
    )
    .await?;

    // Put the findings json metadata in s3.
    storage_wrapper::create_object_metadata_file(
        &tag_map,
        object_info.destination_bucket.as_str(),
        object_info.generated_text_metadata_file_key.as_str(),
    )
    .await?;

    Ok(())
}

pub async fn handle_expense(object_info: types::ObjectInfo) -> Result<(), Error> {
    let config = aws_config::load_from_env().await;
    let textract_client = textractClient::new(&config);
    let s3_object = aws_sdk_textract::types::S3Object::builder()
        .bucket(object_info.source_bucket_name.to_owned())
        .name(object_info.source_key.to_owned())
        .build();

    let expense_document_s3 = Document::builder().s3_object(s3_object).build();

    let result: AnalyzeExpenseOutput = textract_client
        .analyze_expense()
        .document(expense_document_s3)
        .send()
        .await?;

    info!("Expense Document Check for Item {:?}", object_info.clone());
    let expense_documents = result
        .expense_documents
        .expect("Expected expense_documents item from result in expense");

    let expense_document_json = format!("{:#?}", expense_documents);

    let expense_document_json = json!({ "expense_documents": expense_document_json }).to_string();
    let expense_document_json = serde_json::to_string_pretty(&expense_document_json)?;

    let tag_map = object_info.associated_tags.to_hashmap();
    // the user wants to summarize the data.
    if object_info.associated_tags.summarize {
        let summarize_object = bedrock_wrapper::summarize_object(
            object_info.invoke_prompt.as_str(),
            expense_document_json.as_str(),
            object_info.model_id.as_str(),
        )
        .await?;

        // Put the summarized object in S3
        storage_wrapper::put_object(
            object_info.destination_bucket.as_str(),
            object_info.summary_file_key.as_str(),
            summarize_object,
        )
        .await?;
        // Create the metadata file for the summary.
        storage_wrapper::create_object_metadata_file(
            &tag_map,
            object_info.destination_bucket.as_str(),
            object_info.summary_metadata_file_key.as_str(),
        )
        .await?;
    }
    // Copy over the original image
    storage_wrapper::copy_object(
        object_info.source_bucket_name.as_str(),
        object_info.source_key.as_str(),
        object_info.destination_bucket.as_str(),
        object_info.destination_key.as_str(),
    )
    .await?;

    let expense_document_json_bytes = Bytes::from(expense_document_json);

    // Put the findings Json into a txt in s3
    storage_wrapper::put_object(
        object_info.destination_key.as_str(),
        object_info.generated_text_destination_key.as_str(),
        expense_document_json_bytes,
    )
    .await?;

    // Put the findings json metadata in s3.
    storage_wrapper::create_object_metadata_file(
        &tag_map,
        object_info.destination_bucket.as_str(),
        object_info.generated_text_metadata_file_key.as_str(),
    )
    .await?;

    Ok(())
}
