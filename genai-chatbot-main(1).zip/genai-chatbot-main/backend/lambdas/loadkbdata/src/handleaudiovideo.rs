use super::bedrock_wrapper;
use super::storage_wrapper;
use super::types;
use aws_sdk_transcribe::operation::get_transcription_job::GetTranscriptionJobOutput;
use aws_sdk_transcribe::operation::start_transcription_job::StartTranscriptionJobOutput;
use aws_sdk_transcribe::types::Media;
use aws_sdk_transcribe::types::{LanguageCode, MediaFormat};
use aws_sdk_transcribe::Client as TranscribeClient;
use bytes::Bytes;
use lambda_runtime::Error;
use serde_json::{json, Value};
use std::time::Duration;
use tokio::time::sleep;
use uuid::Uuid;

/// Helper function to map file extensions to MediaFormat for Transcribe
fn get_media_format(file_extension: &str) -> Option<MediaFormat> {
    match file_extension.to_lowercase().as_str() {
        "mp3" => Some(MediaFormat::Mp3),
        "amr" => Some(MediaFormat::Amr),
        "flac" => Some(MediaFormat::Flac),
        "m4a" => Some(MediaFormat::Mp4), // M4A is usually associated with MP4 format
        "ogg" => Some(MediaFormat::Ogg),
        "wav" => Some(MediaFormat::Wav),
        "mp4" => Some(MediaFormat::Mp4),
        "webm" => Some(MediaFormat::Webm),
        _ => None, // Return None if the extension is not recognized
    }
}

/// Function to handle video/audio transcription and optional summarization
pub async fn handle_audio_video(object_info: types::ObjectInfo) -> Result<(), Error> {
    // Convert associated tags to a hashmap for later use
    let tag_map = object_info.associated_tags.to_hashmap();

    // Load AWS config and create a Transcribe client
    let config = aws_config::load_from_env().await;
    let transcribe_client = TranscribeClient::new(&config);

    // Determine the media format based on the file extension
    let media_format = get_media_format(&object_info.file_extension)
        .ok_or_else(|| Error::from("Unsupported media format"))?;

    let language_code = LanguageCode::EnUs;
    let job_name = Uuid::new_v4();

    // Construct the S3 URI for the media file
    let media_file_url = format!(
        "s3://{}/{}",
        object_info.source_bucket_name, object_info.source_key
    );

    if object_info.associated_tags.summarize {
        // If summarization is enabled, start the transcription job with summarization

        let start_response: StartTranscriptionJobOutput = transcribe_client
            .start_transcription_job()
            .transcription_job_name(job_name.to_string())
            .language_code(language_code.clone())
            .media_format(media_format.clone())
            .media(
                Media::builder()
                    .media_file_uri(media_file_url.clone())
                    .build(),
            )
            .output_bucket_name(object_info.work_bucket_name.clone())
            .output_key(object_info.generated_text_destination_key.clone())
            .send()
            .await?;

        // Poll for the transcription job completion
        loop {
            let get_response: GetTranscriptionJobOutput = transcribe_client
                .get_transcription_job()
                .transcription_job_name(job_name.to_string())
                .send()
                .await?;

            let status = get_response
                .transcription_job()
                .unwrap()
                .transcription_job_status()
                .unwrap();

            match status.as_str() {
                "COMPLETED" => {
                    // Process the completed transcription job
                    process_transcription_with_summarization(&object_info, &tag_map).await?;
                    break;
                }
                "FAILED" => {
                    return Err(Error::from("Transcription job failed"));
                }
                _ => {
                    // Wait before polling again
                    sleep(Duration::from_secs(10)).await;
                }
            }
        }
    } else {
        // If summarization is not enabled, start the transcription job without summarization

        let start_response: StartTranscriptionJobOutput = transcribe_client
            .start_transcription_job()
            .transcription_job_name(job_name.to_string())
            .language_code(language_code.clone())
            .media_format(media_format.clone())
            .media(
                Media::builder()
                    .media_file_uri(media_file_url.clone())
                    .build(),
            )
            .output_bucket_name(object_info.destination_bucket.clone())
            .output_key(object_info.generated_text_destination_key.clone())
            .send()
            .await?;
        // Poll for the transcription job completion
        loop {
            let get_response: GetTranscriptionJobOutput = transcribe_client
                .get_transcription_job()
                .transcription_job_name(job_name.to_string())
                .send()
                .await?;

            let status = get_response
                .transcription_job()
                .unwrap()
                .transcription_job_status()
                .unwrap();

            match status.as_str() {
                "COMPLETED" => {
                    // Process the completed transcription job without summarization
                    process_transcription_without_summarization(&object_info, &tag_map).await?;
                    break;
                }
                "FAILED" => {
                    return Err(Error::from("Transcription job failed"));
                }
                _ => {
                    // Wait before polling again
                    sleep(Duration::from_secs(10)).await;
                }
            }
        }
    }

    Ok(())
}

/// Process transcription results when summarization is enabled
async fn process_transcription_with_summarization(
    object_info: &types::ObjectInfo,
    tag_map: &std::collections::HashMap<String, String>,
) -> Result<(), Error> {
    // Step 1: Retrieve the transcription result as Bytes
    let transcribe_json_file_data: Bytes = storage_wrapper::get_object(
        object_info.work_bucket_name.as_str(),
        object_info.generated_text_destination_key.as_str(),
    )
    .await?;

    // Step 2: Convert Bytes to a JSON string
    let json_string = String::from_utf8(transcribe_json_file_data.to_vec())?;

    // Step 3: Pretty print the JSON
    let json_value: Value = serde_json::from_str(&json_string)?;
    let pretty_json_string = serde_json::to_string_pretty(&json_value)?;

    // Step 4: Summarize the content using Bedrock
    let summarized_result_bytes = bedrock_wrapper::summarize_object(
        object_info.invoke_prompt.as_str(),
        pretty_json_string.as_str(),
        object_info.model_id.as_str(),
    )
    .await?;

    // Step 5: Store the summarized content in S3
    storage_wrapper::put_object(
        object_info.destination_bucket.as_str(),
        object_info.summary_file_key.as_str(),
        summarized_result_bytes,
    )
    .await?;

    // Step 6: Store the metadata for the summarized content in S3
    storage_wrapper::create_object_metadata_file(
        &tag_map,
        object_info.destination_bucket.as_str(),
        object_info.summary_metadata_file_key.as_str(),
    )
    .await?;

    // Step 7: Copy the original file to the dataset bucket
    storage_wrapper::copy_object(
        object_info.source_bucket_name.as_str(),
        object_info.source_key.as_str(),
        object_info.destination_bucket.as_str(),
        object_info.destination_key.as_str(),
    )
    .await?;

    // Step 8: Store the generated text metadata in S3
    storage_wrapper::create_object_metadata_file(
        &tag_map,
        object_info.destination_bucket.as_str(),
        object_info.generated_text_metadata_file_key.as_str(),
    )
    .await?;
    // Delete Original Object
    storage_wrapper::delete_object(
        object_info.source_bucket_name.as_str(),
        object_info.source_key.as_str(),
    )
    .await?;

    // Copy transcription from work bucket to dataset bucket
    storage_wrapper::copy_object(
        object_info.work_bucket_name.as_str(),
        object_info.generated_text_destination_key.as_str(),
        object_info.destination_bucket.as_str(),
        object_info.generated_text_destination_key.as_str(),
    )
    .await?;

    // Delete worktemp transcription
    storage_wrapper::delete_object(
        object_info.work_bucket_name.as_str(),
        object_info.generated_text_destination_key.as_str(),
    )
    .await?;

    Ok(())
}

/// Process transcription results when summarization is not enabled
async fn process_transcription_without_summarization(
    object_info: &types::ObjectInfo,
    tag_map: &std::collections::HashMap<String, String>,
) -> Result<(), Error> {
    // Step 1: Copy the original file to the dataset bucket
    storage_wrapper::copy_object(
        object_info.source_bucket_name.as_str(),
        object_info.source_key.as_str(),
        object_info.destination_bucket.as_str(),
        object_info.destination_key.as_str(),
    )
    .await?;

    // Step 2: Store the generated text metadata in S3
    storage_wrapper::create_object_metadata_file(
        &tag_map,
        object_info.destination_bucket.as_str(),
        object_info.generated_text_metadata_file_key.as_str(),
    )
    .await?;

    // Step 3: Clean up temporary files from the landing and work buckets
    storage_wrapper::delete_object(
        object_info.source_bucket_name.as_str(),
        object_info.source_key.as_str(),
    )
    .await?;

    Ok(())
}
