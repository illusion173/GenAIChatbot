use aws_lambda_events::event::eventbridge::EventBridgeEvent;
use handleaudiovideo::handle_audio_video;
use lambda_runtime::{
    run, service_fn,
    tracing::{self, info},
    Error, LambdaEvent,
};
mod bedrock_wrapper;
mod db_wrapper;
mod handleaudiovideo;
mod handledocuments;
mod handleimgs;
mod storage_wrapper;
mod types;
use genaitypes::*;

async fn function_handler(event: LambdaEvent<EventBridgeEvent<S3Detail>>) -> Result<(), Error> {
    let document_extensions = vec![
        "txt", "md", "html", "doc", "docx", "pdf", "gz", "json", "yaml",
    ];
    let audio_extensions = vec!["mp3", "amr", "flac", "m4a", "ogg", "wav"];
    let video_extensions = vec!["mp4", "webm"];
    let image_extensions = vec!["png", "jpg"];
    let source_bucket = event.payload.detail.bucket.name;
    let file_key = event.payload.detail.object.key;

    // Big initializer struct for all object information, contains all needed information for
    // summarization, metadata file, tags, invoke prompt, etc.
    let object_info = types::ObjectInfo::new(source_bucket, file_key).await?;

    match object_info.provider_type.as_str() {
        "user" => match &object_info.file_extension.as_str() {
            ext if document_extensions.contains(ext) => {
                // Handle document file extension
                handledocuments::document_handler(object_info).await?;
            }
            ext if audio_extensions.contains(ext) => {
                // Handle audio file extension
                handleaudiovideo::handle_audio_video(object_info).await?;
            }
            ext if video_extensions.contains(ext) => {
                handleaudiovideo::handle_audio_video(object_info).await?;

                // Handle video file extension
            }
            ext if image_extensions.contains(ext) => {
                // Handle image file extension
                let image_type = object_info
                    .associated_tags
                    .image_type
                    .as_ref()
                    .expect("Expected an Image tag!")
                    .as_str();

                match image_type {
                    "document" => handleimgs::handle_documents_forms(object_info).await?,
                    "expense" => handleimgs::handle_expense(object_info).await?,
                    _ => {
                        let error_msg = format!("Must have a proper Image Tag for a submitted image. Allowed image types: document (for forms and general documents), expense (for receipts and expense reports)");
                        return Err(error_msg.into());
                    }
                }
            }
            _ => {
                let error_msg = format!(
                    "File Extension not recognized, move to unsupported bucket: {:?}",
                    object_info
                );

                // Move to the unsupported bucket!
                storage_wrapper::copy_object(
                    object_info.source_bucket_name.as_str(),
                    object_info.source_key.as_str(),
                    object_info.failed_bucket.as_str(),
                    object_info.source_key.as_str(),
                )
                .await?;
                storage_wrapper::delete_object(
                    object_info.source_bucket_name.as_str(),
                    object_info.source_key.as_str(),
                )
                .await?;

                return Err(error_msg.into());
            }
        },
        "service" => match &object_info.file_extension.as_str() {
            ext if document_extensions.contains(ext) => {
                // Handle document file extension
                handledocuments::document_handler(object_info).await?;
            }
            ext if audio_extensions.contains(ext) => {
                // Handle audio file extension
                handleaudiovideo::handle_audio_video(object_info).await?;
            }
            ext if video_extensions.contains(ext) => {
                // Handle video file extension
                handleaudiovideo::handle_audio_video(object_info).await?;
            }
            ext if image_extensions.contains(ext) => {
                // Handle image file extension
                let image_type = object_info
                    .associated_tags
                    .image_type
                    .as_ref()
                    .expect("Expected an Image type tag!")
                    .as_str();

                match image_type {
                    "document" => handleimgs::handle_documents_forms(object_info).await?,
                    "expense" => handleimgs::handle_expense(object_info).await?,
                    _ => {
                        let error_msg = format!("Must have proper Image Tag for an image. Allowed image types: document (for forms and general documents), expense (for receipts and expense reports.)");
                        return Err(error_msg.into());
                    }
                }
            }
            // Handle unknown file extensions
            _ => {
                let error_msg = format!(
                    "File Extension not recognized, move to unsupported bucket: {:?}",
                    object_info
                );
                // Move to the unsupported bucket!
                storage_wrapper::copy_object(
                    object_info.source_bucket_name.as_str(),
                    object_info.source_key.as_str(),
                    object_info.failed_bucket.as_str(),
                    object_info.source_key.as_str(),
                )
                .await?;
                storage_wrapper::delete_object(
                    object_info.source_bucket_name.as_str(),
                    object_info.source_key.as_str(),
                )
                .await?;
                return Err(error_msg.into());
            }
        },
        _ => return Err("Provider type not recognized? Must be either service or user.".into()),
    }

    Ok(())
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
