use super::bedrock_wrapper;
use super::storage_wrapper;
use super::types;
use bytes::Bytes;
use flate2::read::GzDecoder;
use lambda_runtime::{tracing, Error};
use serde_json::Value;
use std::io::Cursor;
use std::io::Read;
use tracing::info;

pub async fn document_handler(object_info: types::ObjectInfo) -> Result<(), Error> {
    let tag_map = object_info.associated_tags.to_hashmap();

    //let source_file_content_bytes: bytes::Bytes;
    //let source_file_content_string = String::new();
    match object_info.file_extension.as_str() {
        "txt" | "md" | "doc" | "html" | "docx" | "pdf" => {
            // Check if the user wants to summarize the data.
            //
            if object_info.associated_tags.summarize {
                // Step 1: Get Object from S3
                let file_data = storage_wrapper::get_object(
                    object_info.source_bucket_name.as_str(),
                    object_info.source_key.as_str(),
                )
                .await?;

                // Step 2: Convert Bytes to String
                let source_file_content_string = String::from_utf8(file_data.to_vec())?;

                // Step 3: Summarize the content
                let summarized_result_bytes = bedrock_wrapper::summarize_object(
                    object_info.invoke_prompt.as_str(),
                    source_file_content_string.as_str(),
                    object_info.model_id.as_str(),
                )
                .await?;

                // Put the summarized txt content in S3.
                storage_wrapper::put_object(
                    object_info.destination_bucket.as_str(),
                    object_info.summary_file_key.as_str(),
                    summarized_result_bytes,
                )
                .await?;

                // Put the summarized metadata file in s3
                storage_wrapper::create_object_metadata_file(
                    &tag_map,
                    object_info.destination_bucket.as_str(),
                    object_info.summary_metadata_file_key.as_str(),
                )
                .await?;
            }

            // Put the original file in s3 dataset bucket.
            info!("{:?}", object_info);
            storage_wrapper::copy_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
                object_info.destination_bucket.as_str(),
                object_info.destination_key.as_str(),
            )
            .await?;

            // Since it is one of the accepted file types, create a natural metadata file.
            // Put the summarized metadata file in s3
            storage_wrapper::create_object_metadata_file(
                &tag_map,
                object_info.destination_bucket.as_str(),
                object_info.generated_text_metadata_file_key.as_str(),
            )
            .await?;

            // Delete the original object from the landing bucket.
            storage_wrapper::delete_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
            )
            .await?;
        }
        "json" => {
            // Step 1: Get the JSON file data as Bytes
            let json_file_data: Bytes = storage_wrapper::get_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
            )
            .await?;

            // Step 2: Convert Bytes to String
            let json_string = String::from_utf8(json_file_data.to_vec())?;

            // Step 3: Pretty print the JSON
            let json_value: Value = serde_json::from_str(&json_string)?;
            let pretty_json_string = serde_json::to_string_pretty(&json_value)?;
            // The user/system wants to summarize the given json item.
            if object_info.associated_tags.summarize {
                // Step 3a: Summarize the content
                let summarized_result_bytes = bedrock_wrapper::summarize_object(
                    object_info.invoke_prompt.as_str(),
                    pretty_json_string.as_str(),
                    object_info.model_id.as_str(),
                )
                .await?;
                // Step 3b. Save the summarized content.
                // Put the summarized txt content in S3.
                storage_wrapper::put_object(
                    object_info.destination_bucket.as_str(),
                    object_info.summary_file_key.as_str(),
                    summarized_result_bytes,
                )
                .await?;

                // Put the summarized metadata file key in s3
                storage_wrapper::create_object_metadata_file(
                    &tag_map,
                    object_info.destination_bucket.as_str(),
                    object_info.summary_metadata_file_key.as_str(),
                )
                .await?;
            }
            // Step 4: Convert the pretty JSON string directly to Bytes
            let source_file_content_bytes = Bytes::from(pretty_json_string);

            // Step 5: Copy original JSON file into the dataset file bucket, copy the txt file that can
            // be read by Knowledge Base to dataset file bucket.
            storage_wrapper::copy_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
                object_info.destination_bucket.as_str(),
                object_info.destination_key.as_str(),
            )
            .await?;
            // Put the new txt file into s3. this will contain the json in it, just in a txt
            // format.
            storage_wrapper::put_object(
                object_info.destination_bucket.as_str(),
                object_info.generated_text_destination_key.as_str(),
                source_file_content_bytes,
            )
            .await?;
            // Insert s3 metadata here.
            storage_wrapper::create_object_metadata_file(
                &tag_map,
                object_info.destination_bucket.as_str(),
                object_info.generated_text_metadata_file_key.as_str(),
            )
            .await?;
            // Delete the original file from the landing.
            storage_wrapper::delete_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
            )
            .await?;
        }
        "gz" => {
            // Fetch file binary from s3
            let gz_file_data: Bytes = storage_wrapper::get_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
            )
            .await?;

            // Create a GzDecoder to decompress the data
            let mut decoder = GzDecoder::new(Cursor::new(gz_file_data));
            // Read the decompressed data into a String
            let mut decompressed_data = String::new();
            decoder.read_to_string(&mut decompressed_data)?;

            // Step 3: Pretty print the JSON
            let json_value: Value = serde_json::from_str(&decompressed_data)?;
            let pretty_json_string = serde_json::to_string_pretty(&json_value)?;
            // The user/system wants to summarize the given json.gz item.
            if object_info.associated_tags.summarize {
                // Step 3a: Summarize the content
                let summarized_result_bytes = bedrock_wrapper::summarize_object(
                    object_info.invoke_prompt.as_str(),
                    pretty_json_string.as_str(),
                    object_info.model_id.as_str(),
                )
                .await?;
                // Step 3b. Save the summarized content.
                // Put the summarized txt content in S3.
                storage_wrapper::put_object(
                    object_info.destination_bucket.as_str(),
                    object_info.summary_file_key.as_str(),
                    summarized_result_bytes,
                )
                .await?;

                // Put the summarized metadata file in s3
                storage_wrapper::create_object_metadata_file(
                    &tag_map,
                    object_info.destination_bucket.as_str(),
                    object_info.summary_metadata_file_key.as_str(),
                )
                .await?;
            }
            // Step 4: Convert the pretty JSON string directly to Bytes
            let source_file_content_bytes = Bytes::from(pretty_json_string);

            // Step 5: Copy original JSON gz file into the dataset file bucket, copy the txt file that can
            // be read by Knowledge Base to dataset file bucket.
            storage_wrapper::copy_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
                object_info.destination_bucket.as_str(),
                object_info.destination_key.as_str(),
            )
            .await?;
            // Insert the json in a txt file here
            storage_wrapper::put_object(
                object_info.destination_bucket.as_str(),
                object_info.generated_text_destination_key.as_str(),
                source_file_content_bytes,
            )
            .await?;

            storage_wrapper::create_object_metadata_file(
                &tag_map,
                object_info.destination_bucket.as_str(),
                object_info.generated_text_metadata_file_key.as_str(),
            )
            .await?;

            // Delete the original file from the landing.
            storage_wrapper::delete_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
            )
            .await?;
        }
        "yaml" => {
            // Fetch file binary from s3
            let yaml_file_data: Bytes = storage_wrapper::get_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
            )
            .await?;

            if object_info.associated_tags.summarize {
                // Step 2: Convert Bytes to String
                let source_file_content_string =
                    String::from_utf8(yaml_file_data.clone().to_vec())?;

                // Step 3: Summarize the content
                let summarized_result_bytes = bedrock_wrapper::summarize_object(
                    object_info.invoke_prompt.as_str(),
                    source_file_content_string.as_str(),
                    object_info.model_id.as_str(),
                )
                .await?;

                // Put the summarized txt content in S3.
                storage_wrapper::put_object(
                    object_info.destination_bucket.as_str(),
                    object_info.summary_file_key.as_str(),
                    summarized_result_bytes,
                )
                .await?;

                // Put the summarized metadata file in s3
                storage_wrapper::create_object_metadata_file(
                    &tag_map,
                    object_info.destination_bucket.as_str(),
                    object_info.summary_metadata_file_key.as_str(),
                )
                .await?;
            }

            // Put file binary into s3 as a txt file data source bucket.
            storage_wrapper::put_object(
                object_info.destination_bucket.as_str(),
                object_info.generated_text_destination_key.as_str(),
                yaml_file_data,
            )
            .await?;

            // Create metadata file for txt file.
            storage_wrapper::create_object_metadata_file(
                &tag_map,
                object_info.destination_bucket.as_str(),
                object_info.generated_text_metadata_file_key.as_str(),
            )
            .await?;

            // Move original file to s3 data source bucket.
            storage_wrapper::copy_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
                object_info.destination_bucket.as_str(),
                object_info.destination_key.as_str(),
            )
            .await?;

            // Delete from landing bucket.
            // Delete the original file from the landing.
            storage_wrapper::delete_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
            )
            .await?;
        }

        _ => {
            let error_msg = format!(
                    "Document File Extension not recognized, move to unsupported bucket: {:?}, how did we get here?",
                    object_info
                );

            // Move to the unsupported bucket!
            storage_wrapper::copy_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
                object_info.failed_bucket.as_str(),
                object_info.source_key.as_str(),
            )
            .await?;
            // Delete original
            storage_wrapper::delete_object(
                object_info.source_bucket_name.as_str(),
                object_info.source_key.as_str(),
            )
            .await?;

            return Err(error_msg.into());
        }
    }

    Ok(())
}
