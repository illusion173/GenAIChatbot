use aws_lambda_events::event::eventbridge::EventBridgeEvent;
use aws_sdk_dynamodb::types::AttributeValue;
use aws_sdk_sfn::Client as sfnClient;
use genaitypes::DynamoTableIdRow;
use lambda_runtime::{run, service_fn, tracing, Error, LambdaEvent};
use serde_dynamo;
use std::collections::HashMap;
use tracing::info;
async fn fetch_ds_kb_id(
    dynamo_client: &aws_sdk_dynamodb::Client,
    table_name: &str,
) -> Result<Vec<DynamoTableIdRow>, Error> {
    // Make sure to only get IDs
    let projection_expression = "knowledge_base_id, data_source_ids";
    // This is needed for pagination
    let mut last_evaluated_key: Option<HashMap<String, AttributeValue>> = None;
    let mut id_rows: Vec<DynamoTableIdRow> = Vec::new();
    loop {
        let scan_request = dynamo_client
            .scan()
            .table_name(table_name)
            .projection_expression(projection_expression)
            .set_exclusive_start_key(last_evaluated_key.clone());

        let scan_output_response = scan_request.send().await?;

        let items = scan_output_response.items().to_vec().clone();

        last_evaluated_key = scan_output_response.last_evaluated_key;

        for row in items {
            let mut id_row: DynamoTableIdRow = serde_dynamo::from_item(row)?;
            id_row.len_ds_ids = Some(id_row.data_source_ids.len());
            id_row.current_idx = Some(0);
            id_rows.push(id_row);
        }

        if last_evaluated_key.is_none() {
            break;
        }
    }

    Ok(id_rows)
}
async fn function_handler(_event: LambdaEvent<EventBridgeEvent>) -> Result<(), Error> {
    // ENV CHECK HERE
    let id_dynamo_table = std::env::var("DB_NAME").expect("DB_NAME environment variable not set.");
    let sync_state_machine_arn =
        std::env::var("SYNC_SF_ARN").expect("SYNC_SF_ARN environment variable not set.");

    let config = aws_config::load_from_env().await;

    let dynamo_client = aws_sdk_dynamodb::Client::new(&config);
    let sfn_client = sfnClient::new(&config);

    // First we need to pull the knowledge base Ids and the associated data source ids.
    let id_vec = fetch_ds_kb_id(&dynamo_client, id_dynamo_table.as_str()).await?;
    for id_row in id_vec {
        // Serialize the input data to JSON
        let row_input_json = serde_json::to_string(&id_row)?;
        // Start the Step Function execution
        let response = sfn_client
            .start_execution()
            .state_machine_arn(sync_state_machine_arn.clone())
            .input(row_input_json)
            .send()
            .await?;
        info!("Began sfn for sync for id_row: {:?}", id_row);
        info!("Response: {:?}", response);
    }

    Ok(())
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
