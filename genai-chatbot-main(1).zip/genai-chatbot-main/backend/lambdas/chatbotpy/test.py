import boto3
import json
import os
from botocore.exceptions import ClientError


def bedrock_rag(kb_id, question, model_id, session_id, prompt_template):
    bedrock_agent_runtime_client = boto3.client("bedrock-agent-runtime")

    model_input = {"text": question}
    final_test = {
        "knowledgeBaseConfiguration": {
            "knowledgeBaseId": kb_id,
            "modelArn": model_id,
        },
        "type": "KNOWLEDGE_BASE",
    }

    if session_id is None:
        return bedrock_agent_runtime_client.retrieve_and_generate(
            input=model_input, retrieveAndGenerateConfiguration=final_test
        )
    else:
        return bedrock_agent_runtime_client.retrieve_and_generate(
            input=model_input,
            retrieveAndGenerateConfiguration=final_test,
            sesionID=session_id,
        )


def get_prompt_template(knowledge_base_id: str):
    # Load AWS configuration
    dynamodb = boto3.client("dynamodb")

    # Get the environment variable
    prompt_table_name = os.environ.get("PROMPT_TABLE")
    if not prompt_table_name:
        raise RuntimeError("PROMPT_TABLE must be set.")

    # Define the global secondary index name and the attribute to retrieve
    global_secondary_index_name = "knowledge_base_id"
    attribute_needed = "gen_prompt"

    try:
        # Execute the query
        response = dynamodb.query(
            TableName=prompt_table_name,
            IndexName=global_secondary_index_name,
            KeyConditionExpression="#k = :v",
            ExpressionAttributeNames={"#k": "knowledge_base_id"},
            ExpressionAttributeValues={":v": {"S": knowledge_base_id}},
            ProjectionExpression=attribute_needed,
        )

        items = response.get("Items", [])
        if not items:
            raise ValueError(
                f"No item found for knowledge_base_id: {knowledge_base_id}"
            )

        first_item = items[0]
        generation_prompt = first_item.get(attribute_needed, {}).get("S")
        print(type(generation_prompt))
        if generation_prompt is None:
            raise ValueError(f"Attribute {attribute_needed} not found in the item.")

        return generation_prompt

    except ClientError as e:
        raise RuntimeError(
            f"Failed to query DynamoDB: {e.response['Error']['Message']}"
        )


def extract_citation_info(response):
    main_array = []

    for citation in response.get("citations", []):
        generated_text = (
            citation.get("generatedResponsePart", {})
            .get("textResponsePart", {})
            .get("text", "")
        )
        retrieved_references = citation.get("retrievedReferences", [])

        for reference in retrieved_references:
            location = reference.get("location", {})
            s3_location = location.get("s3Location", {}).get("uri", None)

            if s3_location:
                citation_info = {
                    "original_text": reference.get("content", {}).get("text", ""),
                    "s3_location": s3_location,
                }
                main_array.append(citation_info)

    return main_array


def lambda_handler(event, context):
    session_id = None

    # Check if the event contains a body
    if "body" in event:
        # Parse the JSON body
        body = json.loads(event["body"])

        user_question = body["question"]
        knowledge_base_id = body["knowledge_base_id"]
        session_id = body["session_id"]

        prompt_text = get_prompt_template(knowledge_base_id)

        # Get environment variables
        prompt_table_name = os.environ.get("PROMPT_TABLE")
        if prompt_table_name is None:
            raise RuntimeError("Environment variable PROMPT_TABLE is not set")

        model_arn = os.environ.get("FOUNDATION_MODEL_ARN")
        if model_arn is None:
            raise RuntimeError("Environment variable FOUNDATION_MODEL_ARN is not set")

        rag_response = bedrock_rag(
            knowledge_base_id, user_question, model_arn, session_id, prompt_text
        )
        generated_text = rag_response["output"]["text"]
        session_id = rag_response["sessionId"]
        extract_citation_vec = extract_citation_info(rag_response)
        print(extract_citation_vec[0])

        composed_rag_response = {
            "answer": generated_text,
            "session_id": session_id,
            "knowledge_base_id": knowledge_base_id,
            "related_objects": extract_citation_vec,
        }
        response = {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS,GET",
            },
            "body": json.dumps(composed_rag_response),
        }
        return response
