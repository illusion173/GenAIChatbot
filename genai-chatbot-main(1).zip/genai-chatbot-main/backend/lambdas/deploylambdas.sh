#!/bin/bash

# Script Name: deploylambas.sh
# Description: Deploy lambdas based on their folder/package name. 
# Usage: ./deploylambdas.sh
# Author: Jeremiah Webb
# Date: 06-07-2024
cargo lambda deploy handleupload
cargo lambda deploy handledownload
cargo lambda deploy assignusertags
cargo lambda deploy assignservicetags
cargo lambda deploy loadkbdata
cargo lambda deploy chatbot
cargo lambda deploy beginsynckb
cargo lambda deploy startingestkb
cargo lambda deploy checkingestkb
cargo lambda deploy getknowledgebaseid
cargo lambda deploy saveconversation
cargo lambda deploy listconversations
cargo lambda deploy grabconversation
cargo lambda deploy insertdomain
cargo lambda deploy getdomainssubdomains

echo "Done deploying"
