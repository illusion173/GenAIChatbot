mod storage_wrapper;
use aws_lambda_events::event::eventbridge::EventBridgeEvent;
use aws_sdk_s3::types::{Tag, Tagging};
use chrono::Utc;
use genaitypes::S3Detail;
use lambda_runtime::{run, service_fn, tracing, Error, LambdaEvent};
use std::{env, path::Path};
use tracing::info;
//mod genaitypes;
// We need to initially check if the file type is even valid.
fn create_tags(file_key: &str, time_retrieved: &str) -> Tagging {
    // Split file_key into domain and subdomain parts
    let domain_parts: Vec<&str> = file_key.split('/').collect();

    // Ensure we have at least two parts (domain and subdomain)
    if domain_parts.len() < 2 {
        panic!("Expected at least two elements in the file key to extract domain and subdomain");
    }

    // Extract domain and subdomain
    let domain = domain_parts[0];
    let subdomain = domain_parts[1];

    // Build tags
    let domain_tag = Tag::builder().key("domain").value(domain).build().unwrap();
    let sub_domain_tag = Tag::builder()
        .key("subdomain")
        .value(subdomain)
        .build()
        .unwrap();
    let source_tag = Tag::builder()
        .key("providertype")
        .value("service")
        .build()
        .unwrap();
    let time_retrieved_tag = Tag::builder()
        .key("datetime")
        .value(time_retrieved)
        .build()
        .unwrap();

    // Create a vector of tags
    let tags = vec![source_tag, time_retrieved_tag, domain_tag, sub_domain_tag];

    // Build Tagging object
    let tagging = Tagging::builder().set_tag_set(Some(tags)).build().unwrap();

    return tagging;
}
async fn function_handler(event: LambdaEvent<EventBridgeEvent<S3Detail>>) -> Result<(), Error> {
    // Extract some useful information from the request
    // We need to extract the file type
    let failed_bucket = env::var("FAILED_BUCKET").expect("FAILED_BUCKET must be set.");
    // Get event Details
    let source_bucket = event.payload.detail.bucket.name;
    let file_key = event.payload.detail.object.key;
    //let time_retrieved = event.payload.time.unwrap_or(Utc::now());
    //let rfc_time = time_retrieved.to_rfc3339();

    let file_name = file_key.split('/').last().unwrap_or("");

    let extension = Path::new(&file_key)
        .extension()
        .expect("Unable to build file extension, path, check s3 uri.")
        .to_str()
        .expect("Extension is not valid UTF-8");

    let document_extensions = vec![
        "txt", "md", "html", "doc", "docx", "pdf", "gz", "json", "yaml",
    ];

    let audio_extensions = vec!["mp3", "amr", "flac", "m4a", "ogg", "wav"];
    let video_extensions = vec!["mp4", "webm"];
    let image_extensions = vec!["png", "jpg"];

    if !document_extensions.contains(&extension)
        && !audio_extensions.contains(&extension)
        && !image_extensions.contains(&extension)
        && !video_extensions.contains(&extension)
    {
        info!("Unsupported");
        // Move to unsupported bucket.
        storage_wrapper::copy_object(
            source_bucket.as_str(),
            file_key.as_str(),
            failed_bucket.as_str(),
            file_name,
        )
        .await?;
        // Delete from original
        storage_wrapper::delete_object(source_bucket.as_str(), file_key.as_str()).await?;
        // Notify user here in some way
        return Err("File not supported".into());
    }
    info!("Assigning Tags");
    // Assign appropriate tags
    let tags = create_tags(
        file_key.as_str(),
        event
            .payload
            .time
            .unwrap_or(Utc::now())
            .to_rfc3339()
            .as_str(),
    );
    storage_wrapper::assign_tags(source_bucket.as_str(), file_key.as_str(), tags).await?;

    Ok(())
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
