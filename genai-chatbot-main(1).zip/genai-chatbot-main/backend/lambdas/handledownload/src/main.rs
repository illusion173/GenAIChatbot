use aws_sdk_s3::Client as S3Client;
use aws_sdk_s3::{self, presigning::PresigningConfig};
use lambda_http::{run, service_fn, tracing, Body, Error, Request, RequestExt, Response};
use serde::{Deserialize, Serialize};
use std::env;
use std::time::Duration;

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
struct ResponseDownload {
    presigned_url: String,
}

async fn get_presigned_url(
    bucket: &str,
    file_key: &str,
    expires_in: &u64,
) -> Result<ResponseDownload, Error> {
    let config = aws_config::load_from_env().await;
    let s3_client = S3Client::new(&config);

    let expires_in = Duration::from_secs(expires_in.to_owned());
    let presigned_request = s3_client
        .get_object()
        .bucket(bucket)
        .key(file_key)
        .presigned(PresigningConfig::expires_in(expires_in)?)
        .await?;

    println!("Object URI: {}", presigned_request.uri());

    let presigned_url = presigned_request.uri().to_string();

    let response_download_struct = ResponseDownload { presigned_url };

    Ok(response_download_struct)
}

async fn function_handler(event: Request) -> Result<Response<Body>, Error> {
    // Verify download Bucket has been set
    let download_bucket = env::var("DOWNLOAD_BUCKET").expect("DOWNLOAD_BUCKET must be set");
    // Extract some useful information from the request
    let query_string_params = event.query_string_parameters();

    let file_key = match query_string_params.first("file_key") {
        Some(file_key_string) => file_key_string,
        None => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(400)
                .body(Body::from("Missing file_key query str param?"))
                .expect("Failed to build a response"))
        }
    };

    let time: u64 = 259200;

    let presigned_url_download =
        get_presigned_url(download_bucket.as_str(), file_key, &time).await?;

    //let message = format!("{}", presigned_url_download);
    let response_string =
        serde_json::to_string(&presigned_url_download).expect("Failed to serailize json response");

    let resp = Response::builder()
        .status(200)
        .header("content-type", "application/json")
        .header("Access-Control-Allow-Origin", "*")
        .header("Access-Control-Allow-Methods", "OPTIONS,GET")
        .body(response_string.into())
        .map_err(Box::new)?;
    Ok(resp)
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
