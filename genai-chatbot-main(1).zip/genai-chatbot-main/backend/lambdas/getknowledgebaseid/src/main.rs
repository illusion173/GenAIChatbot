use aws_sdk_dynamodb::types::AttributeValue;
use aws_sdk_dynamodb::Client as DynamoDbClient;
use lambda_http::{
    run, service_fn,
    tracing::{self, info},
    Body, Error, Request, RequestExt, Response,
};
use serde::{Deserialize, Serialize};
use std::env;

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct ResponseKnowledgeBaseId {
    pub knowledge_base_id: String,
}

pub async fn get_knowledge_base_id(
    domain: &str,
    subdomain: &str,
) -> Result<ResponseKnowledgeBaseId, Error> {
    let config = aws_config::load_from_env().await;
    let prompt_table_name = env::var("PROMPT_TABLE").expect("PROMPT_TABLE must be set.");

    let client = DynamoDbClient::new(&config);

    let partition_key = "audit_domain";
    let sort_key = "subdomain";
    let index_name = "audit_domain-subdomain-index";
    let attributes_needed = "knowledge_base_id";

    // Create the query input
    let response = client
        .query()
        .table_name(prompt_table_name)
        .index_name(index_name)
        .key_condition_expression("#pk = :pkval AND #sk = :skval")
        .expression_attribute_names("#pk", partition_key)
        .expression_attribute_names("#sk", sort_key)
        .expression_attribute_values(":pkval", AttributeValue::S(domain.to_string()))
        .expression_attribute_values(":skval", AttributeValue::S(subdomain.to_string()))
        .projection_expression(attributes_needed)
        .send()
        .await?;

    info!("{:?}", response);

    // Retrieve the first item from the query response
    if let Some(items) = response.items {
        if let Some(first_item) = items.into_iter().next() {
            info!("{:?}", first_item);
            let knowledge_base_id_struct: ResponseKnowledgeBaseId =
                serde_dynamo::from_item(first_item)
                    .expect("No knowledge_base_id in item row. Check DynamoDB prompt table?");
            return Ok(knowledge_base_id_struct);
        } else {
            return Err("No items found".into());
        }
    } else {
        return Err("No items found".into());
    }
}

async fn function_handler(event: Request) -> Result<Response<Body>, Error> {
    // Get query string parameters
    let query_string_params = event.query_string_parameters();

    let audit_domain = match query_string_params.first("domain") {
        Some(audit_domain_string) => audit_domain_string,
        None => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(400)
                .body(Body::from("Missing audit_domain query str param?"))
                .expect("Failed to build a response"))
        }
    };
    let sub_domain = match query_string_params.first("sub_domain") {
        Some(sub_domain_string) => sub_domain_string,
        None => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(400)
                .body(Body::from("Missing sub_domain query str param?"))
                .expect("Failed to build a response"))
        }
    };
    let knowledge_base_id_struct = get_knowledge_base_id(audit_domain, sub_domain).await?;

    let response_string = serde_json::to_string(&knowledge_base_id_struct)
        .expect("Failed to serailize json response");

    // Return something that implements IntoResponse.
    // It will be serialized to the right response event automatically by the runtime
    let resp = Response::builder()
        .status(200)
        .header("content-type", "application/json")
        .header("Access-Control-Allow-Origin", "*")
        .header("Access-Control-Allow-Methods", "OPTIONS,GET")
        .body(response_string.into())
        .map_err(Box::new)?;
    Ok(resp)
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
