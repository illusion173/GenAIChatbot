use aws_sdk_bedrockagent::types::IngestionJobStatus;
use genaitypes::*;
use lambda_runtime::{run, service_fn, tracing, Error, LambdaEvent};
use serde_json::Value;
async fn check_ingestion_job(
    knowlege_base_id: &str,
    data_source_id: &str,
    job_id: &str,
) -> Result<usize, Error> {
    let config = aws_config::load_from_env().await;

    let bedrockagent_client = aws_sdk_bedrockagent::Client::new(&config);

    let response = bedrockagent_client
        .get_ingestion_job()
        .knowledge_base_id(knowlege_base_id)
        .data_source_id(data_source_id)
        .ingestion_job_id(job_id)
        .send()
        .await?;

    if let Some(ingestion_job) = response.ingestion_job {
        let status = ingestion_job.status.clone();
        match status {
            IngestionJobStatus::Complete => return Ok(1),
            IngestionJobStatus::InProgress | IngestionJobStatus::Starting => return Ok(0),
            IngestionJobStatus::Failed => {
                let error_msg = format!("Failure in ingestion job: {:?}", ingestion_job);
                return Err(error_msg.into());
            }
            _ => {
                let error_msg = format!("Unrecognized State?: {:?}", ingestion_job);
                return Err(error_msg.into());
            }
        }
    } else {
        let error_msg = format!("Unable to get ingestion job status via job_id {:?}", job_id);
        return Err(error_msg.into());
    }
}

async fn function_handler(event: LambdaEvent<Value>) -> Result<CheckKnowledgeBaseSyncInfo, Error> {
    // Extract some useful information from the request
    let mut sync_info_struct: CheckKnowledgeBaseSyncInfo = serde_json::from_value(event.payload)?;
    let current_idx = sync_info_struct.current_idx;
    let current_data_source_id = sync_info_struct.data_source_ids[current_idx].clone();
    let job_status = check_ingestion_job(
        sync_info_struct.knowledge_base_id.as_str(),
        current_data_source_id.as_str(),
        sync_info_struct.job_id.as_str(),
    )
    .await?;

    sync_info_struct.current_idx = sync_info_struct.current_idx + job_status;

    Ok(sync_info_struct)
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
