use genaitypes::*;
use lambda_runtime::{run, service_fn, tracing, Error, LambdaEvent};
use serde_json::Value;
use tracing::info;
use uuid::Uuid;
async fn begin_bedrock_ingestion(
    client_token: &str,
    knowledge_base_id: &str,
    data_source_id: &str,
) -> Result<String, Error> {
    let description: String = "Lambda function to run a sync job on a KB datasource.".to_string();
    let config = aws_config::load_from_env().await;
    let bedrock_client = aws_sdk_bedrockagent::Client::new(&config);
    let response = bedrock_client
        .start_ingestion_job()
        .knowledge_base_id(knowledge_base_id)
        .data_source_id(data_source_id)
        .client_token(client_token)
        .description(description)
        .send()
        .await?;

    if let Some(ingestion_job) = response.ingestion_job {
        let job_id = ingestion_job.ingestion_job_id;
        Ok(job_id)
    } else {
        let error_msg = format!(
            "Unable to retrieve response/ingestion job info job_id? {:?}",
            response
        );
        return Err(error_msg.into());
    }
}
async fn function_handler(event: LambdaEvent<Value>) -> Result<StartKnowledgeBaseSyncInfo, Error> {
    info!("{:?}", event);
    // So we get a json value of type KnowledgeBaseSyncInfo
    let mut sync_info_struct: StartKnowledgeBaseSyncInfo = serde_json::from_value(event.payload)?;

    // Need a new token per ingest job
    let client_token = Uuid::new_v4().to_string();
    let current_idx = sync_info_struct.current_idx;
    let knowledge_base_id = sync_info_struct.knowledge_base_id.clone();
    let ds_vec = sync_info_struct.data_source_ids.clone();
    let ds_id = ds_vec[current_idx].clone();

    let job_id = begin_bedrock_ingestion(
        client_token.as_str(),
        knowledge_base_id.as_str(),
        ds_id.as_str(),
    )
    .await?;

    sync_info_struct.job_id = Some(job_id);

    Ok(sync_info_struct)
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
