use aws_sdk_s3::types::Tagging;
use aws_sdk_s3::Client as S3Client;
use lambda_runtime::{tracing, Error};
use tracing::info;
pub async fn copy_object(
    source_bucket: &str,
    source_key: &str,
    destination_bucket: &str,
    destination_key: &str,
) -> Result<(), Error> {
    let config = aws_config::load_from_env().await;
    let s3_client = S3Client::new(&config);

    let copy_source = format!("{}/{}", source_bucket, source_key);

    info!("COPYSOURCE");
    info!("{:?}", copy_source);
    s3_client
        .copy_object()
        .copy_source(copy_source)
        .bucket(destination_bucket)
        .key(destination_key)
        .send()
        .await?;

    Ok(())
}
pub async fn delete_object(source_bucket: &str, source_key: &str) -> Result<(), Error> {
    let config = aws_config::load_from_env().await;
    let s3_client = S3Client::new(&config);
    s3_client
        .delete_object()
        .bucket(source_bucket)
        .key(source_key)
        .send()
        .await?;
    Ok(())
}

pub async fn assign_tags(
    source_bucket: &str,
    source_key: &str,
    tags: Tagging,
) -> Result<(), Error> {
    info!("{:?}", source_bucket);
    info!("{:?}", source_key);

    let config = aws_config::load_from_env().await;
    let s3_client = S3Client::new(&config);

    s3_client
        .put_object_tagging()
        .bucket(source_bucket)
        .key(source_key)
        .tagging(tags)
        .send()
        .await?;

    Ok(())
}
