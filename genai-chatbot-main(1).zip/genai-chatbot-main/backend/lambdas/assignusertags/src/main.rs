use aws_sdk_s3::types::{Tag, Tagging};
use chrono::Utc;
use lambda_http::{
    run, service_fn,
    tracing::{self, info},
    Body, Error, Request, Response,
};
use serde_json;
use std::{env, path::Path};
mod storage_wrapper;
use genaitypes::UserTagSubmission;
fn create_tags(user_submission: &UserTagSubmission, time_retrieved: &str) -> Tagging {
    // Split file_key into domain and subdomain parts
    let domain_parts: Vec<&str> = user_submission.file_key.split('/').collect();

    // Ensure we have at least two parts (domain and subdomain)
    if domain_parts.len() < 2 {
        panic!("Expected at least two elements in the file key to extract domain and subdomain");
    }

    // Extract domain and subdomain
    let domain = domain_parts[0];
    let subdomain = domain_parts[1];

    // Build tags
    let domain_tag = build_tag("domain", domain);
    let sub_domain_tag = build_tag("subdomain", subdomain);
    let source_tag = build_tag("providertype", "user");
    let time_retrieved_tag = build_tag("datetime", time_retrieved);

    // Optional tags
    let optional_tags = vec![
        //build_optional_tag(&user_submission.phi, "phi"),
        build_bool_tag("phi", &user_submission.phi),
        build_bool_tag("pii", &user_submission.pii),
        build_bool_tag("summarize", &user_submission.summarize),
        build_optional_tag("image_type", &user_submission.image_type),
    ];

    // Filter out None values from optional tags and collect all tags
    let tags: Vec<Tag> = vec![domain_tag, sub_domain_tag, source_tag, time_retrieved_tag]
        .into_iter()
        .chain(optional_tags.into_iter().flatten())
        .collect();

    // Build Tagging object
    let tagging = Tagging::builder()
        .set_tag_set(Some(tags))
        .build()
        .unwrap_or_else(|err| {
            panic!("Failed to build tagging object: {}", err);
        });

    tagging
}

// Helper function to build a required tag
fn build_tag(key: &str, value: &str) -> Tag {
    Tag::builder()
        .key(key)
        .value(value)
        .build()
        .unwrap_or_else(|err| {
            panic!("Failed to build tag for key '{}': {}", key, err);
        })
}

// Helper function to build an optional tag if the value is Some
fn build_optional_tag(key: &str, value: &Option<String>) -> Option<Tag> {
    value.as_ref().map(|val| build_tag(key, val))
}

// Helper function to build a boolean tag
fn build_bool_tag(key: &str, value: &bool) -> Option<Tag> {
    Some(build_tag(key, if value.clone() { "true" } else { "false" }))
}

async fn function_handler(event: Request) -> Result<Response<Body>, Error> {
    let user_bucket = env::var("USER_BUCKET").expect("USER_BUCKET must be set.");
    let failed_bucket = env::var("FAILED_BUCKET").expect("FAILED_BUCKET must be set.");

    // Extract some useful information from the request
    let body_str = match std::str::from_utf8(event.body().as_ref()) {
        Ok(body_str) => body_str,
        Err(_error) => {
            return Ok(Response::builder()
                .header("Access-Control-Allow-Origin", "*")
                .status(400)
                .body(Body::from("Unable to derive request body, utf-8 error?"))
                .expect("Failed to build a response"))
        }
    };

    let request_info: UserTagSubmission = match serde_json::from_str(body_str) {
        Ok(user_data_struct) => user_data_struct,
        Err(_error) => {
            return Ok(Response::builder()
                .header("Access-Control-Allow-Origin", "*")
                .status(400)
                .body(Body::from(
                    "Invalid Request Body, missing mandatory file key in body.",
                ))
                .expect("Failed to build a response, for deserialize operation."))
        }
    };

    let original_file_key = request_info.file_key.clone();

    let file_name = request_info.file_key.split('/').last().unwrap_or("");

    let extension = Path::new(&request_info.file_key)
        .extension()
        .expect("Unable to build file extension, path, check s3 uri.")
        .to_str()
        .expect("Extension is not valid UTF-8");

    let document_extensions = vec![
        "txt", "md", "html", "doc", "docx", "pdf", "gz", "json", "yaml",
    ];
    let audio_extensions = vec!["mp3", "amr", "flac", "m4a", "ogg", "wav"];
    let video_extensions = vec!["mp4", "webm"];
    let image_extensions = vec!["png", "jpg"];

    // Check if the extension is in one of the supported file types.
    if !document_extensions.contains(&extension)
        && !audio_extensions.contains(&extension)
        && !image_extensions.contains(&extension)
        && !video_extensions.contains(&extension)
    {
        info!("File not Supported");
        // Move to unsupported bucket.
        storage_wrapper::copy_object(
            user_bucket.as_str(),
            request_info.file_key.as_str(),
            failed_bucket.as_str(),
            file_name,
        )
        .await?;
        // Delete from original
        storage_wrapper::delete_object(user_bucket.as_str(), request_info.file_key.as_str())
            .await?;
        let resp = Response::builder()
            .status(400)
            .header("content-type", "text/html")
            .header("Access-Control-Allow-Origin", "*")
            .body("File Not Supported, failed adding tags".into())
            .map_err(Box::new)?;
        return Ok(resp);
    }

    let tags = create_tags(&request_info, Utc::now().to_rfc3339().as_str());
    info!("{:?}", tags);
    storage_wrapper::assign_tags(user_bucket.as_str(), original_file_key.as_str(), tags).await?;

    let resp = Response::builder()
        .status(200)
        .header("content-type", "text/html")
        .header("Access-Control-Allow-Origin", "*")
        .body("Success Adding Tags".into())
        .map_err(Box::new)?;
    Ok(resp)
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
