use lambda_http::{run, service_fn, tracing, Body, Error, Request, RequestExt, Response};
use std::collections::HashMap;
use std::env;

use aws_sdk_dynamodb::types::Select;
use aws_sdk_dynamodb::Client;

async fn get_domains_sub_domains(client: &Client) -> Result<HashMap<String, Vec<String>>, Error> {
    let gsi_name = "audit_domain-subdomain-index"; // Replace with your GSI name
    let table_name = env::var("PROMPT_TABLE").expect("PROMPT_TABLE must be set.");
    // Query the table using GSI
    let output = client
        .scan()
        .table_name(table_name)
        .index_name(gsi_name)
        .select(Select::AllAttributes)
        .send()
        .await?;

    let mut domain_map: HashMap<String, Vec<String>> = HashMap::new();

    for item in output.items.unwrap_or_default() {
        let audit_domain = item
            .get("audit_domain")
            .and_then(|val| val.as_s().ok())
            .unwrap()
            .to_owned();
        let subdomain = item
            .get("subdomain")
            .and_then(|val| val.as_s().ok())
            .unwrap()
            .to_owned();

        domain_map
            .entry(audit_domain)
            .or_insert_with(Vec::new)
            .push(subdomain);
    }

    Ok(domain_map)
}

async fn function_handler(_event: Request) -> Result<Response<Body>, Error> {
    // Initialize the DynamoDB client
    let config = aws_config::load_from_env().await;
    let client = Client::new(&config);
    match get_domains_sub_domains(&client).await {
        Ok(results) => {
            let body = serde_json::to_string(&results).unwrap_or_else(|_| {
                "Failed to serialize get domain/subdomain response".to_string()
            });

            let resp = Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(200)
                .body(Body::from(body))
                .map_err(Box::new)?;

            return Ok(resp);
        }
        Err(e) => {
            let error_msg = format!("Error while getting domain and subdomain info: {:?}", e);

            let resp = Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(200)
                .body(error_msg.into())
                .map_err(Box::new)?;

            return Ok(resp);
        }
    };
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
