use std::env;

use aws_sdk_dynamodb::types::AttributeValue;
use aws_sdk_dynamodb::Client as DynamoDbClient;
use lambda_http::{run, service_fn, tracing, Body, Error, Request, RequestExt, Response};

async fn get_conversation(
    conversation_id: &str,
    dynamo_client: &DynamoDbClient,
) -> Result<genaitypes::SaveConversationRequest, Error> {
    let conversation_table_name =
        env::var("CONVERSATION_TABLE_NAME").expect("CONVERSATION_TABLE_NAME must be set.");

    // Perform the query
    let response = dynamo_client
        .query()
        .table_name(conversation_table_name)
        .key_condition_expression("#cid = :v_id")
        .expression_attribute_names("#cid", "conversation_id")
        .expression_attribute_values(":v_id", AttributeValue::S(conversation_id.to_string()))
        .send()
        .await?;

    // Check the number of items
    if let Some(items) = response.items {
        if items.len() == 1 {
            let conversation_data: genaitypes::SaveConversationRequest =
                serde_dynamo::from_item(items[0].to_owned())
                    .expect("No conversation in item row. Check DynamoDB prompt table?");

            return Ok(conversation_data);
        } else if items.len() > 1 {
            let error_msg = format!("Unexpectedly found more than one item: {:?}", items);
            return Err(error_msg.into());
        } else {
            let error_msg = format!("No Items found with given conversation id?");
            return Err(error_msg.into());
        }
    } else {
        let error_msg = format!("No Items found?");
        return Err(error_msg.into());
    }
}

async fn function_handler(event: Request) -> Result<Response<Body>, Error> {
    // Extract some useful information from the request
    let query_string_params = event.query_string_parameters();

    let conversation_id_str = match query_string_params.first("conversation_id") {
        Some(conversation_id_str) => conversation_id_str,
        None => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(400)
                .body(Body::from("Missing conversation_id query str param?"))
                .expect("Failed to build a response"))
        }
    };
    let config = aws_config::load_from_env().await;
    let client = DynamoDbClient::new(&config);

    match get_conversation(conversation_id_str, &client).await {
        Ok(conversation_info) => {
            let body = serde_json::to_string(&conversation_info)
                .unwrap_or_else(|_| "Failed to serialize response".to_string());

            let resp = Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(200)
                .body(Body::from(body))
                .map_err(Box::new)?;

            Ok(resp)
        }
        Err(err) => {
            let error_msg = format!("Error while querying DB for conversation id: {:?}", err);
            let resp = Response::builder()
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .header("content-type", "text/html")
                .status(500)
                .body(error_msg.into())
                .map_err(Box::new)?;
            Ok(resp)
        }
    }
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
