use std::collections::HashMap;

use aws_sdk_dynamodb::types::AttributeValue;
use aws_sdk_dynamodb::Client;
use lambda_http::{
    run, service_fn,
    tracing::{self},
    Body, Error, Request, Response,
};

async fn insert_new_domain(
    new_domain_data: genaitypes::DomainData,
    table_name: &str,
) -> Result<(), Error> {
    let config = aws_config::load_from_env().await;
    let dynamo_client = Client::new(&config);
    let mut item = HashMap::new();

    item.insert(
        "domain_id".to_string(),
        AttributeValue::N(new_domain_data.domain_id.to_string()),
    );
    item.insert(
        "audit_domain".to_string(),
        AttributeValue::S(new_domain_data.audit_domain),
    );
    item.insert(
        "data_source_ids".to_string(),
        AttributeValue::L(
            new_domain_data
                .data_source_ids
                .into_iter()
                .map(AttributeValue::S)
                .collect(),
        ),
    );
    item.insert(
        "gen_prompt".to_string(),
        AttributeValue::S(new_domain_data.gen_prompt),
    );
    item.insert(
        "invoke_prompt".to_string(),
        AttributeValue::S(new_domain_data.invoke_prompt),
    );
    item.insert(
        "knowledge_base_id".to_string(),
        AttributeValue::S(new_domain_data.knowledge_base_id),
    );
    item.insert(
        "model_id".to_string(),
        AttributeValue::S(new_domain_data.model_id),
    );
    item.insert(
        "subdomain".to_string(),
        AttributeValue::S(new_domain_data.subdomain),
    );

    dynamo_client
        .put_item()
        .table_name(table_name)
        .set_item(Some(item))
        .send()
        .await?;

    Ok(())
}

async fn function_handler(event: Request) -> Result<Response<Body>, Error> {
    let prompt_table_name = std::env::var("PROMPT_TABLE").expect("PROMPT_TABLE must be set.");

    // Extract some useful information from the request
    let body_str = match std::str::from_utf8(event.body().as_ref()) {
        Ok(body_str) => body_str,
        Err(_error) => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,POST")
                .status(400)
                .body(Body::from("Unable to derive request body, utf-8 error?"))
                .expect("Failed to build a response"))
        }
    };

    let new_domain_request_struct: genaitypes::DomainData = match serde_json::from_str(body_str) {
        Ok(insert_new_domain_request) => insert_new_domain_request,
        Err(_error) => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,POST")
                .status(400)
                .body(Body::from(
                    "Invalid Request Body,may be missing a domain key needed for insertion?",
                ))
                .expect("Failed to build a response, for deserialize operation."))
        }
    };

    match insert_new_domain(new_domain_request_struct, prompt_table_name.as_str()).await {
        Ok(()) => {
            let message = format!("Success inserting new domain.");

            // Return something that implements IntoResponse.
            // It will be serialized to the right response event automatically by the runtime
            let resp = Response::builder()
                .status(200)
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,POST")
                .header("content-type", "text/html")
                .body(message.into())
                .map_err(Box::new)?;
            return Ok(resp);
        }
        Err(e) => {
            let message = format!("Failure inserting new domain. Error: {:?}", e);

            // Return something that implements IntoResponse.
            // It will be serialized to the right response event automatically by the runtime
            let resp = Response::builder()
                .status(500)
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,POST")
                .header("content-type", "text/html")
                .body(message.into())
                .map_err(Box::new)?;
            return Ok(resp);
        }
    }
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();

    run(service_fn(function_handler)).await
}
