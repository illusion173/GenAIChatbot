use aws_sdk_dynamodb::operation::query::QueryOutput;
use aws_sdk_dynamodb::types::{AttributeValue, Select};
use aws_sdk_dynamodb::Client;
use lambda_http::{run, service_fn, tracing, Body, Error, Request, RequestExt, Response};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ConversationSummary {
    pub datetime_submitted: String,
    pub audit_domain: String,
    pub sub_domain: String,
    pub conversation_title: String,
    pub first_question: String,
    pub conversation_id: String,
}

async fn query_conversations_by_email(
    client: &Client,
    table_name: &str,
    user_email: &str,
    audit_domain: Option<&str>,
    sub_domain: Option<&str>,
) -> Result<Vec<ConversationSummary>, Error> {
    let user_email_global_index_name = "user_email-index".to_string();
    let partition_key = "user_email";

    let attributes_needed =
        "conversation_id, datetime_submitted,audit_domain,sub_domain,conversation_title,messages";

    let response: QueryOutput = match (audit_domain, sub_domain) {
        (Some(audit_domain_str), Some(sub_domain_str)) => {
            let key_condition_expression = "#user_email = :user_email".to_string();
            let filter_expression = "#audit_domain = :audit_domain AND #sub_domain = :sub_domain";
            let response = client
                .query()
                .table_name(table_name)
                .index_name(user_email_global_index_name.clone())
                .key_condition_expression(key_condition_expression)
                .expression_attribute_names("#user_email", partition_key)
                .filter_expression(filter_expression)
                .expression_attribute_names("#audit_domain", "audit_domain")
                .expression_attribute_names("#sub_domain", "sub_domain")
                .expression_attribute_values(
                    ":user_email",
                    AttributeValue::S(user_email.to_string()),
                )
                .expression_attribute_values(
                    ":audit_domain",
                    AttributeValue::S(audit_domain_str.to_string()),
                )
                .expression_attribute_values(
                    ":sub_domain",
                    AttributeValue::S(sub_domain_str.to_string()),
                )
                .projection_expression(attributes_needed)
                .send()
                .await?;
            response
        }
        (Some(audit_domain_str), None) => {
            let key_condition_expression = "#user_email = :user_email".to_string();
            let filter_expression = "#audit_domain = :audit_domain";
            let response = client
                .query()
                .table_name(table_name)
                .index_name(user_email_global_index_name.clone())
                .key_condition_expression(key_condition_expression)
                .filter_expression(filter_expression)
                .expression_attribute_names("#user_email", partition_key)
                .expression_attribute_names("#audit_domain", "audit_domain")
                .expression_attribute_values(
                    ":user_email",
                    AttributeValue::S(user_email.to_string()),
                )
                .expression_attribute_values(
                    ":audit_domain",
                    AttributeValue::S(audit_domain_str.to_string()),
                )
                .projection_expression(attributes_needed)
                .send()
                .await?;
            response
        }
        (None, Some(sub_domain_str)) => {
            let error_msg = format!(
                "Error, cannot have subdomain argument: {:?} without domain.",
                sub_domain_str
            );
            return Err(error_msg.into());
        }
        (None, None) => {
            let key_condition_expression = "#user_email = :user_email".to_string();
            let response = client
                .query()
                .table_name(table_name)
                .index_name(user_email_global_index_name.clone())
                .key_condition_expression(key_condition_expression)
                .expression_attribute_names("#user_email", partition_key)
                .expression_attribute_values(
                    ":user_email",
                    AttributeValue::S(user_email.to_string()),
                )
                .projection_expression(attributes_needed)
                .send()
                .await?;
            response
        }
    };

    let mut summaries = Vec::new();
    if let Some(items) = response.items {
        for item in items {
            if let (
                Some(datetime),
                Some(domain),
                Some(sub),
                Some(title),
                Some(messages),
                Some(conversation_id),
            ) = (
                item.get("datetime_submitted").and_then(|v| v.as_s().ok()),
                item.get("audit_domain").and_then(|v| v.as_s().ok()),
                item.get("sub_domain").and_then(|v| v.as_s().ok()),
                item.get("conversation_title").and_then(|v| v.as_s().ok()),
                item.get("messages").and_then(|v| v.as_l().ok()),
                item.get("conversation_id").and_then(|v| v.as_s().ok()),
            ) {
                if let Some(first_message) = messages.get(0) {
                    let first_message_map = first_message.as_m().unwrap();

                    let mut first_question_string = "No Questions.".to_string();

                    if let Some(first_question) = first_message_map.get("text") {
                        first_question_string = first_question.as_s().unwrap().to_owned();
                    }

                    summaries.push(ConversationSummary {
                        datetime_submitted: datetime.to_owned(),
                        audit_domain: domain.to_owned(),
                        sub_domain: sub.to_owned(),
                        conversation_title: title.to_owned(),
                        first_question: first_question_string.to_owned(),
                        conversation_id: conversation_id.to_string(),
                    });
                }
            }
        }
    }

    Ok(summaries)
}

async fn function_handler(event: Request) -> Result<Response<Body>, Error> {
    let conversation_table_name =
        std::env::var("CONVERSATION_TABLE_NAME").expect("CONVERSATION_TABLE_NAME must be set.");

    let query_string_params = event.query_string_parameters();

    let user_email = match query_string_params.first("user_email") {
        Some(user_email_string) => user_email_string,
        None => {
            return Ok(Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(400)
                .body(Body::from("Missing user_email query parameter"))
                .expect("Failed to build a response"));
        }
    };

    let audit_domain = query_string_params.first("domain");
    let sub_domain = query_string_params.first("sub_domain");
    // Initialize the DynamoDB client
    let config = aws_config::load_from_env().await;
    let client = Client::new(&config);

    // Query the DynamoDB table
    match query_conversations_by_email(
        &client,
        &conversation_table_name,
        user_email,
        audit_domain,
        sub_domain,
    )
    .await
    {
        Ok(summaries) => {
            let body = serde_json::to_string(&summaries)
                .unwrap_or_else(|_| "Failed to serialize response".to_string());

            let resp = Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .status(200)
                .body(Body::from(body))
                .map_err(Box::new)?;

            Ok(resp)
        }
        Err(err) => {
            let error_msg = format!("Error while querying DB: {:?}", err);
            eprintln!("Error querying DynamoDB: {:?}", err);
            let message = "Failed to query conversations";
            let resp = Response::builder()
                .header("content-type", "application/json")
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "OPTIONS,GET")
                .header("content-type", "text/html")
                .status(500)
                .body(error_msg.into())
                .map_err(Box::new)?;
            Ok(resp)
        }
    }
}

#[tokio::main]
async fn main() -> Result<(), Error> {
    tracing::init_default_subscriber();
    run(service_fn(function_handler)).await
}
