# genai-chatbot

<!--toc:start-->

- [genai-chatbot](#genai-chatbot)

  - [Description](#description)
  - [Architecture](#architecture)
  - [Documentation](#documentation)
  - [Deployment](/docs/cdkdeployment.md)
  - [Authors](#authors)
  - [Support](#support)

  <!--toc:end-->

## Description

This is an AWS Cloud solution to facilitate a chatbot Q&A style system for users using a RAG source.

This solution will enable those who are doing a systematic review of their cloud security and infrastructure to expedite evidence gathering for a standard, or certification.

This solution runs on AWS.

In an audit, it can take months to even a year (in hours) to obtain a standard certification.

#### Multiple Phases

- Understanding the standard's requirements, encryption at rest, at transit for ex.
- Scope Determination
- Self assessment, remediation, evidence gathering
- Documentation review, system inspection, training personnel

Event after obtaining the standard's certification, companies may need **Recertification**.

- ISO 27001, valid 3 years, yearly checks
- PCI DSS, yearly

## Architecture

![GenAIChatbot](./docs/GenAIDiagram_V2.png)

This solution intakes AWS service and user uploaded files to load them into a [knowledge base](https://aws.amazon.com/bedrock/knowledge-bases/) for [RAG](https://docs.aws.amazon.com/bedrock/latest/userguide/kb-how-it-works.html) retrieval for auditing purposes.

By using the [tag system](/docs/tag_system.md) one can have granular control on how files are ingested, down to the file type, whether it has phi, pii.

One can additionally have the system summarize an AWS service and user uploaded file by a bedrock foundational model, deriving useful information for later retrieval.

The foundational model and its prompt's can be specified based on the audit domain, as stated in the [DynamoDB Table](/docs/dynamo_db.md).

Once file ingestion and [syncing](/docs/synckb-step-function.md) of knowledge bases are done, one can use the chatbot interface hosted on Amplify to interact with the knowledge bases.

This solution enable auditors in multiple domains (security, infrastructure) a chatbot Q&A style chatbot web interface to efficiently recall evidence for an audit standard by using human language.

## Documentation

- [CDK Deployment](/docs/cdkdeployment.md)
- [Data Ingestion](/docs/dataingestion.md)
- [ChatBot Interaction](/docs/chatbot.md)
- [Prompt Information](/docs/prompt.md)
- [API Information](/docs/api_endpoints.md)
- [S3 Information](/docs/s3.md)
- [Tag System](/docs/tag_system.md)
- [DynamoDB Information](/docs/dynamo_db.md)
- [EventBridge Information](/docs/eventbridge.md)
- [IAM Permissions, Roles and Related](/docs/IAM.md)
- [Lambda Functions](/docs/lambdas.md)
- [Sync Knowledge Base Step Function](/docs/synckb-step-function.md)

## Authors

- Jay Scheponik jschepon@amazon.com
- Pooja Kondath pkondath@amazon.com
- Jeremiah Webb illusjw@amazon.com

## Support

For assistance, questions and support, please contact:

- Jay Scheponik jschepon@amazon.com
